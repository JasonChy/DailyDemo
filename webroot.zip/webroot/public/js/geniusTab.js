function watermark1(settings) {
  //默认设置
  var defaultSettings={
    id:"",
    watermark_txt:"text",
    watermark_x:20,//水印起始位置x轴坐标
    watermark_y:20,//水印起始位置Y轴坐标
    watermark_rows:4,//水印行数
    watermark_cols:4,//水印列数
    watermark_x_space:90,//水印x轴间隔
    watermark_y_space:60,//水印y轴间隔
    watermark_color:'#000000',//水印字体颜色
    watermark_alpha:0.2,//水印透明度
    watermark_fontsize:'18px',//水印字体大小
    watermark_font:'微软雅黑',//水印字体
    watermark_width:120,//水印宽度
    watermark_height:80,//水印长度
    watermark_angle:30//水印倾斜度数
  };
  //采用配置项替换默认值，作用类似jquery.extend
  if(arguments.length===1&&typeof arguments[0] ==="object" )
  {
    var src=arguments[0]||{};
    for(key in src)
    {
      if(src[key]&&defaultSettings[key]&&src[key]===defaultSettings[key])
        continue;
      else if(src[key])
        defaultSettings[key]=src[key];
    }
  }

  var oTemp = defaultSettings.id!=""? document.getElementById(defaultSettings.id):document.body;
   //获取页面最大宽度
  var page_width = Math.max(document.body.scrollWidth,document.body.clientWidth)>1200? Math.max(document.body.scrollWidth,document.body.clientWidth):1200 ;
  //获取页面最大长度
  var page_height = Math.max(document.body.scrollHeight,document.body.clientHeight)>768?Math.max(document.body.scrollHeight,document.body.clientHeight):768;

  if(defaultSettings.id!=""){
     page_width=parseInt(oTemp.style.width);
	 page_height=parseInt(oTemp.style.height);
  }

 
  //如果将水印列数设置为0，或水印列数设置过大，超过页面最大宽度，则重新计算水印列数和水印x轴间隔
  if (defaultSettings.watermark_cols == 0 || (parseInt(defaultSettings.watermark_x + defaultSettings.watermark_width *defaultSettings.watermark_cols + defaultSettings.watermark_x_space * (defaultSettings.watermark_cols - 1)) > page_width)) {
    defaultSettings.watermark_cols = parseInt((page_width-defaultSettings.watermark_x+defaultSettings.watermark_x_space) / (defaultSettings.watermark_width + defaultSettings.watermark_x_space));
    defaultSettings.watermark_x_space = parseInt((page_width - defaultSettings.watermark_x - defaultSettings.watermark_width * defaultSettings.watermark_cols) / (defaultSettings.watermark_cols - 1));
  }
  //如果将水印行数设置为0，或水印行数设置过大，超过页面最大长度，则重新计算水印行数和水印y轴间隔
  if (defaultSettings.watermark_rows == 0 || (parseInt(defaultSettings.watermark_y + defaultSettings.watermark_height * defaultSettings.watermark_rows + defaultSettings.watermark_y_space * (defaultSettings.watermark_rows - 1)) > page_height)) {
    defaultSettings.watermark_rows = parseInt((defaultSettings.watermark_y_space + page_height - defaultSettings.watermark_y) / (defaultSettings.watermark_height + defaultSettings.watermark_y_space));
    defaultSettings.watermark_y_space = parseInt(((page_height - defaultSettings.watermark_y) - defaultSettings.watermark_height * defaultSettings.watermark_rows) / (defaultSettings.watermark_rows - 1));
  }
  var x;
  var y;
  for (var i = 0; i < defaultSettings.watermark_rows; i++) {
    y = defaultSettings.watermark_y + (defaultSettings.watermark_y_space + defaultSettings.watermark_height) * i;
    for (var j = 0; j < defaultSettings.watermark_cols; j++) {
      x = defaultSettings.watermark_x + (defaultSettings.watermark_width + defaultSettings.watermark_x_space) * j;

      var mask_div = document.createElement('div');
      mask_div.id = 'mask' + i + j;
      mask_div.appendChild(document.createTextNode(defaultSettings.watermark_txt));
      //设置水印div倾斜显示
      mask_div.style.webkitTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
      mask_div.style.MozTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
      mask_div.style.msTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
      mask_div.style.OTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
      mask_div.style.transform = "rotate(-" + defaultSettings.watermark_angle + "deg)";
      mask_div.style.visibility = "";
      mask_div.style.position = "absolute";
      mask_div.style.left = x + 'px';
      mask_div.style.top = y + 'px';
      mask_div.style.overflow = "hidden";
      mask_div.style.zIndex = "9999";
      //mask_div.style.border="solid #eee 1px";
      mask_div.style.opacity = defaultSettings.watermark_alpha;
      mask_div.style.fontSize = defaultSettings.watermark_fontsize;
      mask_div.style.fontFamily = defaultSettings.watermark_font;
      mask_div.style.color = defaultSettings.watermark_color;
      mask_div.style.textAlign = "center";
      mask_div.style.width = defaultSettings.watermark_width + 'px';
      mask_div.style.height = defaultSettings.watermark_height + 'px';
      mask_div.style.display = "block";
      oTemp.appendChild(mask_div);
    };
  };
}


$(function(){
    $(".up-down-top").toggle(function(){ 
        if($(this).attr("data-url") && $(this).attr("data-url")!=""){  
           $(this).next(".up-down-text").animate({height: 'toggle', opacity: 'toggle'}, "slow");
            $(this).find(".x-caret").removeClass("x-caret-left");
            $(this).find(".x-caret").addClass("x-caret-down");
            var obj=$(this).next(".up-down-text");
            var t = obj.html();
            t = t.replace(/[\r\n]/g,"").replace(/[ ]/g,"");
            if($.trim(t)==""){            
            obj.load($(this).attr("data-url"),function(){
               $.each($(".check_up_content input[type=radio]"),function(i,item){       
                    $(item).bind("click",function(){
                        if($(this).val()=="verifyGiveup"){
                             $(".check_up_door select").show();
                        }else{
                             $(".check_up_door select").hide();
                        }
                    });
                 });
                  $("#btnSubmit").bind("click",function(){  				  
                     if($(".check_up_content input[type=radio]:checked").length<=0){
                         BUI.Message.Show({
                                        msg :'请选择操作项',
                                        icon : 'info',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });     
                         return;
                     }
                     if($.trim($("#txt_area"))==""){
                        BUI.Message.Show({
                                        msg :'小计不能为空',
                                        icon : 'info',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });       
                         return;
                     }
                     $("#btnSubmit").attr("disabled",true);
                     $.ajax({
                            url: "/epiboly/workflow/doDealTask.json",
                            dataType:"json",
                            data: $('#formSubmit_Check').serialize(),
                            type: "POST",
                            error: function(e) {            
                               BUI.Message.Show({
                                        msg : '提交失败',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });
									$("#btnSubmit").attr("disabled",false);
                            },
                            success: function(data) {
                            BUI.Message.Show({
                                        msg : data.result,
                                        icon : 'success',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });
						      $("#btnSubmit").attr("disabled",false);
							  window.location.reload();
                            }                   
                       });
                 });
                
            });    
          }         
    } 
    },function(){        
        if($(this).attr("data-url") && $(this).attr("data-url")!=""){
            $(this).next(".up-down-text").animate({height: 'toggle', opacity: 'toggle'}, "slow");
            $(this).find(".x-caret").removeClass("x-caret-down");
            $(this).find(".x-caret").addClass("x-caret-left");
        }
    });
   $.each($(".up-down-top"),function(i,item){
       if($(item).attr("data-url") && $(item).attr("data-url")!=""){
          $(item).click()  
       } 
   });
    function parseObj( strData ){
        return (new Function( "return " + strData ))();
    }
    fileNam="";    
     var picArr=[];                   
    	  BUI.use(['bui/imgview','bui/overlay'],function(ImgView,Overlay){    
                 	     dialog = new Overlay.Dialog({
							        id:"showPic",
		                            title:'图片查看器',
		                            width:900,
		                            height:580,
		                            mask:false,
		                            buttons:[],
		                            closeAction:'hide',
		                            bodyContent:'<div><div class="image_tree"> </div> <div id="imgviewWrap"></div></div>',
		                            listeners:{
		                                closeclick:function(){
		                                     if(imgView) {
		                                         //imgView.remove(true);
		                                         imgView.hide();
		                                     }
		                                }
		                            }
		                            
		                            
		                    });
		                  imgView = new ImgView.ImgView({
		                                    render: "#imgviewWrap",
		                                    width: 640,
		                                    height: 480,
		                                    imgList: picArr,
		                                    imgNum: 2, // 默认取第几张图片，默认为0，取第一张
		                                    autoRender: false // 是否自动渲染,默认为false
		                    }); 
		            });          
    	
    
    $(".bui-tab-item").bind("click",function(){
        //$("#tabContent").html("");
        var obj=$(this);
        $(this).siblings(".bui-tab-item-selected").removeClass("bui-tab-item-selected");
        $(this).addClass("bui-tab-item-selected")
        if(obj.find("span").html()=="采集数据"){
           var a = $("<a href='"+$(this).find("span").attr("data-url")+"' target='_blank'>采集数据</a>").get(0);
           if(document.createEvent){
                var e = document.createEvent('MouseEvents');  
                e.initEvent('click', true, true);  
                a.dispatchEvent(e);  
           } 
           else if( document.createEventObject )
           {
                a.fireEvent('click');
           }          
        }
        else{        
           $("#tabContent").load($(this).find("span").attr("data-url"),function(){
            if(obj.find("span").html()=="上传文件资料"){
                if(selectPageConfigJosn!=null){
                    var dataObj= selectPageConfigJosn;
                    $.each(dataObj, function(i,item){
                        if(typeof(item)!="undefined")
                            $("#parentFileType").append("<option value='"+item.value+"'>"+item.text+"</option>");
                    });
                    var uploader = null;                    
                    function uploadFile(){
                        var dataObj={taskId:$("#taskId").val(),categoryCode:$("#categoryCode").val()};
                        BUI.use('bui/uploader',function (Uploader) {
                            uploader = new Uploader.Uploader({
                                render: '#J_Uploader',
                                url: '/loan/doLoanTaskUploadFileAjax.json',
                                rules: {
                                    //文的类型
                                   ext: ['.doc,.docx,.xls,.xlsx,.zip,.7z,.rar,.jpeg,.jpg,.bmp,.gif,.png,.txt','文件类型只能为{0}'],
                                    //上传的最大个数
                                   // max: [5, '文件的最大个数不能超过{0}个'],
                                    //文件大小的最小值,这个单位是kb
                                    //minSize: [5, '文件的大小不能小于{0}KB'],
                                    //文件大小的最大值,单位也是kb
                                    maxSize: [103424, '文件大小不能大于100M']
                                },
                               data:dataObj,
                               listeners:{                                   
                                   start:function(){
                                                          
                                   },                                   
                                   mousedown:function(){
                                        if(dataObj.categoryCode=='')
                                        {
                                            BUI.Message.Show({
                                            msg : '文件分类不能为空',
                                            icon : 'error',
                                            width:200,
                                            buttons : [{ text:'关闭', elCls : 'button', handler : function(){ this.hide(); }}],
                                            autoHide : false
                                            });
                                            return false;
                                        }                                       
                                   }
                                }
                            }).render();
                            
                            //上传成功时会触发
                            uploader.on('success', function(ev){
                                var result = ev.result;
                                    BUI.Message.Show({
                                        msg : '上传成功',
                                        icon : 'success',
                                        width:200,
                                        buttons : [],
                                        autoHide : true,
                                        autoHideDelay : 1000
                                    });
                            })
                            //上传成功时会触发
                            uploader.on('error', function(ev){
                                var result = ev.result;
                                if(result.result=="上传成功"){
                                        BUI.Message.Show({
                                            msg : '上传成功',
                                            icon : 'success',
                                            width:200,
                                            buttons : [],
                                            autoHide : true,
                                            autoHideDelay : 1000
                                        });
                                }
                                else{
                                        BUI.Message.Show({
                                            msg : result.result+" 请删除,重新上传！",
                                            icon : 'error',
                                            width:200,
                                            buttons : [{ text:'关闭', elCls : 'button', handler : function(){ this.hide(); }}],
                                            autoHide : false
                                        });
                                    $(".defaultTheme .bui-queue-item .action").css("display","block");
                                }
                            });
                        });                        
                    }
                    $("#parentFileType").bind("change",function(ev){
                        var obj=$(this);                        
                        $("#categoryCode").val(obj.val());
                        uploader && uploader.destroy();
                        uploadFile();
                        
                    });
                    uploadFile();
                }
            }
            if(obj.find("span").html()=="文件下载"){
				    $(".delteFile").on("click",function(){
					var taskid=$(this).attr("taskId");
					var ossPath=$(this).attr("ossPath");
					$.ajax({
							url: "/loan/deleteFileAjax.json?taskId="+taskid+"&ossPath="+ossPath,
							dataType:"json",
							type: "get",
							error: function(e) {            
							BUI.Message.Show({
										msg : '删除失败',
										icon : 'error',
										width:200,
										buttons : [],
										autoHide :false 
									});
							},
							success: function(data) {
							BUI.Message.Show({
										msg : data.result,
										icon : 'success',
										width:200,
										buttons : [],
										autoHide :false 
									});	
                             obj.click();				  
							}                   
					   });
		
					});
				
				
                    // autoRender如果为true就代表自动渲染。         
                    $('#ScanImage').bind('click',function () {  
                    	  $(".image_tree").html("");    
                    	    var imageTreeJson=picTypeJson;
                            var strContent = [];
							var str_img="";
                            $.each(imageTreeJson,function(i, item) {                               
                                if (item.dataFileList && item.dataFileList.length > 0) {  
                                    str_img=""; 
									$.each(item.dataFileList,function(k,imgitem){
									  str_img+=imgitem.pcHttpUrl+"||";
									});
                                }
								strContent.push('<div class="parent_first"><span class="parent_text"  data=' + str_img + '><b>' + item.text + '</b></span></div>');
                            });
                            dialog.show();			
		                    watermark({id:"imgviewWrap",watermark_txt: realName})//传入动态水印内容
                            $(".image_tree").append(strContent.join(''));     
	                        if(imgView){                        
								imgView.show();
	                        }  
                            $(".parent_first span ").on("click",function(evt) {
                                var str = $(this).attr("data");
                                picArr=[];
                                if (str.length > 0) {
                                    var strArr = str.split('||');                            
                                    if (strArr.length > 0) {
                                    $.each(strArr,function(i, item) {
                                      var picObj = {
                                            src: "123",
                                            miniSrc: "456"
                                        };
                                        picObj.src = item;
                                        picObj.miniSrc = item;
                                        picArr.push(picObj)
                                    });
                                 }
                                 picArr.pop();
                                 imgView.show();
                                 imgView.set('imgList', picArr);                                               
                               } else{
                                 imgView.hide();
                              }
                            });
                           
                    });                   
               }            
          });
        }
    });
   
    $.each($(".bui-tab-item"),function(i,item){
        if($(item).attr("class").indexOf("bui-tab-item-selected")>0){
            $(item).click();
        }
    });
    
    $(".total tr:gt(0)").bind("mouseover",function(){
        $(this).css("backgroundColor","#0093bd");
    });
    $(".total tr:gt(0)").bind("mouseout",function(){
        $(this).css("backgroundColor","");
    });
    $(".total tr:gt(0)").bind("click",function(){
        $(this).siblings().removeClass("selected");
        $(this).addClass("selected");
    });
})