$(function(){
	var showLoanar= {
		loadData:function(){//获取数据
			var self = this;
			//获取taskId
			var taskId=$("#taskId").val();
			if(!taskId){
				BUI.Message.Alert('taskId为空','error');
				return false;
			}
			jQuery.ajax({
		    	url: "/loanar/queryLoanar.json?taskId="+taskId,
		        dataType:"json",
		        type: "POST",
		        async:false,
		        success: function(data){
		        	if(data['loanArResult']){
		        		var datas=data['loanArResult'];
		        		if(datas['resultObj']){
		        			//授信信息
		        			if(datas['resultObj']['creditModel']){
				        		var creditModelData=datas['resultObj']['creditModel'];
					        	self.buildCreditModule(creditModelData);
		        			}
		        			//合约信息
		        			if(datas['resultObj']['contractModel']){
					        	var contractModelData=datas['resultObj']['contractModel'];
					        	self.buildContractTable(contractModelData);
		        			}else{
		        				//合约信息
					        	self.buildContractTable([]);
		        			}
		        		}else{
		        			//合约信息
				        	self.buildContractTable([]);
		        		}
		        		//返回false
		        		if(!data['loanArResult']['success'] && data['loanArResult']['message']){
			        		BUI.Message.Alert(data['loanArResult']['message'],'info');
			        	}
		        	}else{
		        		//合约信息
			        	self.buildContractTable([]);
			      		BUI.Message.Alert('暂无数据','info');
		        	}
		        },
		        error: function(e) {            
		        	BUI.Message.Alert('获取数据失败','error');
		        }
		 	});
		},
		buildCreditModule:function(data){//渲染授信模块信息
			//将数据填充到对应的字段上
			var creditAmt=data['creditAmt'];
			var instalIntRate=data['instalIntRate'] && data['instalIntRate'].length>0?data['instalIntRate'][0]['value']:'';
			var loanTerm=data['loanTerm'];
			var repayModes=data['repayModes'] && data['repayModes'].length>0?data['repayModes'][0]['value']:'';
			$("#creditAmt").html(creditAmt);
			$("#instalIntRate").html(instalIntRate);
			$("#loanTerm").html(loanTerm);
			$("#repayModes").html(repayModes);
		},
		buildContractTable:function(dataSource){//绘画合约table
			var Grid = BUI.Grid,
	        Data = BUI.Data;
	    	var Store = Data.Store,
	        columns = [
	            { title: '合约号', width: '20%', sortable: false, dataIndex:'argmentNo',elCls:'center'},
				{ title: '合约额度（元）', width: '15%', sortable: false, dataIndex:'encashAmt',elCls:'center'},
				{ title: '应还本金（元）', width: '15%', sortable: false, dataIndex:'allPrin',elCls:'center'},
				{ title: '应还利息（元）', width: '15%', sortable: false, dataIndex:'allInt',elCls:'center'},
				{ title: '应还罚息（元）', width: '15%', sortable: false, dataIndex:'allPenInt',elCls:'center'},
				{ title: '合约状态', width: '10%', sortable: false, dataIndex:'status',elCls:'center',renderer : function (value,obj) {
					if(obj.status == 'NORMAL'){
						return '<span>正常</span>';
					}
					if(obj.status == 'CLEAR'){
						return '<span>结清</span>';
					}
					if(obj.status == 'LENDING'){
						return '<span>发放中</span>';
					}
					if(obj.status == 'OVD'){
						return '<span>逾期</span>';
					}
				}},
				{title : '操作', width: '10%', dataIndex:'e',elCls:'center',renderer : function (value,obj) {
					if(obj.status == 'NORMAL' || obj.status =='OVD'){
						return '<span class="grid-command btn-edit"><a href="javascript:void(0)" class="grid-command repaymentOperate">机构代客户还款</a></span>';
					}else{
						return '<span>--</span>';
					}
				}}
			];
	        var store = new Store({
	        	data : dataSource,
	        	autoLoad:true,
	        	pageSize:10
	        }),
	        grid = new Grid.Grid({
		        render:'#grid',
		        loadMask: true,
		        width:'100%',
		        columns : columns,
	            bbar:{
	                pagingBar:true
	            },
		        store : store
	        });
	        grid.render();
	        
	        //机构代客户还款
	    	var Overlay = BUI.Overlay;
	    	grid.on('cellclick',function(ev){
	    		var obj=this;
	    		var record = ev.record, 
	         	field = ev.field, 
	         	target = jQuery(ev.domTarget); 
	        	if(target.hasClass('repaymentOperate')){
	        		//模态框弹出
	        		var Overlay = BUI.Overlay
	        		var dialog = new Overlay.Dialog({
	    	            title:'机构代客户还款',
	    	            width:400,
	    	            height:200,
	    	            mask:false,
        	            buttons:[
	                    {
	    	                text:'确定',
	    	                elCls : 'button button-primary confirmBtn',
	    	                handler : function(){
			        			var allPrin=$("#allPrin").val();
			        			//校验金额
			        			if(!checkMoney()){
			        				return false;
			        			}
		        				$(".confirmBtn").attr("class","button button-primary confirmBtn");
	    	            	    jQuery.ajax({//ajax请求,提交到后端
	    	            	    	url: '/loanar/loanArRepay.json',
	    	   			           	dataType:"json",
	    	   			           	data: {
	    	   			           		prinAmt:allPrin?allPrin:'',
	   			           				loanArNo:record['argmentNo']?record['argmentNo']:'',
	   			           				taskId:$("#taskId").val()?$("#taskId").val():''
	    	   			           	},
	    	   			           	type: "POST",
	    	   			           	async:false,
	    	   			           	error: function(e){
	    	   			           		BUI.Message.Alert('受理失败','error');
	    	   			           	},
	    	   			           	success: function(data) {
	    	   			           		if(data['loanArResult']['success']){
	    	   			           			BUI.Message.Alert('受理成功','info');
		    	   			           		setTimeout(function(){
			   			           				window.location.reload();
			   			           			},2000);
	    	   			           		}else{
	    	   			           			var msg='';
	    	   			           			if(typeof data['loanArResult'] !== 'undefined' && typeof data['loanArResult']['message'] !== 'undefined' ){
	    	   			           				if(data['loanArResult']['message']){
	    	   			           					msg=':'+data['loanArResult']['message'];
	    	   			           				}
	    	   			           			}
	    	   			           			BUI.Message.Alert('受理失败'+msg,'error');
	    	   			           		}
	    	   			           	}                   
	   						  	});
	    	            	    dialog.close();
   			           			this.destroy();
	    	                }
	                    },{
	    	                text:'关闭',
	    	                elCls : 'button',
	    	                handler : function(){
	    	                	//this.close();
	    	                	dialog.close();
	    	                	this.destroy();
	    	                }
	                    }],
        	            bodyContent:
    	            	'<div>'+
	    	            	'<form class="form-horizontal" autocomplete="off">'+
				        		'<p style="margin-top:20px;">'+
				            		'<label style="margin-left:10px;">还款金额（元）：</label>'+
				            		'<input type="text" name="allPrin" id="allPrin" onChange="javaScript:checkMoney(this);" onKeyUp="javaScript:checkMoney(this);" onKeyDown="return ClearSubmit(event)" onKeyPress="return ClearSubmit(event)" value="'+record['allPrin']+'" data-allPrin="'+record['allPrin']+'" style="width:180px;">'+
				        		'</p>'+
				        		'<span id="checkSpan" style="margin-left: 105px;color:red;"></span>'+
				        	'</form>'+
			        	'</div>'
	        		});
		        	dialog.show();
	        	}
	        });
		}
	}
	showLoanar.loadData();
})