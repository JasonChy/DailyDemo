(function($){
	  var taskId = $("#hidden1").html();
	  var bankAccountName = $("#hidden2").html();
	  var bankAccount = $("#hidden3").html();
	  var maxCreditAmount = $("#hidden4").html();
	  var intRate = $("#hidden5").html();
	  var repaymentMethod = $("#hidden6").html();
	  var loanPeriod = $("#hidden7").html();
	  var validDate = $("#hidden8").html();
	  var expireDate = $("#hidden9").html();
      var contactNo = $("#hidden12").html();
      var headOfficeBankContactNo = $("#hidden13").html();
	  
	  
	  
	  /*录入人员再待复审待终审和拒绝三种状态下查看的input框的不同状态（是否可编辑）*/
	  var status = $("#hidden10").html();
	  var editable = $("#hidden11").html();
	  
	  

      /*如果任务以拒绝处理则后面加上个“（拒绝）”字样，如果是终审通过处理则没有改字样*/
      if(status == "REFUSED"){
        $("#jujue").css("display","inline-block");
      }else{
        $("#jujue").css("display","none");
      }




	  console.log(status);
	  if(status == ""&&editable == "true"){
		  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
	  }else if(status == ""&&editable == "false"){
		  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
      }else if(status == "INPUT"&&editable == "true"){
    	  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
	  }else if(status == "INPUT"&&editable == "false"){
		  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "REVIEW"&&editable == "true"){
		  $(".inputButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "REVIEW"&&editable == "false"){
		  $(".inputButton").css("display","none");
          $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "RECHECK"&&editable == "true"){
		  $(".inputButton").css("display","none");
		  $(".reviewButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "RECHECK"&&editable == "false"){
		  $(".inputButton").css("display","none");
		  $(".reviewButton").css("display","none");
          $(".recheckButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "REFUSED"){
		  $(".inputButton").css("display","none");
		  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }else if(status == "VALID"){
		  $(".inputButton").css("display","none");
		  $(".reviewButton").css("display","none");
		  $(".recheckButton").css("display","none");
		  $(".inputMessage").attr("disabled","false");
	  }
	  
	  
	  
	  
	  
	  
	  /*点击查看接受的日期进行格式化(“yyyy-MM-dd”)形式*/
      var validDateNew = new Date(validDate);
      var expireDateNew = new Date(expireDate);
  
      var validDateFormat = validDateNew.toJSON();
      var expireDateFormat = expireDateNew.toJSON();
      if(typeof(validDateFormat) == "string"||typeof(expireDateFormat) == "string"){
          var validDateString = validDateFormat.substring(0,10);
          var expireDateString = expireDateFormat.substring(0,10);
      }else if(typeof(validDateFormat) == "object"||typeof(expireDateFormat) == "object"){
    	  var validDateString = "";
          var expireDateString = "";
      }
	  
	  
	  
	  $(".buyer").val(bankAccountName);
	  $(".bankCard").val(bankAccount);
	  $(".creditAmount").val(maxCreditAmount);
	  $(".moneyRate").val(intRate);
	  $(".payBack").val(repaymentMethod);
	  $(".lifeLoan").val(loanPeriod);
	  $(".validDate").val(validDateString);
	  $(".expireDate").val(expireDateString);
      $(".contactNo").val(contactNo);
      $(".headOfficeBankContactNo").val(headOfficeBankContactNo);

        

        


	    /*借款期限的正整数限制*/
        /*document.getElementsByClassName('lifeLoan')[0].addEventListener("input",function(){
            if(!/^\+?[1-9][0-9]*$/.test(this.value)){
                    showErrMsg("借款期限请输入正整数！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".lifeLoan").removeAttr("disabled");
                }else if(!/^[1-9]\d{0,6}$/.test(this.value)){
                    showErrMsg("借款期限数字长度不能过长！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".lifeLoan").removeAttr("disabled");
                }else{
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
        })*/

        


        /*授信金额的正数限制 如果没有放款行联行号则授信金额不能超过500万元*/ 
        if($(".contactNo").val() == ""){
            /*document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(this.value)){
                    showErrMsg("授信金额请输入正数！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".creditAmount").removeAttr("disabled");
                }else if($(".creditAmount").val() > 500){
                    showErrMsg("放款行支行联行号不能为空！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".creditAmount").removeAttr("disabled");
                }else{
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
            })*/
            showErrMsg("放款行支行联行号不能为空！");
            $(".inputButton").css("display","none");
            $(".inputMessage").attr("disabled","false");
            $(".creditAmount").removeAttr("disabled");
        }else{
            document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(this.value)){
                    showErrMsg("授信金额请输入正数！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".creditAmount").removeAttr("disabled");
                }else if($(".creditAmount").val() > 100000){
                        showErrMsg("授信金额不能超过10亿！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                }else{
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
            })
        }

        document.getElementsByClassName('contactNo')[0].addEventListener("input",function(){
            if($(".contactNo").val() == ""){
                /*if($(".creditAmount").val() > 500){
                    showErrMsg("放款行支行联行号不能为空！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".creditAmount").removeAttr("disabled");
                }
                document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                    if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(this.value)){
                        showErrMsg("授信金额请输入正数！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                    }else if($(".creditAmount").val() > 500){
                        showErrMsg("放款行支行联行号不能为空！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                    }else{
                        hideErrMsg();
                        $(".inputMessage").removeAttr("disabled");
                        $(".inputButton").css("display","inline-block");
                    }
                })*/
                showErrMsg("放款行支行联行号不能为空！");
                $(".inputButton").css("display","none");
                $(".inputMessage").attr("disabled","false");
                $(".creditAmount").removeAttr("disabled");
                document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                    showErrMsg("放款行支行联行号不能为空！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".creditAmount").removeAttr("disabled");
                })
            }else{
                hideErrMsg();
                $(".inputMessage").removeAttr("disabled");
                $(".inputButton").css("display","inline-block");
                document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                    if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(this.value)){
                        showErrMsg("授信金额请输入正数！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                    }else if($(".creditAmount").val() > 100000){
                        showErrMsg("授信金额不能超过10亿！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                    }else{
                        hideErrMsg();
                        $(".inputMessage").removeAttr("disabled");
                        $(".inputButton").css("display","inline-block");
                    }
                })
                /*if($(".creditAmount").val() > 500){
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
                document.getElementsByClassName('creditAmount')[0].addEventListener("input",function(){
                    if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])$/.test(this.value)){
                        showErrMsg("授信金额请输入正数！");
                        $(".inputButton").css("display","none");
                        $(".inputMessage").attr("disabled","false");
                        $(".creditAmount").removeAttr("disabled");
                    }else{
                        hideErrMsg();
                        $(".inputMessage").removeAttr("disabled");
                        $(".inputButton").css("display","inline-block");
                    }
                })*/
            }
        })



            


        /*利率的大于零小于一的限制*/ 
        /*document.getElementsByClassName('moneyRate')[0].addEventListener("input",function(){
            if(this.value <= 0 || this.value > 2){
                    showErrMsg("利率请输入大于零且小于二的数！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".moneyRate").removeAttr("disabled");
                }else{
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
        })*/


        /*利率的只能是数字*/
        document.getElementsByClassName('moneyRate')[0].addEventListener("input",function(){
            if(!/^([1-9]\d*(\.\d*[1-9])?)|(0\.\d*[1-9])|0$/.test(this.value)){
                    showErrMsg("利率需是大于等于0的数字！");
                    $(".inputButton").css("display","none");
                    $(".inputMessage").attr("disabled","false");
                    $(".moneyRate").removeAttr("disabled");
                }else{
                    hideErrMsg();
                    $(".inputMessage").removeAttr("disabled");
                    $(".inputButton").css("display","inline-block");
                }
        })

        
    

        function showErrMsg(errMsg) {
            var msgNode = $("#errMsg");
            msgNode.html(errMsg);
            msgNode.css("display","block");
        }
        function hideErrMsg(){
            var msgNode = $("#errMsg");
            msgNode.css("display","none");
        }







            
        
        /*录入人员进行数据保存但不提交以便下次继续填写信息*/
        $("#keep").click(function(){
        	var isSubmit = 2;
            var bankAccountName = $(".buyer").val();
            var bankCard = $(".bankCard").val();
            var creditAmount = $(".creditAmount").val();
            var moneyRate = $(".moneyRate").val();
            var lifeLoan = $(".lifeLoan").val();
            var validDate = $(".validDate").val();
            var expireDate = $(".expireDate").val();
            var payBack = $(".payBack").val();
            var contactNo = $(".contactNo").val();
            var headOfficeBankContactNo = $(".headOfficeBankContactNo").val();



            /*生效日与失效日转换成number类型并且差值与0相比*/
            /*var validDateArr = validDate.split('-');
            var expireDateArr = expireDate.split('-');
            var validDateNumber = parseInt(validDateArr[0]+validDateArr[1]+validDateArr[2]);
            var expireDateNumber = parseInt(expireDateArr[0]+expireDateArr[1]+expireDateArr[2]);*/



            /*if(bankCard == ""||creditAmount == ""||moneyRate == ""||lifeLoan == ""||validDate == ""||payBack == ""||expireDate == ""){*/
            /*因为去掉了日期以及借款期限所有有的判断要删掉*/
        	if(bankCard == ""||creditAmount == ""||moneyRate == ""||payBack == ""||headOfficeBankContactNo == ""||contactNo == ""){
            	alert("输入框不能为空！")
            	return false;
            }else if($(".payBack").val() == "请选择"){
            	alert("请选择还款方式！")
                return false;
            }/*else if(expireDateNumber - validDateNumber <= 0){
                alert("失效日必须大于生效日!")
            }*/else{
            	$.ajax({
            		url: '/supplychainprepay/saveManualCreditInput.json',
            		type: 'post',
            		dataType: 'json',
            		data: {
            			taskId : taskId,
            			isSubmit : isSubmit,
                        bankAccountName : bankAccountName,
            			bankAccount : bankCard,
            			maxCreditAmount : creditAmount,
            			intRate : moneyRate,
            			loanPeriod : lifeLoan,
            			validDate : validDate,
            			expireDate : expireDate,
            			repaymentMethod : payBack,
                        contactNo : contactNo,
                        headOfficeBankContactNo : headOfficeBankContactNo
            		},
            		success:function(obj){
            			alert(obj.remark)
            		},
            		error:function(obj) {
            			alert(obj.remark)
            		}
            	})
            }
        })


        /*录入人员进行数据提交*/
        $("#pass").click(function(){
            var isSubmit = 1;
            var bankAccountName = $(".buyer").val();
            var bankCard = $(".bankCard").val();
            var creditAmount = $(".creditAmount").val();
            var moneyRate = $(".moneyRate").val();
            var lifeLoan = $(".lifeLoan").val();
            var validDate = $(".validDate").val();
            var expireDate = $(".expireDate").val();
            var payBack = $(".payBack").val();
            var contactNo = $(".contactNo").val();
            var headOfficeBankContactNo = $(".headOfficeBankContactNo").val();


            /*生效日与失效日转换成number类型并且差值与0相比*/
            /*var validDateArr = validDate.split('-');
            var expireDateArr = expireDate.split('-');
            var validDateNumber = parseInt(validDateArr[0]+validDateArr[1]+validDateArr[2]);
            var expireDateNumber = parseInt(expireDateArr[0]+expireDateArr[1]+expireDateArr[2]);*/
        	


            /*if(bankCard == ""||creditAmount == ""||moneyRate == ""||lifeLoan == ""||validDate == ""||payBack == ""||expireDate == ""){*/
            /*因为去掉了日期以及借款期限所有有的判断要删掉*/
            if($(".payBack").val() == "请选择"){
                alert("请选择还款方式！")
                return false;
            }else if(bankCard == ""||creditAmount == ""||moneyRate == ""||payBack == ""||headOfficeBankContactNo == ""||contactNo == ""){
            	alert("输入框不能为空！")
            	return false;
            }/*else if(expireDateNumber - validDateNumber <= 0){
                alert("失效日必须大于生效日!")
            }*/else{
            	$.ajax({
            		url: '/supplychainprepay/saveManualCreditInput.json',
            		type: 'post',
            		dataType: 'json',
            		data: {
            			taskId : taskId,
            			isSubmit : isSubmit,
                        bankAccountName : bankAccountName,
            			bankAccount : bankCard,
            			maxCreditAmount : creditAmount,
            			intRate : moneyRate,
            			loanPeriod : lifeLoan,
            			validDate : validDate,
            			expireDate : expireDate,
            			repaymentMethod : payBack,
                        contactNo : contactNo,
                        headOfficeBankContactNo : headOfficeBankContactNo
            		},
            		success:function(obj){
            			alert(obj.remark)
            		},
            		complete: function(){
        			    window.location.reload();
                    },
            		error:function(obj) {
            			alert(obj.remark)
            		}
            	})
            }
        })
        
        

        /*点击拒绝弹出拒绝原因框*/
    	$("#refuse").click(function(){
    		$("#reasonsRefusal").css("display","block");
    	})
        /*在拒绝原因框弹出后点击确定发送拒绝原因后弹框消失按钮全部失效，并且拒绝原因字数限制500字*/
        $("#ensure").click(function(){
            $("#refuse").attr("disabled","false");
            $("#refuse").css("background-color","#ccc");
            $("#refuse").css("border","1px solid #ccc");
        	var textInfo = $(".refuseInfo").val();
        	var textLangth = $(".refuseInfo").val().length;
        	
        	if(textLangth > 500){
                alert("最多输入500个字符！")
                $(".refuseInfo").val($(".refuseInfo").val().substring(0,500))
            }else{
        	    $.ajax({
    		        url: '/supplychainprepay/refuseManualCreditInput.json',
    		        type: 'post',
    		        dataType: 'json',
    		        data: {
    			        taskId : taskId,
    			        refuseReason : textInfo,
    		        },
    		        success:function(obj){
    			        alert(obj.remark)
    		        },
    		        complete: function(){
    		        	window.location.reload();
                    },
    		        error:function(obj) {
    			        alert(obj.remark)
    		        }
    	        })
                $("#reasonsRefusal").css("display","none");
        	    $("#keep").attr("disabled","false");
                $("#pass").attr("disabled","false");
                $("#refuse").attr("disabled","false");
            }	   
        })
        /*在拒绝原因框弹出后点击取消弹框消失，内容清空*/
        $("#cancel").click(function(){
        	$("#reasonsRefusal").css("display","none");
        	$(".refuseInfo").val("");
        })
        
        
        
        /*复审和终审人员在点击通过按钮时*/
        $("#ReviewThrough").click(function(){
            $(this).attr("disabled","false");
            $(this).css("background-color","#ccc");
            $(this).css("border","1px solid #ccc");
            $("#ReviewGoback").attr("disabled","false");
        	var isPassed = 1;
        	$.ajax({
        		url: '/supplychainprepay/reviewManualCreditInput.json',
        		type: 'post',
        		dataType: 'json',
        		data: {
        			taskId : taskId,
        			isPassed : isPassed,
        		},
        		success:function(obj){
        			alert(obj.remark)
        		},
        		complete: function(){
        			window.location.reload();
                },
        		error:function(obj) {
        			alert(obj.remark)
        		}
        	})
        })
        
        
        /*复审和终审人员在点击打回按钮时*/
        $("#ReviewGoback").click(function(){
            $(this).attr("disabled","false");
            $(this).css("background-color","#ccc");
            $(this).css("border","1px solid #ccc");
            $("#ReviewThrough").attr("disabled","false");
        	var isPassed = 2;
        	$.ajax({
        		url: '/supplychainprepay/reviewManualCreditInput.json',
        		type: 'post',
        		dataType: 'json',
        		data: {
        			taskId : taskId,
        			isPassed : isPassed,
        		},
        		success:function(obj){
        			alert(obj.remark)
        		},
        		complete: function(){
        			window.location.reload();
                },
        		error:function(obj) {
        			alert(obj.remark)
        		}
        	})
        })
        
        
        

        /*终审和终审人员在点击通过按钮时*/
        $("#RecheckThrough").click(function(){
            $(this).attr("disabled","false");
            $(this).css("background-color","#ccc");
            $(this).css("border","1px solid #ccc");
            $("#RecheckGoback").attr("disabled","false");
        	var isPassed = 1;
        	$.ajax({
        		url: '/supplychainprepay/recheckManualCreditInput.json',
        		type: 'post',
        		dataType: 'json',
        		data: {
        			taskId : taskId,
        			isPassed : isPassed,
        		},
        		success:function(obj){
        			alert(obj.remark)
        		},
        		complete: function(){
        			window.location.reload();
                },
        		error:function(obj) {
        			alert(obj.remark)
        		}
        	})
        })
        
        
        /*终审和终审人员在点击打回按钮时*/
        $("#RecheckGoback").click(function(){
            $(this).attr("disabled","false");
            $(this).css("background-color","#ccc");
            $(this).css("border","1px solid #ccc");
            $("#RecheckThrough").attr("disabled","false");
        	var isPassed = 2;
        	$.ajax({
        		url: '/supplychainprepay/recheckManualCreditInput.json',
        		type: 'post',
        		dataType: 'json',
        		data: {
        			taskId : taskId,
        			isPassed : isPassed,
        		},
        		success:function(obj){
        			alert(obj.remark)
        		},
        		complete: function(){
        			window.location.reload();
                },
        		error:function(obj) {
        			alert(obj.remark)
        		}
        	})
        })
})(jQuery);