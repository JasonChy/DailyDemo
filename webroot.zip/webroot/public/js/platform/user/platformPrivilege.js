$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '权限id',dataIndex :'id',sortable: false, width:40,elCls : 'center'},
       {title : '权限名',dataIndex :'privilegeName',sortable: false, width:40,elCls : 'center'},
       {title : '权限描述',dataIndex :'privilegeDesc',sortable: false, width:60,elCls : 'center'},
       {title: '操作', width: 120, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var delPrivilege = '<a href="javascript:void(0)" class="grid-command PrivilegeDelete">删除</a>';
				var updatePrivilege = '<a href="javascript:void(0)" class="grid-command PrivilegeUpdate">编辑</a>';
				var operateEvt= updatePrivilege+"&nbsp;&nbsp;"+delPrivilege;
				return operateEvt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                privilegeName:$("#privilegeName").val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	
	
	
	//新增用户
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addPlatformPrivilegeform'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增权限',
	          width:500,
	          height:300,
	          //配置DOM容器的编号
	          contentId:'addPlatformPrivilegeDiv',
	          success:function () {
	        	  var privilegeName = $("#a_privilegeName").val();
	        	  var PrivilegeDesc = $("#privilegeDesc").val();
	        	  var memo = $("#memo").val();
	        	  
	        	  
	        	  if(privilegeName==undefined || privilegeName==""){
			    		BUI.Message.Alert('权限名必填','info');
			    		return false;
			      }
	        	  
			      $.ajax({
			    		url: 'addPlatformPrivilegeAjax.json',
			    		dataType:"json",
			    		data: {
			    			privilegeName:privilegeName,
			    			PrivilegeDesc:PrivilegeDesc,
			    			memo:memo
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','success');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else if(data.message=="NotUnique"){
			    		    	BUI.Message.Alert('权限码不唯一，请修改后重试','error'); 
			    		     }else{
			    		    	BUI.Message.Alert('新增权限失败','error'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addPlatformPrivilege').on('click',function () {
            dialog.show();
          });   
         
        });	
	
	
	
  //编辑权限信息
	grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        field = ev.field, //点击对应列的dataIndex
        target = $(ev.domTarget); //点击的元素
        var privilegeDesc= record.privilegeDesc?record.privilegeDesc:"";
        var privilegeId = record.id;
        //用户信息
        if(target.hasClass('PrivilegeUpdate')){
        	var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*权限名：</font></span><input type="text" name="b_privilegeName" id="b_privilegeName" value="'+record.privilegeName+'"  onchange="chkvalue('+privilegeId+',this)" style="width:150px;"/>'+
        	'<span class="valid-text" style=" display:none" id="b_privilegeNameErr">'+
        	'<span class="error"><span class="x-icon x-icon-mini x-icon-error">!</span><em>权限名称不唯一</em></span></span></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">权限描述：</span><input type="text" name="b_privilegeDesc" id="b_privilegeDesc" value="'+privilegeDesc+'" style="width:150px;" /></div>';
        	var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'编辑权限信息',
		        width:480,
		        height:250,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   var privilegeName=$("#b_privilegeName").val()?$("#b_privilegeName").val():"";
   		        	   var privilegeDesc=$("#b_privilegeDesc").val()?$("#b_privilegeDesc").val():"";
	   	        	   if(privilegeName==undefined || privilegeName==""){
	   	        		   BUI.Message.Alert('权限名必填','info');
	   	        		   return false;
	   		      	   }
                	   //do some thing
	            	   $.ajax({
	   						url: 'addPlatformPrivilegeAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	privilegeName:privilegeName,
	   			            	privilegeDesc:privilegeDesc
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('修改权限成功','success');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else if(data.message=="NotUnique"){
						    		    	BUI.Message.Alert('权限码不唯一，请修改后重试','error'); 
					    		     }else{
					    		    	BUI.Message.Alert('修改权限异常','error'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
    });
	
	
	
	
	 //删除用户
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>确定要删除该权限吗？';
        if(target.hasClass('PrivilegeDelete')){
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除权限',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   //do some thing
	            	   $.ajax({
	   						url: 'deletePrivilegeAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
	   			             if(data.message=="success"){
									BUI.Message.Alert('删除成功','info');
					    			setTimeout(function(){
						            	window.location.reload();
						            },2000);
				    		     }else{
				    		    	BUI.Message.Alert('删除失败','info'); 
				    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
	});

function chkvalue(privilegeId,privilege){
	var privilegeName = privilege.value;
	var msgId = privilege.id + "Err";
	if(privilegeName.length == 0 || privilegeName == ''){
		return false;
	}
	
	$.ajax({
		url: 'checkPrivilegeNameUnique.json',
		dataType:"json",
		data: {
			id:privilegeId,
			privilegeName:privilegeName
		},
		type: "POST",
		error: function(e){
			$('#'+msgId).show();
			BUI.Message.Alert('校验失败','info');
			return false;
		},
		success: function(data) {
			if(data.message == "success"){
				//校验成功不做处理
				$('#'+msgId).hide();
			}else if(data.message == "NotUnique"){
				$('#'+msgId).show();
				return false;
			}
		}                   
	});
	
}




