$(function() {
	BUI.use([ 'bui/grid', 'bui/data' ], function(Grid, Data) {
		var Store = Data.Store, columns = [ {
			title : '权限id',
			dataIndex : 'id',
			sortable : false,
			width : 40,
			elCls : 'center'
		}, {
			title : '权限名',
			dataIndex : 'privilegeName',
			sortable : false,
			width : 40,
			elCls : 'center'
		}, {
			title : '权限描述',
			dataIndex : 'privilegeDesc',
			sortable : false,
			width : 60,
			elCls : 'center'
		} ],

		store = new Store({
			url : $("#btnSearch").data("url"),
			autoLoad : true,
			pageSize : 10,
			proxy : {
				method : 'post',
				dataType : 'json'
			},
			params : {
				start : 0,
				privilegeName : $("#privilegeName").val(),
				a_roleId:$('#a_roleId').val()
			},
			listeners : {
				beforeprocessload : function(e) {

				}

			}
		}),

		grid = new Grid.Grid({
			render : '#grid',
			columns : columns,
			itemStatusFields : { //设置数据跟状态的对应关系
	              selected : 'selected',
	              disabled : 'disabled'
	         },
			loadMask : true,
			forceFit : true,
			plugins : [ Grid.Plugins.CheckSelection ],
			store : store,
			// 顶部工具栏
			bbar : {
				//items 也可以在此配置
				// pagingBar:表明包含分页栏
				pagingBar : true
			}
		});

		grid.render();

		//没有数据，处理分页栏
		if (!store.getTotalCount()) {
			$('#grid #totalPage').text("共 0 页");
			$('#grid .bui-pb-page').val("0");
			$('#grid #totalCount').text("共0条记录");
		}

		//创建表单，表单中的日历，不需要单独初始化
		var form = new BUI.Form.HForm({
			srcNode : '#searchForm'
		}).render();

		form.on('beforesubmit', function(ev) {
			//序列化成对象
			var obj = form.serializeToObject();
			// obj.start = 0; //返回第一页
			var page = $('#grid .bui-pb-page').val();
			obj.pageIndex = page - 1;
			store.load(obj);
			return false;
		});

		//获取选中行数据
		/*  grid.on('rowselected',function(ev){
		        var record = ev.record;
		        privilegeId = record.id;
		        alert(record.id);
		        $('#privilegeId').val(privilegeId);
		      });
		 */

		BUI.use('bui/form', function(Form) {
			var form = new Form.HForm({
				srcNode : '#J_Form',
				submitType : 'ajax',
				callback : function(data) {
					if (data.message == "success") {
						BUI.Message.Alert('关联信息成功','success');
						setTimeout(function(){
			            	window.location.reload();
			            },2000);
					}else{
						BUI.Message.Alert('关联信息失败','error');
					}
				}
			}).render();
			//提交前校验选中行
			form.on('beforesubmit', function() {
				var privilegeId = '';
				var selections = grid.getSelection();
				if (selections != null && selections.length >0) {
					for (var i = 0; i < selections.length; i++) {
						if (i == selections.length - 1) {
							privilegeId += selections[i].id;
						} else {
							privilegeId += selections[i].id;
							privilegeId += ',';
						}

					}
					$('#privilegeIds').val(privilegeId);
					return true;
				} 
				/*else {
					BUI.Message.Alert('请选中指定项进行提交！','warning');
					return false;
				}*/

			});

		});

	});

});