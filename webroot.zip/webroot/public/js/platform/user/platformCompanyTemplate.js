$(function() {
	// 初始化任务表格
	var Grid = BUI.Grid, Store = BUI.Data.Store, columns = [
			{
				title : '公司id',
				dataIndex : 'companyId',
				sortable : false,
				width : 40,
				elCls : 'center'
			},
			{
				title : '模板id',
				dataIndex : 'templateId',
				sortable : false,
				width : 40,
				elCls : 'center'
			},
			{
				title : '模板编码',
				dataIndex : 'templateCode',
				sortable : false,
				width : 40,
				elCls : 'center'
			},
			{
				title : '业务名称',
				dataIndex : 'bizName',
				sortable : false,
				width : 40,
				elCls : 'center'
			},
			{
				title : '操作',
				width : 120,
				dataIndex : 'id',
				elCls : 'center',
				renderer : function(value, obj) {
					var delCompany = '<a href="javascript:void(0)" class="grid-command CompanyTemplateDelete">删除</a>';
					var updateCompany = '<a href="javascript:void(0)" class="grid-command CompanyTemplateUpdate">编辑</a>';
					var operateEvt = updateCompany + "&nbsp;&nbsp;"
							+ delCompany;
					return operateEvt;
				}
			} ];
	store = new Store({
		url : $("#btnSearch").data("url"),
		autoLoad : true,
		pageSize : 10,
		proxy : {
			method : 'post',
			dataType : 'json'
		},
		params : {
			start : 0,
			companyId : $('#companyId').val(),
			bizName : $('#bizName').val()
		},
		listeners : {
			beforeprocessload : function(e) {

			}

		}
	}),

	grid = new Grid.Grid({
		render : '#grid',
		loadMask : true,
		forceFit : true,
		columns : columns,
		store : store,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
			// pagingBar:表明包含分页栏
			pagingBar : true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if (!store.getTotalCount()) {
		$('#grid #totalPage').text("共 0 页");
		$('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}

	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
		srcNode : '#searchForm'
	}).render();

	form.on('beforesubmit', function(ev) {
		//序列化成对象
		var obj = form.serializeToObject();
		// obj.start = 0; //返回第一页
		var page = $('#grid .bui-pb-page').val();
		obj.pageIndex = page - 1;
		store.load(obj);
		return false;
	});

	//新增公司模板
	BUI.use([ 'bui/overlay', 'bui/form' ], function(Overlay, Form) {
		var form = new Form.HForm({
			srcNode : '#addPlatformCompanyTemplateform'
		}).render();
		var dialog = new Overlay.Dialog({
			title : '新增公司模板关联',
			width : 500,
			height : 300,
			//配置DOM容器的编号
			contentId : 'addPlatformCompanyTemplateDiv',
			success : function() {
				var companyId = $("#companyId").val();
				var templateId = $("#templateId").val();
				var bizName = $('#a_bizName').val();
				var memo = $("#memo").val();

				$.ajax({
					url : 'addPlatformCompanyTemplateAjax.json',
					dataType : "json",
					data : {
						companyId : companyId,
						templateId : templateId,
						bizName : bizName,
						memo : memo
					},
					type : "POST",
					async : false,
					error : function(e) {
						BUI.Message.Alert('新增失败', 'error');
					},
					success : function(data) {
						if (data.message == "success") {
							BUI.Message.Alert('新增成功', 'info');
							setTimeout(function() {
								window.location.reload();
							}, 2000);
						} else {
							BUI.Message.Alert('公司模板关联失败', 'info');
						}
					}
				});
				this.close();
			}
		});

		$('#addPlatformCompanyTemplate').on('click', function() {
			dialog.show();
		});

	});

	function bindData(companyId,templateId) {
		var dataOption = "";
		$.ajax({
			type : "post",
			url : "/platform/company/initTemplateDict.json?companyId="+companyId,
			dataType : 'json',
			async : false,
			success : function(data) {
				if (data) {
					dataOption = "<option value=\"\">---请选择所属公司---</option>";
					dataStatus = "<option value=\"\">---请选择用户状态---</option>";
					$.each(data.templateList, function(i, item) {
						if ($.trim(templateId) == $.trim(item.id)) {
							dataOption += "<option value='" + item.id
									+ "' selected>" + item.templateCode
									+ "</option>";
						} else {
							dataOption += "<option value='" + item.id + "'>"
									+ item.templateCode + "</option>";
						}

					});

				}
			}
		});
		return dataOption;
	}

	//编辑公司模板
	grid
			.on(
					'cellclick',
					function(ev) {
						var obj = this;
						var record = ev.record, //点击行的记录
						field = ev.field, //点击对应列的dataIndex
						target = $(ev.domTarget); //点击的元素
						var dataObject = bindData(record.companyId,record.templateId);

						//公司信息
						if (target.hasClass('CompanyTemplateUpdate')) {
							var msg = '<input type="hidden" name="id" id="id" value="'
									+ record.id
									+ '" style="width:100px;"/>'
									+ '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">所属模板：</span><select name="b_templateId" id="b_templateId">'
									+ dataObject
									+ '</select></div>'
									+ '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">业务名：</span><input type="text" name="b_bizName" id="b_bizName" value="'
									+ record.bizName
									+ '" style="width:150px;"/></div>';
							var Overlay = BUI.Overlay;
							var dialog = new Overlay.Dialog(
									{
										title : '编辑公司信息',
										width : 400,
										height : 250,
										bodyContent : msg,
										buttons : [
												{
													text : '确定',
													elCls : 'button button-primary',
													handler : function() {
														var obj = this;
														var id = $("#id").val() ? $(
																"#id").val()
																: "";
														var templateId = $(
																"#b_templateId")
																.val() ? $(
																"#b_templateId")
																.val()
																: "";
														var bizName = $(
																"#b_bizName")
																.val() ? $(
																"#b_bizName")
																.val() : "";
														if (templateId == undefined
																|| templateId == "") {
															BUI.Message.Alert(
																	'模板id必填',
																	'info');
															return false;
														}
														if (bizName == undefined
																|| bizName == "") {
															BUI.Message.Alert(
																	'业务名称必填',
																	'info');
															return false;
														}
														//do some thing
														$
																.ajax({
																	url : 'addPlatformCompanyTemplateAjax.json',
																	dataType : "json",
																	data : {
																		id : id,
																		templateId : templateId,
																		bizName : bizName
																	},
																	type : "POST",
																	error : function(
																			e) {
																		BUI.Message
																				.Alert(
																						'修改失败',
																						'error');
																		obj
																				.destroy();
																	},
																	success : function(
																			data) {
																		if (data.message == "success") {
																			BUI.Message
																					.Alert(
																							'修改公司模板成功',
																							'info');
																			setTimeout(
																					function() {
																						window.location
																								.reload();
																					},
																					2000);
																		} else {
																			BUI.Message
																					.Alert(
																							'修改公司模板异常',
																							'info');
																		}
																		obj
																				.destroy();
																	}
																});
													}
												}, {
													text : '取消',
													elCls : 'button',
													handler : function() {
														this.destroy();
													}
												} ]
									});
							dialog.show();
						}
					});

	//删除公司模板
	grid.on('cellclick', function(ev) {
		var obj = this;
		var record = ev.record, //点击行的记录
		field = ev.field, //点击对应列的dataIndex
		target = $(ev.domTarget); //点击的元素

		var id = record.id;
		var msg = '<input type="hidden" name="id" id="id" value="' + record.id
				+ '" style="width:100px;"/>确定要删除该公司模板吗？';
		if (target.hasClass('CompanyTemplateDelete')) {
			var Overlay = BUI.Overlay;
			var dialog = new Overlay.Dialog({
				title : '删除公司模板',
				width : 300,
				height : 200,
				bodyContent : msg,
				buttons : [ {
					text : '确定',
					elCls : 'button button-primary',
					handler : function() {
						var obj = this;
						var id = $("#id").val() ? $("#id").val() : "";
						//do some thing
						$.ajax({
							url : 'deleteCompanyTemplateAjax.json',
							dataType : "json",
							data : {
								id : id
							},
							type : "POST",
							error : function(e) {
								BUI.Message.Alert('删除失败', 'error');
								obj.destroy();
							},
							success : function(data) {
								if (data.message == "success") {
									BUI.Message.Alert('删除成功', 'info');
									setTimeout(function() {
										window.location.reload();
									}, 2000);
								} else {
									BUI.Message.Alert('删除失败', 'info');
								}
								obj.destroy();
							}
						});
					}
				}, {
					text : '取消',
					elCls : 'button',
					handler : function() {
						this.destroy();
					}
				} ]
			});
			dialog.show();
		}

	});

});