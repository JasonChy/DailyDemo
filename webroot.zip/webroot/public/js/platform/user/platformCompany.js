var flag;
var returnFlag = false;

$(function(){  

	 var province = document.getElementById("province");
     var city = document.getElementById("city");
     var area = document.getElementById("area");
	
	 province.options[0] = new Option("请选择省", "-1");
     city.options[0] = new Option("请选择市", "-1");
     area.options[0] = new Option("请选择区", "-1");
        //循环第一步
    for (var i = 0; i < addressData.length; i++) {
        // console.log(province.length);
        province.options[province.length] = new Option(addressData[i].label, addressData[i].value);
        province.onchange = function () {
            //恢复默认选项
            //city.options[0].selected = true;
            //area.options[0].selected = true;
            //清空市区选项
            city.options.length = 0;
            city.options[city.length] = new Option("请选择市", "-1");
            area.options.length = 0;
            area.options[area.length] = new Option("请选择区", "-1");
            for (var j = 0; j < addressData[province.selectedIndex - 1].children.length; j++) {
                city.options[city.length] =
                    new Option(addressData[province.selectedIndex - 1].children[j].label,
                        addressData[province.selectedIndex - 1].children[j].value);
                city.onchange = function () {
                    //恢复默认选项
                    //area.options[0].selected = true;
                    //清空区选项
                    area.options.length = 0;
                    area.options[area.length] = new Option("请选择区", "-1");
                    for (var k = 0; k < addressData[province.selectedIndex - 1].
                        children[city.selectedIndex - 1].children.length; k++) {
                        area.options[area.length] =
                            new Option(addressData[province.selectedIndex - 1].
                                children[city.selectedIndex - 1].children[k].label,
                                addressData[province.selectedIndex - 1].
                                    children[city.selectedIndex - 1].children[k].value);
                    }
                }
            }
        }
    }
  	// 初始化任务表格
    var Grid = BUI.Grid,
        Store = BUI.Data.Store,
        columns = [
            {title : '公司id',dataIndex :'id',sortable: false, width:40,elCls : 'center'},
            {title : '公司名',dataIndex :'companyName',sortable: false, width:40,elCls : 'center'},
            {title : '网商会员号',dataIndex :'orgIproleid',sortable: false, width:40,elCls : 'center'},
            {title : '工商注册号',dataIndex :'iCRegistCode',sortable: false, width:40,elCls : 'center'},
            {title : '所属地区',dataIndex :'region',sortable: false, width:80,elCls : 'center'},
            {title: '操作', width: 80, dataIndex: 'id',elCls : 'center',
                renderer:function(value,obj){
                    var delCompany = '<a href="javascript:void(0)" class="grid-command CompanyDelete">删除</a>';
                    var updateCompany = '<a href="javascript:void(0)" class="grid-command CompanyUpdate">编辑</a>';
                    var companyImages = '<a href="/platform/company/companyImages.htm?companyId='+obj.id+'" class="grid-command companyImages"  target="_blank">图片管理</a>';
                    var operateEvt= updateCompany+"&nbsp;&nbsp;"+delCompany+"&nbsp;&nbsp;"+companyImages;
                    return operateEvt;
                }
            }
        ];
    store = new Store({
        url: $("#btnSearch").data("url"),
        autoLoad:true,
        pageSize:10,
        proxy:{
            method:'post',
            dataType:'json'
        },
        params : {
            start : 0,
            companyName:$("#companyName").val()
        },
        listeners:{
            beforeprocessload:function(e){

            }
        }
    }),

        console.log(store);

        grid = new Grid.Grid({
            render:'#grid',
            loadMask: true,
            forceFit:true,
            columns : columns,
            store: store,
            // 顶部工具栏
            bbar : {
                //items 也可以在此配置
                // pagingBar:表明包含分页栏
                pagingBar:true
            }
        });
    grid.render();

    //没有数据，处理分页栏
    if(!store.getTotalCount())
    {
        $('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
        $('#grid #totalCount').text("共0条记录");
    }

    //创建表单，表单中的日历，不需要单独初始化
    var form = new BUI.Form.HForm({
        srcNode : '#searchForm'
    }).render();


    form.on('beforesubmit',function(ev) {
        //序列化成对象
        var obj = form.serializeToObject();
        // obj.start = 0; //返回第一页
        var page=$('#grid .bui-pb-page').val();
        obj.pageIndex = page-1;
        store.load(obj);
        return false;
    });




    //新增用户
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
            srcNode : '#addPlatformCompanyform'
        }).render();
        var dialog = new Overlay.Dialog({
            title:'新增公司',
            width:700,
            height:400,
            //配置DOM容器的编号
            contentId:'addPlatformCompanyDiv',
            success:function () {
            
                var companyName = $("#a_companyName").val();
                var ICRegistCode2 = $("#ICRegistCode2").val();
                var orgIproleid2 = $("#orgIproleid2").val();
                var regionArr = new Array($("#province").val(),$("#city").val(),$("#area").val());
                var regionCode = regionArr.join(",");
                var memo = $("#memo").val();

                if(companyName==undefined || companyName==""){
                    BUI.Message.Alert('公司名必填','info');
                    return false;
                }
                if(ICRegistCode2==undefined || ICRegistCode2==""){
                    BUI.Message.Alert('工商注册号必填','info');
                    return false;
                }
                if(orgIproleid2==undefined || orgIproleid2==""){
                    BUI.Message.Alert('网商会员号必填','info');
                    return false;
                }
                if(regionCode==undefined || regionCode==""){
                	BUI.Message.Alert('所属区域必填','info');
                    return false;
                }
                var dia = this;
				
                $.ajax({
                    url: 'addPlatformCompanyAjax.json',
                    dataType:"json",
                    data: {
                        companyName:companyName,
                        orgIproleid:orgIproleid2,
                        ICRegistCode:ICRegistCode2,
                        region:regionCode,
                        memo:memo
                    },
                    type: "POST",
                    async: false,
                    error: function(e){
                        BUI.Message.Alert('新增公司失败','error');
                        dia.close();
                    },
                    success: function(data) {
                        if(data.message=="success"){
                            BUI.Message.Alert('新增公司成功','success');
                            dia.close();
                            setTimeout(function(){
                                window.location.reload();
                            },2000);

                        }else if(data.message=="NotUnique"){
                            BUI.Message.Alert('公司名不唯一','error');
                        }else if(data.message=="certifyFalse"){
                            BUI.Message.Alert('公司网商会员号或工商注册号不正确','error');
                        }else{
                            BUI.Message.Alert('新增公司失败','error');
                            dia.close();
                        }
                    }
                });


            }
        });

        $('#addPlatformCompany').on('click',function () {
            dialog.show();
        });

    });



    //编辑公司信息
    grid.on('cellclick',function(ev) {
        var obj=this;
        var record = ev.record, //点击行的记录
            field = ev.field, //点击对应列的dataIndex
            target = $(ev.domTarget); //点击的元素
		var regionCode1 = record.region;
		var regionArr1 = regionCode1.split(",");
        //用户信息
        if(target.hasClass('CompanyUpdate')){
            var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>'+
                '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*公司名：</font></span><input type="text" name="b_companyName" id="b_companyName" value="'+record.companyName+'" onchange="chkCompanyValue('+record.id+',this)" style="width:150px;"/>'+
                '<span class="valid-text" style=" display:none" id="b_companyNameErr">'+
                '<span class="error"><span class="x-icon x-icon-mini x-icon-error">!</span><em>该公司名已存在</em></span></span></div>'+
                '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*网商会员号：</font></span><input type="text" name="orgIproleid1" id="orgIproleid1" value="'+record.orgIproleid+'" style="width:150px;"/></div>'+
                '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*工商注册号：</font></span><input type="text" name="iCRegistCode1" id="iCRegistCode1" value="'+record.iCRegistCode+'" style="width:150px;" onchange="checkICRegistCode(1)"/></div>'+
                '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*所属区域：</font></span><select name="province1" id="province1"/><select name="city1" id="city1"/><select name="area1" id="area1"/></div>';
            var Overlay = BUI.Overlay;
            var dialog = new Overlay.Dialog({
                title:'编辑公司信息',
                width:700,
                height:250,
                bodyContent:msg,
                buttons:[{
                    text:'确定',
                    elCls : 'button button-primary',
                    handler : function(){
                        var obj=this;
                        var id = $("#id").val()?$("#id").val():"";
                        var companyName=$("#b_companyName").val()?$("#b_companyName").val():"";
                        var orgIproleid1=$("#orgIproleid1").val()?$("#orgIproleid1").val():"";
                        var ICRegistCode1=$("#iCRegistCode1").val()?$("#iCRegistCode1").val():"";
	
                        if(companyName==undefined || companyName==""){
                            BUI.Message.Alert('公司名称必填','info');
                            return false;
                        }
                        if(orgIproleid1==undefined || orgIproleid1==""){
                            BUI.Message.Alert('网商会员号称必填','info');
                            return false;
                        }
                        if(ICRegistCode1==undefined || ICRegistCode1==""){
                            BUI.Message.Alert('公司工商注册号必填','info');
                            return false;
                        }


                        //do some thing
                        $.ajax({
                            url: 'addPlatformCompanyAjax.json',
                            dataType:"json",
                            data: {
                                id:id,
                                companyName:companyName,
                                orgIproleid:orgIproleid1,
                                ICRegistCode:ICRegistCode1
                            },
                            type: "POST",
                            error: function(e){
                                BUI.Message.Alert('修改公司失败','error');
                                obj.destroy();
                            },
                            success: function(data) {
                                if(data.message=="success"){
                                    BUI.Message.Alert('修改公司成功','success');
                                    setTimeout(function(){
                                        window.location.reload();
                                    },2000);
                                }else if(data.message=="NotUnique"){
                                    BUI.Message.Alert('公司名不唯一','error');
                                }else if(data.message=="certifyFalse"){
                                    BUI.Message.Alert('公司网商会员号或工商注册号不正确','error');
                                }else{
                                    BUI.Message.Alert('修改公司异常','error');
                                }
                                obj.destroy();
                            }
                        });
                    }
                },{
                    text:'取消',
                    elCls : 'button',
                    handler : function(){
                        this.destroy();
                    }
                }]
            });
            dialog.show();
        }
    });

    //删除用户
    grid.on('cellclick',function(ev) {
        var obj=this;
        var record = ev.record, //点击行的记录
            field = ev.field, //点击对应列的dataIndex
            target = $(ev.domTarget); //点击的元素

        var id = record.id;
        var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>确定要删除该公司吗？';
        if(target.hasClass('CompanyDelete')){
            var Overlay = BUI.Overlay;
            var dialog = new Overlay.Dialog({
                title:'删除公司',
                width:300,
                height:200,
                bodyContent:msg,
                buttons:[{
                    text:'确定',
                    elCls : 'button button-primary',
                    handler : function(){
                        var obj=this;
                        var id = $("#id").val()?$("#id").val():"";
                        //do some thing
                        $.ajax({
                            url: 'deleteCompanyAjax.json',
                            dataType:"json",
                            data: {
                                id:id
                            },
                            type: "POST",
                            error: function(e){
                                BUI.Message.Alert('删除失败','error');
                                obj.destroy();
                            },
                            success: function(data) {
                                if(data.message=="success"){
                                    BUI.Message.Alert('删除成功','info');
                                    setTimeout(function(){
                                        window.location.reload();
                                    },2000);
                                }else{
                                    BUI.Message.Alert('删除失败','info');
                                }
                                obj.destroy();
                            }
                        });
                    }
                },{
                    text:'取消',
                    elCls : 'button',
                    handler : function(){
                        this.destroy();
                    }
                }]
            });
            dialog.show();
        }

    });


});


//检查公司工商注册号时候正确
function checkICRegistCode(type){
    var orgIproleid;
    var ICRegistCode;
    if(type==1){
        orgIproleid= $("#orgIproleid1").val();
        ICRegistCode = $("#iCRegistCode1").val();
    }else{
        orgIproleid= $("#orgIproleid2").val();
        ICRegistCode = $("#ICRegistCode2").val();
    }

    if(orgIproleid==undefined || orgIproleid==""){
        return false;
    }
    if(ICRegistCode==undefined || ICRegistCode==""){
        return false;
    }

    $.ajax({
        url: 'checkICRegistCode.json',
        dataType:"json",
        data: {
            orgIproleid:orgIproleid,
            ICRegistCode:ICRegistCode
        },
        type: "POST",
        error: function(e){
            BUI.Message.Alert('校验失败','info');
            return false;
        },
        success: function(data) {
            if(data.message=="success"){
                //校验成功不做处理
            }else{
                BUI.Message.Alert('公司网商会员号或工商注册号不正确','info');
                return false;
            }
        }
    });

}

function chkCompanyValue(companyId,company){
    var companyName = company.value;
    var msgId = company.id + "Err";
    if(companyName.length == 0 || companyName == ''){
        return false;
    }

    $.ajax({
        url: 'checkCompanyNameUnique.json',
        dataType:"json",
        data: {
            id:companyId,
            companyName:companyName
        },
        type: "POST",
        error: function(e){
            $('#'+msgId).show();
            BUI.Message.Alert('公司名唯一性校验失败','info');
            return false;
        },
        success: function(data) {
            if(data.message == "success"){
                //校验成功不做处理
                $('#'+msgId).hide();
            }else if(data.message == "NotUnique"){
                $('#'+msgId).show();
                return false;
            }
        }
    });

}