
function getUrlVars(){
	var vars = [], hash;
	var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	for(var i = 0; i < hashes.length; i++)
	{
		hash = hashes[i].split('=');
		vars.push(hash[0]);
		vars[hash[0]] = hash[1];
	}
	return vars;
}

function getUrlVar(name){
	return getUrlVars()[name];
}


//显示表格

BUI.use(['bui/grid','bui/data'],function(Grid,Data){
	var Grid = Grid,
	Store = Data.Store,
	columns = [
	           {
	        	   title : 'id',
	        	   dataIndex : 'id',
	        	   sortable : false,
	        	   width : 10,
	        	   elCls : 'center'
	           },
	           {
	        	   title : '图片',
	        	   dataIndex : 'showImage',
	        	   sortable : false,
	        	   width : 40,
	        	   elCls : 'center'
	           },
	           {
	        	   title : 'actionUrl',
	        	   dataIndex : 'actionUrl',
	        	   sortable : false,
	        	   width : 40,
	        	   elCls : 'center'
	           },
	           {
	        	   title : '公司',
	        	   dataIndex : 'relatedName',
	        	   sortable : false,
	        	   width : 40,
	        	   elCls : 'center'
	           },
	           {
	        	   title : '操作',
	        	   width : 40,
	        	   dataIndex : 'id',
	        	   elCls : 'center',
	        	   renderer : function(value, obj) {
	        		   var deleteImage = '<a href="javascript:deleteImage('+obj.id+')" class="grid-command deleteImage">删除图片</a>';
	        		   var operateEvt = deleteImage;
	        		   return operateEvt;
	        	   }
	           } ];


	var store = new Store({
		url : '/platform/images/listCompanyImages.json',
		autoLoad:true, //自动加载数据
		pageSize:10,	// 配置分页数目
		params : { //配置初始请求的参数
			companyId :  getUrlVar('companyId')
		}

	}),

	grid = new Grid.Grid({
		render:'#grid',
		columns : columns,
		loadMask: true, //加载数据时显示屏蔽层
		forceFit:true,
		store: store,
		// 底部工具栏
		bbar:{
			// pagingBar:表明包含分页栏
			pagingBar:true
		}
	});

	//没有数据，处理分页栏
	if (!store.getTotalCount()) {
		$('#grid #totalPage').text("共 0 页");
		$('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	grid.render();
});


//添加图片
BUI.use('bui/overlay',function(Overlay){
	var dialog = new Overlay.Dialog({
		title:'添加图片',
		width:500,
		height:300,
		mask:false,
		buttons:[
		         {
		        	 text:'提交',
		        	 elCls : 'button button-primary',
		        	 handler : function(){
		        		 var actionUrl = $("#actionUrl").val();
		        		 if (actionUrl == undefined|| actionUrl == "") {
		        			 BUI.Message.Alert('actionUrl不能为空','info');
		        			 return false;
		        		 }
		        		 var companyImage = $("#companyImage").val();
		        		 if (companyImage == undefined|| companyImage == "") {
		        			 BUI.Message.Alert('没有选择图片','info');
		        			 return false;
		        		 }
		        		 $("#companyId").val(getUrlVar('companyId'));
		        		 $("#uploadImageform").submit();
		        		 this.close();
		        	 }
		         },{
		        	 text:'取消',
		        	 elCls : 'button',
		        	 handler : function(){
		        		 $("#actionUrl").val('');
		        		 $("#companyImage").val('');
		        		 $("#companyId").val('');
		        		 this.close();
		        	 }
		         }
		         ],

		         contentId:'uploadImageDiv'
	});
	$('#uploadImage').on('click',function () {
		dialog.show();
	});
});

//删除图片
function deleteImage(imageId){
	$.ajax({
		url : '/platform/images/deleteImage.json',
		dataType : "json",
		data : {
			imageId : imageId,
		},
		type : "POST",
		async : false,
		error : function(e) {
			BUI.Message.Alert('删除异常', 'error');
		},
		success : function(data) {
			if (data.code == true) {
				BUI.Message.Alert(data.info, 'info');
				setTimeout(function() {
					window.location.reload();
				}, 500);
			} else {
				BUI.Message.Alert(data.info, 'info');
			}
		}
	});
}
