$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '用户id',dataIndex :'id',sortable: false, width:40,elCls : 'center'},
       {title : '用户名',dataIndex :'userName',sortable: false, width:40,elCls : 'center'},
       {title : '手机号',dataIndex :'phone',sortable: false, width:60,elCls : 'center'},
       {title : '用户状态',dataIndex : 'statusText',sortable: false,width:20,elCls : 'center'},
       {title : '姓名',dataIndex : 'certName',sortable: false,width:40,elCls : 'center'},
       {title : '身份证号',dataIndex :'certNo',sortable: false, width:60,elCls : 'center'},
       {title : '公司名',dataIndex : 'companyName',sortable: false,width:60,elCls : 'center'},
       {title : '支付宝账号',dataIndex : 'alipayUserName',sortable: false,width:60,elCls : 'center'},
       { title: '操作', width: 200, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var updateUser = "";
				var delUser = "";
				var relPrivilege ='';
				var operateOpt = '';
				//超级管理员处理小贷公司管理员误操作问题，将删除后的用户释放
				if($.trim(obj.status) == "NORMAL"){
					delUser = '<a href="javascript:void(0)" class="grid-command userDelete">删除</a>';
					updateUser = '<a href="javascript:void(0)" class="grid-command userUpdate">编辑</a>';
					relPrivilege = '<a href="/platform/user/relRole.htm?userId='+obj.id+'" class="grid-command roleRelPrivilege">关联角色</a>';
					operateOpt = updateUser+"&nbsp;&nbsp;"+delUser+"&nbsp;&nbsp;"+relPrivilege;
				}else{
					operateOpt = '<a href="javascript:void(0)" class="grid-command userUpdate">编辑</a>';
				}
				return operateOpt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                userName:$("#userName").val(),
                phone:$("#phone").val(),
                companyId:$('#companyId').val(),
                status:$('#status').val(),
                alipayUserName:$('#alipayUserName').val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	
	
	
	//新增用户
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addPlatformUserform'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增用户',
	          width:700,
	          height:450,
	          //配置DOM容器的编号
	          contentId:'addPlatformUserDiv',
	          success:function () {
	        	  var alipayUserName = $("#a_alipayUserName").val();
	        	  var password = $("#password").val();
	        	  var certName = $("#certName").val();
	        	  var certNo = $("#certNo").val();
	        	  var phone = $("#a_phone").val();
	        	  var status = $('#a_status option:selected').val();
	        	  var email = $("#email").val();
	        	  var companyId =$('#a_companyId option:selected').val(); 
	        	  
	        	  
	        	  if(alipayUserName==undefined || alipayUserName==""){
			    		BUI.Message.Alert('支付宝账号必填','info');
			    		return false;
			      }
	        	  if(certName==undefined || certName==""){
			    		BUI.Message.Alert('姓名必填','info');
			    		return false;
			      }
	        	  if(certNo==undefined || certNo==""){
			    		BUI.Message.Alert('身份证号必填','info');
			    		return false;
			      }
	        	  if(phone==undefined || phone==""){
			    		BUI.Message.Alert('用户手机号必填','info');
			    		return false;
			      }
	        	  if(status==undefined || status==""){
			    		BUI.Message.Alert('用户状态必填','info');
			    		return false;
			      }
	        	  
			      $.ajax({
			    		url: 'addPlatformUserAjax.json',
			    		dataType:"json",
			    		data: {
			    			alipayUserName:alipayUserName,
			    			password:password,
			    			certName:certName,
			    			certNo:certNo,
			    			phone:phone,
			    			status:status,
			    			email:email,
			    			companyId:companyId
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else if(data.message=="isBind"){
			    		    	 BUI.Message.Alert('支付宝账号已被绑定','error');
			    		     }else{
			    		    	BUI.Message.Alert('新增用户失败','error'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addPlatformUser').on('click',function () {
            dialog.show();
          });   
         
        });	
	
	
  //用户批量导入
    BUI.use('bui/uploader',function (Uploader) {
        uploader = new Uploader.Uploader({
            render: '#batchAddUser',
            url: 'batchAddUserAjax.json',
            rules: {
                //文的类型
               ext: ['.csv','文件类型只能为{0}'],
                maxSize: [11264, '文件大小不能大于10M']
            }
        }).render();
        
        //上传成功时会触发
        uploader.on('success', function(ev){
            var result = ev.result;
                //BUI.Message.Show({
                //    msg : '上传成功',
                //    icon : 'success',
                //   width:200,
                //    buttons : [],
                //    autoHide : true,
                //    autoHideDelay : 1000
                //});
        })
        //上传成功时会触发
        uploader.on('error', function(ev){
            var result = ev.result;
            if(result.batchAddResult.success==true){
                BUI.Message.Show({
                    msg : '上传成功',
                    icon : 'success',
                    width:200,
                    buttons : [],
                    autoHide : true,
                    autoHideDelay : 1000
                });
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }else{
                    BUI.Message.Show({
                        msg : result.batchAddResult.message+" 请删除,重新上传！",
                        icon : 'error',
                        width:200,
                        buttons : [{ text:'关闭', elCls : 'button', handler : function(){ this.hide(); }}],
                        autoHide : false
                    });
                $(".defaultTheme .bui-queue-item .action").css("display","block");
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }
        });
    }); 
	
    
  //编辑用户信息
	grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        field = ev.field, //点击对应列的dataIndex
        target = $(ev.domTarget); //点击的元素
        var companyId = record.companyId;
        var status = record.status;
        var dataObject = bindData(companyId,status);
        
        
        //用户信息
        if(target.hasClass('userUpdate')){
        	var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*支付宝账号：</font></span><input type="text" name="b_alipayUserName" id="b_alipayUserName" value="'+record.alipayUserName+'" onchange="chkAlipayValue('+record.id+',this)" style="width:150px;"/>'+
        	'<span class="valid-text" style=" display:none" id="b_alipayUserNameErr">'+
        	'<span class="error"><span class="x-icon x-icon-mini x-icon-error">!</span><em>该支付宝账号已被绑定</em></span></span></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*姓名：</font></span><input type="text" name="b_certName" id="b_certName" value="'+record.certName+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*身份证号：</font> </span><input type="text" name="b_certNo" id="b_certNo" value="'+record.certNo+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;"><font color="#FF0000">*手机号：</font> </span><input type="text" name="b_phone" id="b_phone" value="'+record.phone+'" style="width:150px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">用户状态：</span><select name="b_status" id="b_status">'+dataObject[1]+'</select></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">所属公司：</span><select name="b_companyId" id="b_companyId">'+dataObject[0]+'</select></div>';
        	var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'编辑用户信息',
		        width:500,
		        height:450,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   var alipayUserName=$("#b_alipayUserName").val()?$("#b_alipayUserName").val():"";
	   		           var certName=$("#b_certName").val()?$("#b_certName").val():"";
	   		           var certNo=$("#b_certNo").val()?$("#b_certNo").val():"";
	   		           var phone=$("#b_phone").val()?$("#b_phone").val():"";
	   		           var b_companyId =$("#b_companyId").val()?$("#b_companyId").val():"";
	   		           var b_status =$("#b_status").val()?$("#b_status").val():"";
	   	        	   if(alipayUserName==undefined || alipayUserName==""){
	   	        		   BUI.Message.Alert('支付宝账户必填','info');
	   	        		   return false;
	   		      	   }

	   	        	   if(certName==undefined || certName==""){
	   		        	   BUI.Message.Alert('用户姓名必填','info');
	   		      		   return false;
	   		      	   }
	   		           if(certNo==undefined || certNo==""){
			    		BUI.Message.Alert('身份证号必填','info');
			    		return false;
	   		           }
	   		           if(phone==undefined || phone==""){
			    		BUI.Message.Alert('用户手机号必填','info');
			    		return false;
	   		           }
                	   //do some thing
	            	   $.ajax({
	   						url: 'addPlatformUserAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	alipayUserName:alipayUserName,
	   			            	certName:certName,
	   			            	certNo:certNo,
	   			            	phone:phone,
	   			            	companyId:b_companyId,
	   			            	status:b_status
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('修改用户成功','success');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else if(data.message=="isBind"){
						    		    	BUI.Message.Alert('该支付宝账号已被绑定','error'); 
					    		     }else{
					    		    	BUI.Message.Alert('修改用户异常','error'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
    });
	
	
	function bindData(companyId,status) {
		var dataOption = "";
		var dataStatus = "";
		 $.ajax({
              type:"post",
              url: "/platform/user/initDict.json",                   
              dataType: 'json',
              async:false,
              success: function(data){
                  if(data){
                	  dataOption ="<option value=\"\">---请选择所属公司---</option>";
                	  dataStatus = "<option value=\"\">---请选择用户状态---</option>";
                      $.each(data.companyList,function(i,item){
                    	  if($.trim(companyId) == $.trim(item.id)){
                    		  dataOption +="<option value='"+item.id+"' selected>"+item.companyName+"</option>";
                    	  }else{
                    		  dataOption +="<option value='"+item.id+"'>"+item.companyName+"</option>";
                    	  }
                    	  
                    });
                	
                	  $.each(data.userStatusList,function(i,item){
                    	  if($.trim(status) == $.trim(item.code)){
                    		  dataStatus +="<option value='"+item.code+"' selected>"+item.desc+"</option>";
                    	  }else{
                    		  dataStatus +="<option value='"+item.code+"'>"+item.desc+"</option>";
                    	  }
                    	  
                    });
                  }
               }
       });    
		var array = new Array();
		array[0] = dataOption;
		array[1] = dataStatus;
		return array;
	}
	
	function MathRand(n) 
	{ 
		var Num=""; 
		for(var i=0;i<6;i++) {
			Num+=Math.floor(Math.random()*10); 
		} 
		return Num;
	}
	//密码重置passwordReset
	 grid.on('cellclick',function(ev) {
	    	var obj=this;
	        var record = ev.record, //点击行的记录
	        	field = ev.field, //点击对应列的dataIndex
	        	target = $(ev.domTarget); //点击的元素
	        
	        var id = record.id;
	        var rand = MathRand(6);
	        var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>确定要重置密码吗？重置后密码为：'+rand;
	        if(target.hasClass('passwordReset')){
	        	var Overlay = BUI.Overlay;
	        	var dialog = new Overlay.Dialog({
			    	title:'重置密码',
			        width:300,
			        height:200,
			        bodyContent:msg,
			        buttons:[{
	                   text:'确定',
	                   elCls : 'button button-primary',
	                   handler : function(){
	                	   var obj=this;
	                	   var id = $("#id").val()?$("#id").val():"";
		            	   $.ajax({
		   						url: '/platform/password/resetPassword.json',
		   			            dataType:"json",
		   			            data: {
		   			            	id:id,
		   			            	password:rand
		   			            },
		   			            type: "POST",
		   			            error: function(e){
		   			            	BUI.Message.Alert('重置密码失败','error');
		   				            obj.destroy();
		   			            },
		   			            success: function(data) {
		   			             if(data.message=="success"){
										BUI.Message.Alert('重置密码成功','info');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('重置密码失败','info'); 
					    		     }
		   				            obj.destroy();
		   			            }                   
		   					});
	               	   }
	                },{
	                   text:'取消',
	                   elCls : 'button',
	                   handler : function(){
	                	   this.destroy();
	                   }
	                }]
			    });
	        	dialog.show();
	        }
	        
	    });
	 
	
	 //删除用户
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>确定要删除该用户吗？删除后，将删除该用户相关信息！';
        if(target.hasClass('userDelete')){
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除用户',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   //do some thing
	            	   $.ajax({
	   						url: 'deleteUserAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
	   			             if(data.message=="success"){
									BUI.Message.Alert('删除成功','info');
					    			setTimeout(function(){
						            	window.location.reload();
						            },2000);
				    		     }else{
				    		    	BUI.Message.Alert('删除失败','info'); 
				    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
	
	});

function chkAlipayValue(userId,alipayUserName){
	var alipayUserNameVal = alipayUserName.value;
	var msgId = alipayUserName.id + "Err";
	if(alipayUserNameVal.length == 0 || alipayUserNameVal == ''){
		return false;
	}
	
	$.ajax({
		url: 'checkAlipayUserNameUnique.json',
		dataType:"json",
		data: {
			id:userId,
			alipayUserName:alipayUserNameVal
		},
		type: "POST",
		error: function(e){
			$('#'+msgId).show();
			BUI.Message.Alert('支付宝账号唯一性校验失败','error');
			return false;
		},
		success: function(data) {
			if(data.message == "success"){
				//校验成功不做处理
				$('#'+msgId).hide();
			}else if(data.message == "NotUnique"){
				$('#'+msgId).show();
				return false;
			}else{
				BUI.Message.Alert('支付宝账号唯一性校验失败','info');
				return false;
			}
		}                   
	});
	
}
