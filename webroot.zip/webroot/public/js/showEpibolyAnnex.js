$(function(){
	BUI.use(['bui/imgview','bui/overlay'],function(ImgView,Overlay){  
		var fileNam="";    
		var picArr=[];    
		var dialog = new Overlay.Dialog({
			id:"showPic",
			title:'图片查看器',
			width:900,
			height:580,
			mask:false,
			buttons:[],
			closeAction:'hide',
			bodyContent:'<div><div class="image_tree"> </div> <div id="imgviewWrap"></div></div>',
			listeners:{
				closeclick:function(){
					 if(imgView) {
						 imgView.hide();
					 }
				}
			}	
		 });
		var  imgView = new ImgView.ImgView({
							render: "#imgviewWrap",
							width: 640,
							height: 480,
							imgList: picArr,
							imgNum: 2, // 默认取第几张图片，默认为0，取第一张
							autoRender: false // 是否自动渲染,默认为false
		}); 
		$("#ScanImage").click(function(){
			 $(".image_tree").html("");    
                    	  var imageTreeJson=picTypeJson;
                            var strContent = [];
                            $.each(imageTreeJson,function(i, item) {
                                strContent.push('<div class="parent_first"><span class="parent_text"  data=' + item.value + '><span class="x-caret x-caret-left"></span><b>' + item.text + '</b></span><ul class="second_child">');
                                if (item.selects && item.selects.length > 0) {
                                    var str_img="";
                                    var third_tree="";
                                   $.each(item.selects,function(j, child) {  
                                       str_img="";
                                       third_tree="";
                                      if(child.dataFileList){
                                          if(child.value=="bankStatementPic" || child.value=="paperFlowPic"){
                                              var strArrBankName=[];
                                              var str_third_img="";
                                              $.each(child.dataFileList,function(k,imgitem){
                                                  if(strArrBankName.indexOf(imgitem.itemName)<0){
                                                      if($.trim(imgitem.itemName)!=""){
                                                          strArrBankName.push(imgitem.itemName);
                                                      }
                                                  }
                                                  str_img+=imgitem.httpUrl+"||";
                                              });
                                              third_tree="<dl class='bankClass' style='width:120px;display:none;padding-left:20px;padding-left:20px !important; margin-bottom:0px;'><dt>";
                                              var count=0;
                                              $.each(strArrBankName,function(i,bankName){
                                                  str_third_img="";
                                                  count=0;
                                                  $.each(child.dataFileList,function(k,thirdItem){
                                                      if(thirdItem.itemName==bankName){
                                                          str_third_img+=thirdItem.httpUrl+"||";
                                                          count++;
                                                      }
                                                  });
                                                  third_tree+='<dd data="'+str_third_img+'">'+bankName+'('+count+')</dd>';
                                              });
                                              third_tree+="</dt></dl>";

                                          }
                                          else{
                                              $.each(child.dataFileList,function(k,imgitem){
                                                  str_img+=imgitem.httpUrl+"||";
                                              });
                                              third_tree="";
                                          }
                                      }
                                      if(third_tree==""){
                                          strContent.push('<li data="' +str_img + '">' + child.text+ third_tree+ '</li>');
                                      }
                                       else{
                                          strContent.push('<li data="' +str_img + '"><span class="x-caret x-caret-left" style="margin-right:5px;"></span>' + child.text+ third_tree+ '</li>');
                                      }
                                    });
                                }
                                strContent.push('</ul></div>');
                            });
                            dialog.show();
							watermark1({id:"imgviewWrap",watermark_txt: realName})//传入动态水印内容
                            $(".image_tree").append(strContent.join(''));        
                           
	                         if(imgView){                        
	                                imgView.show();
	                         }                                                      
                            $(".parent_text").toggle(function(e) {
                                $(this).next().show();
                                $(this).next().children().find("ul").show();
                                $(this).find(".x-caret").removeClass("x-caret-left");
                                $(this).find(".x-caret").addClass("x-caret-down");                              
                            },
                            function(e) {
                                $(this).next().hide();
                                $(this).next().children().find("ul").hide();
                                $(this).find(".x-caret").removeClass("x-caret-down");
                                $(this).find(".x-caret").addClass("x-caret-left");                       
                            });
                            $(".second_child li ").on("click",function(evt) {
                                var str = $(this).attr("data");
                                picArr=[];
                                var c_dl=$(this).children()[1];
                                var c_span= $(this).children()[0];
                                if(c_dl){
                                    if($(c_dl).css("display")=="none"){
                                        $(c_span).removeClass("x-caret-left");
                                        $(c_span).addClass("x-caret-down");
                                        $(c_dl).css("display","block");
                                    }else{
                                        $(c_span).removeClass("x-caret-down");
                                        $(c_span).addClass("x-caret-left");
                                        $(c_dl).css("display","none");
                                    }
                                }
                                if (str.length > 0) {
                                    var strArr = str.split('||');                            
                                    if (strArr.length > 0) {
                                    $.each(strArr,function(i, item) {
                                      var picObj = {
                                            src: "123",
                                            miniSrc: "456"
                                        };
                                        picObj.src = item;
                                        picObj.miniSrc = item;
                                        picArr.push(picObj)
                                    });
                                 }
                                 picArr.pop();
                                 imgView.show();
                                 imgView.set('imgList', picArr);                                               
                               } else{
                                 imgView.hide();
                              }
                            });
                            $(".second_child dd").on("click",function(evt){
                                var str = $(this).attr("data");
                                console.log(str);
                                picArr=[];
                                if (str.length > 0) {
                                    var strArr = str.split('||');
                                    if (strArr.length > 0) {
                                        $.each(strArr,function(i, item) {
                                            var picObj = {
                                                src: "123",
                                                miniSrc: "456"
                                            };
                                            picObj.src = item;
                                            picObj.miniSrc = item;
                                            picArr.push(picObj)
                                        });
                                    }
                                    picArr.pop();
                                    imgView.show();
                                    imgView.set('imgList', picArr);
                                } else{
                                    imgView.hide();
                                }
                                    var e =evt ? evt : window.event;
                                    if (e.stopPropagation) {
                                        e.stopPropagation();
                                    }
                                    else {
                                        e.cancelBubble = true;
                                     }
                                });
		 }); 
	});
})