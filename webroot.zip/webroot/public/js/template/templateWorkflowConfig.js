$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '字段id',dataIndex :'id',sortable: false, width:20,elCls : 'center'},
       {title : 'workflowType',dataIndex :'workflowType',sortable: false, width:40,elCls : 'center'},
       {title : 'bizType',dataIndex : 'bizType',sortable: false,width:40,elCls : 'center'},
       {title : 'configSeqNo',dataIndex : 'configSeqNo',sortable: false,width:20,elCls : 'center'},
       {title : '是否跳过品控',dataIndex :'validateQualityControl',sortable: false, width:20,elCls : 'center'},
       {title: '操作', width: 120, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var configDeleteApt = "<a href='javascript:void(0)' class='grid-command deleteWoukflowConfig'>删除模板定义</a>";
				return configDeleteApt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                fieldCode:$("#bizType").val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	//新增模块
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addWorkflowConfigForm'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增模板定义',
	          width:450,
	          height:350,
	          //配置DOM容器的编号
	          contentId:'addWorkflowConfigDiv',
	          success:function () {
	        	  var workflowType = $("#workflowType").val();
	        	  var bizType = $("#a_bizType").val();
	        	  var validateQualityControl = $('#validateQualityControl option:selected').val();
	        	  var configSeqNo = $("#configSeqNo").val();
	        	  
	        	  if(workflowType==undefined || workflowType==""){
			    		BUI.Message.Alert('流程类型必填','info');
			    		return false;
			      }
	        	  if(bizType==undefined || bizType==""){
			    		BUI.Message.Alert('业务类型必填','info');
			    		return false;
			      }
	        	  if(configSeqNo==undefined || configSeqNo==""){
			    		BUI.Message.Alert('配置序列号必填','info');
			    		return false;
			      }
			      $.ajax({
			    		url: 'addWorkflowConfig.json',
			    		dataType:"json",
			    		data: {
			    			workflowType:workflowType?workflowType:"",
			    			bizType:bizType?bizType:"",
			    			validateQualityControl:validateQualityControl?validateQualityControl:"",
			    			configSeqNo:configSeqNo?configSeqNo:""
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','success');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else if(data.message=="fail"){
			    		    	 BUI.Message.Alert('新增模板定义失败','error'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addWorkflowConfig').on('click',function () {
            dialog.show();
          });   
         
        });	
 
    //删除数据
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        var msg = '<input type="hidden" name="b_id" id="b_id" value="'+record.id+'" style="width:100px;"/>确定要删除该模板定义吗？';
        if(target.hasClass('deleteWoukflowConfig')){
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除模板定义',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#b_id").val()?$("#b_id").val():"";
                	   //do some thing
	            	   $.ajax({
	   						url: 'deleteworkflowConfigAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
	   			             if(data.message=="success"){
									BUI.Message.Alert('删除成功','success');
					    			setTimeout(function(){
						            	window.location.reload();
						            },2000);
				    		     }else{
				    		    	BUI.Message.Alert('删除失败','error'); 
				    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
    
});