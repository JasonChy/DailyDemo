$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '模块id',dataIndex :'id',sortable: false, width:20,elCls : 'center'},
       {title : '模块名称',dataIndex :'moduleName',sortable: false, width:40,elCls : 'center'},
       {title : '模块编码',dataIndex : 'moduleCode',sortable: false,width:40,elCls : 'center'},
       {title : '模板order',dataIndex :'moduleOrderNo',sortable: false, width:20,elCls : 'center'},
       {title : '模块序列号',dataIndex : 'moduleSeqNo',sortable: false,width:20,elCls : 'center'},
       {title : '模块attrMap',dataIndex : 'attrMap',sortable: false,width:100,elCls : 'center'},
       {title: '操作', width: 120, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var moduleId = obj.id;
				var templateId = obj.templateId;
				var formUpdate = '<a href="javascript:void(0)" class="grid-command formUpdate">编辑表单模块</a>';
				var deleteApt = "<a href='javascript:void(0)' class='grid-command deleteModule'>删除模块</a>";
				var moduleFieldOpt =  '<a href="/template/field/moduleFieldPage.htm?moduleId='+moduleId+'&templateId='+templateId+'" class="grid-command moduleFieldOpt">表单业务字段</a>';
				var operateEvt= formUpdate+"&nbsp;&nbsp;"+deleteApt+"&nbsp;&nbsp;"+moduleFieldOpt;
				return operateEvt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                moduleCode:$("#moduleCode").val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	//新增模块
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addform'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增模块',
	          width:700,
	          height:600,
	          //配置DOM容器的编号
	          contentId:'addFormModuleDiv',
	          success:function () {
	        	  var moduleName = $("#moduleName").val();
	        	  var moduleCode = $("#a_moduleCode").val();
	        	  var moduleDesc = $("#moduleDesc").val();
	        	  var moduleOrderNo = $("#moduleOrderNo").val();
	        	  var moduleSeqNo = $("#moduleSeqNo").val();
	        	  var a_templateId = $("#a_templateId").val();
	        	  var moduleType = $('#moduleType option:selected').val();
	        	  var isShowAddBtn =$('#isShowAddBtn option:selected').val(); 
	        	  var isReadOnly =$('#isReadOnly option:selected').val();
	        	  var isShoot = $('#isShoot option:selected').val();
	        	  var attrMap = $('#attrMap').val();
	        	  var moduleValue = $("#moduleValue").val();
	        	  
	        	  if(moduleName==undefined || moduleName==""){
			    		BUI.Message.Alert('模块名称必填','info');
			    		return false;
			      }
	        	  if(moduleCode==undefined || moduleCode==""){
			    		BUI.Message.Alert('模块Code必填','info');
			    		return false;
			      }
	        	  if(moduleOrderNo==undefined || moduleOrderNo==""){
			    		BUI.Message.Alert('模块顺序必填','info');
			    		return false;
			      }
	        	  if(moduleType==undefined || moduleType==""){
			    		BUI.Message.Alert('模块类型必填','info');
			    		return false;
			      }
	        	  if(isShowAddBtn==undefined || isShowAddBtn==""){
			    		BUI.Message.Alert('是否显示AddBtn必填','info');
			    		return false;
			      }
	        	  if(isShoot==undefined || isShoot==""){
			    		BUI.Message.Alert('是否是拍照项必填','info');
			    		return false;
			      }
			      $.ajax({
			    		url: 'addFormModuleAjax.json',
			    		dataType:"json",
			    		data: {
			    			moduleName:moduleName?moduleName:"",
			    			moduleCode:moduleCode?moduleCode:"",
			    			moduleDesc:moduleDesc?moduleDesc:"",
			    			moduleOrderNo:moduleOrderNo?moduleOrderNo:"",
			    			moduleSeqNo:moduleSeqNo?moduleSeqNo:"",
			    			moduleValue:moduleValue?moduleValue:"",
			    			templateId:a_templateId?a_templateId:"",
			    			moduleType:moduleType?moduleType:"",
			    			isShowAddBtn:isShowAddBtn?isShowAddBtn:"",
			    			isReadOnly:isReadOnly?isReadOnly:"",
			    			isShoot:isShoot?isShoot:"",
			    			attrMap:attrMap?attrMap:"",
			    			moduleValue:moduleValue?moduleValue:""
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','success');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else if(data.message=="already"){
			    		    	 BUI.Message.Alert('moduleCode在该模板下已存在，请修改','warning');
			    		     }else if(data.message=="false"){
			    		    	 BUI.Message.Alert('新增模块数据失败','error'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addFormModule').on('click',function () {
            dialog.show();
          });   
         
        });	
    //编辑模块
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        //编辑渠道商
        if(target.hasClass('formUpdate')){
        	var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块名称：</span><input type="text" name="b_moduleName" id="b_moduleName" value="'+record.moduleName+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块Code：</span><span name="b_moduleCode" id="b_moduleCode">'+record.moduleCode+'</span></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块描述： </span><input type="text" name="b_moduleDesc" id="b_moduleDesc" value="'+record.moduleDesc+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块顺序：</span><input type="text" name="b_moduleOrderNo" id="b_moduleOrderNo" value="'+record.moduleOrderNo+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">moduleType：</span><input type="text" name="b_moduleType" id="b_moduleType" value="'+record.moduleType+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">是否AddBtn：</span><input type="text" name="b_isShowAddBtn" id="b_isShowAddBtn" value="'+record.isShowAddBtn+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">是否isShoot：</span><input type="text" name="b_isShoot" id="b_isShoot" value="'+record.isShoot+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块备注：</span><textarea id="b_moduleValue" name="b_moduleValue" style="width:300px;">'+record.moduleValue+'</textarea></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">模块attrMap：</span><textarea id="b_attrMap" name="b_attrMap"  style="width:300px;">'+record.attrMap+'</textarea></div>';
			var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'修改模块',
		        width:600,
		        height:550,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   var moduleName=$("#b_moduleName").val()?$("#b_moduleName").val():"";
   		        	   var moduleDesc=$("#b_moduleDesc").val()?$("#b_moduleDesc").val():"";
   		        	   var moduleSeqNo=$("#b_moduleSeqNo").val()?$("#b_moduleSeqNo").val():"";
   		        	   var moduleOrderNo=$("#b_moduleOrderNo").val()?$("#b_moduleOrderNo").val():"";
   		        	   var moduleValue=$("#b_moduleValue").val()?$("#b_moduleValue").val():"";
   		        	   var moduleType =$("#b_moduleType").val()?$("#b_moduleType").val():"";
   		        	   var isShowAddBtn =$("#b_isShowAddBtn").val()?$("#b_isShowAddBtn").val():"";
   		        	   var isShoot =$("#b_isShoot").val()?$("#b_isShoot").val():"";
   		        	   var attrMap =$("#b_attrMap").val()?$("#b_attrMap").val():"";
   		        	   var templateId = record.templateId;
	   	        	   if(moduleName==undefined || moduleName==""){
	   	        		   BUI.Message.Alert('模块名称必填','info');
	   	        		   return false;
	   		      	   }
	   		           
                	   //do some thing
	            	   $.ajax({
	   						url: 'addFormModuleAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	moduleName:moduleName,
	   			            	moduleDesc:moduleDesc,
	   			            	moduleSeqNo:moduleSeqNo,
	   			            	moduleOrderNo:moduleOrderNo,
	   			            	moduleValue:moduleValue,
	   			            	moduleType:moduleType,
	   			            	isShowAddBtn:isShowAddBtn,
	   			            	isShoot:isShoot,
	   			            	attrMap:attrMap,
	   			            	templateId:templateId
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('修改成功','success');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('修改失败','error'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
	
	});
    //删除数据
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        console.log(record.id);
        var msg = '<input type="hidden" name="c_id" id="c_id" value="'+record.id+'" style="width:100px;"/>确定要删除该模块吗？删除后，将删除该模块下面的业务字段及其关联信息！';
        if(target.hasClass('deleteModule')){
        	//var msg ='确定要删除该模块吗？删除后，将删除该模块下面的业务字段及其关联信息！';
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除模块',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#c_id").val()?$("#c_id").val():"";
	   		           
                	   //do some thing
	            	   $.ajax({
	   						url: 'deleteFormModuleAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('删除成功','success');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('删除失败','error'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
    
});