$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '字段id',dataIndex :'id',sortable: false, width:20,elCls : 'center'},
       {title : '字段名称',dataIndex :'fieldName',sortable: false, width:40,elCls : 'center'},
       {title : '字段编码',dataIndex : 'fieldCode',sortable: false,width:40,elCls : 'center'},
       {title : '字段order',dataIndex :'fieldOrderNo',sortable: false, width:20,elCls : 'center'},
       {title : '单位',dataIndex : 'fieldValueUnit',sortable: false,width:20,elCls : 'center'},
       {title : '控件类型',dataIndex : 'fieldInputType',sortable: false,width:20,elCls : 'center'},
       {title : '验证规则',dataIndex : 'fieldValidationRule',sortable: false,width:100,elCls : 'center'},
       {title: '操作', width: 120, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var fieldUpdate = '<a href="javascript:void(0)" class="grid-command fieldUpdate">编辑业务字段</a>';
				var fieldDeleteApt = "<a href='javascript:void(0)' class='grid-command deleteModuleFeild'>删除字段</a>";
				var operateEvt= fieldUpdate+"&nbsp;&nbsp;"+fieldDeleteApt;
				return operateEvt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                fieldCode:$("#fieldCode").val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	//新增模块
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addModuleFieldform'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增业务字段',
	          width:700,
	          height:680,
	          //配置DOM容器的编号
	          contentId:'addModuleFieldDiv',
	          success:function () {
	        	  var fieldName = $("#fieldName").val();
	        	  var fieldCode = $("#a_fieldCode").val();
	        	  var fieldDesc = $("#fieldDesc").val();
	        	  var fieldOrderNo = $("#fieldOrderNo").val();
	        	  var fieldValueUnit = $("#fieldValueUnit").val();
	        	  var fieldValue = $("#fieldValue").val();
	        	  var shootTextTip = $("#shootTextTip").val();
	        	  var fieldControlRule = $("#fieldControlRule").val();
	        	  var fieldValidationRule = $("#fieldValidationRule").val();
	        	  var shootSubCategory = $("#shootSubCategory").val();
	        	  var fieldInputType = $('#fieldInputType option:selected').val();
	        	  var fieldTip = $("#fieldTip").val();
	        	  var a_moduleId = $("#a_moduleId").val();
	        	  var templateId = $("#templateId").val();
	        	  alert(templateId);
	        	  
	        	  if(fieldName==undefined || fieldName==""){
			    		BUI.Message.Alert('字段名称必填','info');
			    		return false;
			      }
	        	  if(fieldCode==undefined || fieldCode==""){
			    		BUI.Message.Alert('字段Code必填','info');
			    		return false;
			      }
	        	  if(fieldOrderNo==undefined || fieldOrderNo==""){
			    		BUI.Message.Alert('字段顺序必填','info');
			    		return false;
			      }
			      $.ajax({
			    		url: 'addModuleFieldAjax.json',
			    		dataType:"json",
			    		data: {
			    			fieldName:fieldName?fieldName:"",
			    			fieldCode:fieldCode?fieldCode:"",
			    			fieldDesc:fieldDesc?fieldDesc:"",
			    			fieldOrderNo:fieldOrderNo?fieldOrderNo:"",
			    			fieldValueUnit:fieldValueUnit?fieldValueUnit:"",
			    			fieldValue:fieldValue?fieldValue:"",
			    			shootTextTip:shootTextTip?shootTextTip:"",
			    			fieldControlRule:fieldControlRule?fieldControlRule:"",
			    			fieldValidationRule:fieldValidationRule?fieldValidationRule:"",
			    			shootSubCategory:shootSubCategory?shootSubCategory:"",
			    			fieldInputType:fieldInputType?fieldInputType:"",
			    			fieldTip:fieldTip?fieldInputType:"",
			    			moduleId:a_moduleId?a_moduleId:"",
			    			templateId:templateId?templateId:""
			    			
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','success');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else if(data.message=="already"){
			    		    	 BUI.Message.Alert('fieldCode在该模板下已存在，请修改','warning');
			    		     }else if(data.message=="fail"){
			    		    	 BUI.Message.Alert('新增业务字段失败','error'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addModuleField').on('click',function () {
            dialog.show();
          });   
         
        });	
    //编辑模块
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        //编辑渠道商
        if(target.hasClass('fieldUpdate')){
        	var msg = '<input type="hidden" name="id" id="id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">字段名称：</span><input type="text" name="b_fieldName" id="b_fieldName" value="'+record.fieldName+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">字段Code：</span><input type="text" name="b_fieldCode" id="b_fieldCode"value="'+record.fieldCode+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">字段描述： </span><input type="text" name="b_fieldDesc" id="b_fieldDesc" value="'+record.fieldDesc+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">字段顺序：</span><input type="text" name="b_fieldOrderNo" id="b_fieldOrderNo" value="'+record.fieldOrderNo+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">控件Type：</span><input type="text" name="b_fieldInputType" id="b_fieldInputType" value="'+record.fieldInputType+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">单位unit：</span><input type="text" name="b_fieldValueUnit" id="b_fieldValueUnit" value="'+record.fieldValueUnit+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">照片分类：</span><input type="text" name="b_shootSubCategory" id="b_shootSubCategory" value="'+record.shootSubCategory+'" style="width:200px;"/></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">字段值：</span><textarea id="b_fieldValue" name="b_fieldValue"  style="width:400px;">'+record.fieldValue+'</textarea></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">拍摄提示文案：</span><textarea id="b_shootTextTip" name="b_shootTextTip"  style="width:400px;">'+record.shootTextTip+'</textarea></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">提示信息：</span><textarea  id="b_fieldTip" name="b_fieldTip" style="width:400px;"/>'+record.fieldTip+'</textarea></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">验证规则：</span><textarea id="b_fieldValidationRule" name="b_fieldValidationRule" style="width:400px;">'+record.fieldValidationRule+'</textarea></div>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">控制规则：</span><textarea id="b_fieldControlRule" name="b_fieldControlRule" style="width:400px;">'+record.fieldControlRule+'</textarea></div>';
			var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'修改业务字段',
		        width:700,
		        height:750,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#id").val()?$("#id").val():"";
                	   var fieldName=$("#b_fieldName").val()?$("#b_fieldName").val():"";
   		        	   var fieldCode=$("#b_fieldCode").val()?$("#b_fieldCode").val():"";
   		        	   var fieldDesc=$("#b_fieldDesc").val()?$("#b_fieldDesc").val():"";
   		        	   var fieldOrderNo=$("#b_fieldOrderNo").val()?$("#b_fieldOrderNo").val():"";
   		        	   var fieldInputType=$("#b_fieldInputType").val()?$("#b_fieldInputType").val():"";
   		        	   var fieldValueUnit =$("#b_fieldValueUnit").val()?$("#b_fieldValueUnit").val():"";
   		        	   var fieldValue =$("#b_fieldValue").val()?$("#b_fieldValue").val():"";
   		        	   var shootSubCategory =$("#b_shootSubCategory").val()?$("#b_shootSubCategory").val():"";
   		        	   var shootTextTip =$("#b_shootTextTip").val()?$("#b_shootTextTip").val():"";
   		        	   var fieldTip =$("#b_fieldTip").val()?$("#b_fieldTip").val():"";
   		        	   var fieldValidationRule =$("#b_fieldValidationRule").val()?$("#b_fieldValidationRule").val():"";
   		        	   var fieldControlRule =$("#b_fieldControlRule").val()?$("#b_fieldControlRule").val():"";
   		        	   var templateId = record.templateId;
   		        	 
   		        	   alert(fieldCode);
	   	        	   if(fieldName==undefined || fieldName==""){
	   	        		   BUI.Message.Alert('字段名称必填','info');
	   	        		   return false;
	   		      	   }
	   		           
                	   //do some thing
	            	   $.ajax({
	   						url: 'addModuleFieldAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	fieldName:fieldName,
	   			            	fieldCode:fieldCode,
	   			            	fieldDesc:fieldDesc,
	   			            	fieldOrderNo:fieldOrderNo,
	   			            	fieldInputType:fieldInputType,
	   			            	fieldValueUnit:fieldValueUnit,
	   			            	fieldValue:fieldValue,
	   			            	shootSubCategory:shootSubCategory,
	   			            	shootTextTip:shootTextTip,
	   			            	fieldTip:fieldTip,
	   			            	fieldValidationRule:fieldValidationRule,
	   			            	fieldControlRule:fieldControlRule,
	   			            	templateId:templateId
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('修改成功','success');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('修改失败','error'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
	
	});
    //删除数据
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        var msg = '<input type="hidden" name="c_id" id="c_id" value="'+record.id+'" style="width:100px;"/>确定要删除该业务字段吗？';
        if(target.hasClass('deleteModuleFeild')){
        	//var msg ='确定要删除该模块吗？删除后，将删除该模块下面的业务字段及其关联信息！';
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除字段',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#c_id").val()?$("#c_id").val():"";
                	   var templateId = record.templateId;
                	   var moduleId = record.moduleId;
                	   //do some thing
	            	   $.ajax({
	   						url: 'deleteModuleFieldAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	moduleId:moduleId,
	   			            	templateId:templateId
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
	   			             if(data.message=="success"){
									BUI.Message.Alert('删除成功','success');
					    			setTimeout(function(){
						            	window.location.reload();
						            },2000);
				    		     }else{
				    		    	BUI.Message.Alert('删除失败','error'); 
				    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
    
});