$(function(){
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '模板id',dataIndex :'id',sortable: false, width:80,elCls : 'center'},
       {title : '模板名称',dataIndex :'templateName',sortable: false, width:80,elCls : 'center'},
       {title : '模板编码',dataIndex : 'templateCode',sortable: false,width:40,elCls : 'center'},
       {title : '模板版本',dataIndex :'templateVersion',sortable: false, width:20,elCls : 'center'},
       {title : '客户端最低版本',dataIndex : 'appVersionMin',sortable: false,width:20,elCls : 'center'},
       {title : '客户端最高版本',dataIndex : 'appVersionMax',sortable: false,width:20,elCls : 'center'},
       { title: '操作', width: 120, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var templateId = obj.id;
				var templateUpgrade = '<a href="javascript:void(0)" class="grid-command templateUpgrade">模板升级</a>';
				var formModuleOpt =  '<a href="/template/config/formModulePage.htm?templateId='+templateId+'" class="grid-command formModuleOpt">表单字段</a>';
				var copyTemplate = '<a href="javascript:void(0)" class="grid-command copyTemplateOpt">克隆模板</a>';
				var delTemplate = '<a href="javascript:void(0)" class="grid-command delTemplateOpt">删除模板</a>';
				var operateEvt= templateUpgrade+"&nbsp;&nbsp;"+formModuleOpt+"&nbsp;&nbsp;"+copyTemplate+"&nbsp;&nbsp;"+delTemplate;
				return operateEvt;
			}
		} 
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0,
                templateCode:$("#templateCode").val()
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});
	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		  var obj = form.serializeToObject();
		 // obj.start = 0; //返回第一页
		  var page=$('#grid .bui-pb-page').val();                        
		  obj.pageIndex = page-1;
		  store.load(obj);
		  return false;
	});
	
	
	
	
	
	
	//新增模板
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#deployTemplateForm'
        }).render();
        var dialog = new Overlay.Dialog({
	          title:'新增模板',
	          width:700,
	          height:600,
	          //配置DOM容器的编号
	          contentId:'addTemplateDiv',
	          success:function () {
	        	  var templateName = $("#templateName").val();
	        	  var templateCode = $("#a_templateCode").val();
	        	  var templateVersion = $("#templateVersion").val();
	        	  var appVersionMin = $("#appVersionMin").val();
	        	  //var templateType = $('#templateType option:selected').val();
	        	  var configSeqNo = $('#configSeqNo').val();
	        	  var appVersionMax = $("#appVersionMax").val();
	        	  
	        	  
	        	  if(templateCode==undefined || templateCode==""){
			    		BUI.Message.Alert('模板编码必填','info');
			    		return false;
			      }
	        	  if(templateVersion==undefined || templateVersion==""){
			    		BUI.Message.Alert('模板版本必填','info');
			    		return false;
			      }
	        	  if(appVersionMin==undefined || appVersionMin==""){
			    		BUI.Message.Alert('兼容最小版本必填','info');
			    		return false;
			      }
	        	  if(appVersionMax==undefined || appVersionMax==""){
			    		BUI.Message.Alert('兼容最高版本必填','info');
			    		return false;
			      }
	        	  
			      $.ajax({
			    		url: 'deployTemplate.json',
			    		dataType:"json",
			    		data: {
			    			templateName:templateName?templateName:"",
			    			templateCode:templateCode?templateCode:"",
			    			templateVersion:templateVersion?templateVersion:"",
			    			configSeqNo:configSeqNo?configSeqNo:"",
			    			appVersionMin:appVersionMin?appVersionMin:"",
			    			appVersionMax:appVersionMax?appVersionMin:""
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增模板失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.message=="success"){
								BUI.Message.Alert('新增成功','info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else{
			    		    	BUI.Message.Alert('新增模板失败','info'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addTemplate').on('click',function () {
            dialog.show();
          });   
         
        });	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 //删除数据
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        
        var id = record.id;
        var msg = '<input type="hidden" name="a_id" id="a_id" value="'+record.id+'" style="width:100px;"/>确定要删除该模板吗？';
        if(target.hasClass('delTemplateOpt')){
        	//var msg ='确定要删除该模块吗？删除后，将删除该模块下面的业务字段及其关联信息！';
        	var Overlay = BUI.Overlay;
        	var dialog = new Overlay.Dialog({
		    	title:'删除模板',
		        width:300,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#a_id").val()?$("#a_id").val():"";
                	   var templateId = record.templateId;
                	   var moduleId = record.moduleId;
                	   //do some thing
	            	   $.ajax({
	   						url: 'deleteTemplateAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('删除失败','error');
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
	   			             if(data.message=="success"){
									BUI.Message.Alert('删除成功','info');
					    			setTimeout(function(){
						            	window.location.reload();
						            },2000);
				    		     }else{
				    		    	BUI.Message.Alert('删除失败','info'); 
				    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
        	dialog.show();
        }
        
    });
    
	//克隆模板
	grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        field = ev.field, //点击对应列的dataIndex
        target = $(ev.domTarget); //点击的元素
       
        //模板小版本升级
        if(target.hasClass('copyTemplateOpt')){
        	var msg = '<input type="hidden" name="b_id" id="b_id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板名称：</span><input type="text" name="b_templateName" id="b_templateName" value="'+record.templateName+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板编码：</span><input type="text" name="b_templateCode" id="b_templateCode" value="'+record.templateCode+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板版本号：</span><input type="text" name="b_templateVersion" id="b_templateVersion" value="'+record.templateVersion+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">APP最低版本： </span><input type="text" name="b_appVersionMin" id="b_appVersionMin" value="'+record.appVersionMin+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">APP最高版本： </span><input type="text" name="b_appVersionMax" id="b_appVersionMax" value="'+record.appVersionMax+'" style="width:150px;"/></div>';
			var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'克隆模板',
		        width:500,
		        height:300,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#b_id").val()?$("#b_id").val():"";
                	   var templateName = $("#b_templateName").val()?$("#b_templateName").val():"";
                	   var templateCode = $("#b_templateCode").val()?$("#b_templateCode").val():"";
                	   var templateVersion=$("#b_templateVersion").val()?$("#b_templateVersion").val():"";
   		        	   var appVersionMin=$("#b_appVersionMin").val()?$("#b_appVersionMin").val():"";
	   		           var appVersionMax=$("#b_appVersionMax").val()?$("#b_appVersionMax").val():"";
	   		           
	   		           
	   	        	   if(templateName==undefined || templateName==""){
	   	        		   BUI.Message.Alert('模板名称必填','info');
	   	        		   return false;
	   		      	   }
	   		           if(templateCode==undefined || templateCode==""){
	   		        	   BUI.Message.Alert('客户编码必填','info');
	   		      		   return false;
	   		      	   }
	   		           if(templateVersion==undefined || templateVersion==""){
	   		        	   BUI.Message.Alert('模板版本号必填','info');
	   		      		   return false;
	   		      	   }
                	   //do some thing
	            	   $.ajax({
	   						url: 'copyTemplate.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	templateName:templateName,
	   			            	templateCode:templateCode,
	   			            	templateVersion:templateVersion,
	   			            	appVersionMin:appVersionMin,
	   			            	appVersionMax:appVersionMax
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('克隆失败','error');
	   				            //$("#btnSearch").submit();
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('模板克隆成功','info');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('模板克隆失败','info'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
      
    });
	
	
	
	
	
	
	
	
	
	//模板项配置
	grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        field = ev.field, //点击对应列的dataIndex
        target = $(ev.domTarget); //点击的元素
       
        //模板小版本升级
        if(target.hasClass('templateUpgrade')){
        	var msg = '<input type="hidden" name="c_id" id="c_id" value="'+record.id+'" style="width:100px;"/>'+
        	'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板名称：</span><input type="text" name="c_templateName" id="c_templateName" value="'+record.templateName+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板编码：</span><span name="c_templateCode" id="c_templateCode">'+record.templateCode+'</span></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">模板版本号：</span><input type="text" name="c_templateVersion" id="c_templateVersion" value="'+record.templateVersion+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">APP最低版本： </span><input type="text" name="c_appVersionMin" id="c_appVersionMin" value="'+record.appVersionMin+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">APP最高版本： </span><input type="text" name="c_appVersionMax" id="c_appVersionMax" value="'+record.appVersionMax+'" style="width:150px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:120px;text-align:right;">configSeqNo： </span><input type="text" name="c_configSeqNo" id="c_configSeqNo" value="'+record.configSeqNo+'" style="width:150px;"/></div>';
			var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'模板升级',
		        width:500,
		        height:300,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var id = $("#c_id").val()?$("#c_id").val():"";
                	   var templateName=$("#c_templateName").val()?$("#c_templateName").val():"";
                	   var templateVersion=$("#c_templateVersion").val()?$("#c_templateVersion").val():"";
   		        	   var appVersionMin=$("#c_appVersionMin").val()?$("#c_appVersionMin").val():"";
	   		           var appVersionMax=$("#c_appVersionMax").val()?$("#c_appVersionMax").val():"";
	   		           var configSeqNo=$("#c_configSeqNo").val()?$("#c_configSeqNo").val():"";
	   		        
	   	        	   if(templateVersion==undefined || templateVersion==""){
	   	        		   BUI.Message.Alert('模板版本号必填','info');
	   	        		   return false;
	   		      	   }
	   		           if(appVersionMin==undefined || appVersionMin==""){
	   		        	   BUI.Message.Alert('客户端版最低版本号必填','info');
	   		      		   return false;
	   		      	   }
	   		           if(appVersionMax==undefined || appVersionMax==""){
	   		        	   BUI.Message.Alert('客户端最高版本号必填','info');
	   		      		   return false;
	   		      	   }
	   		           
	   		           if(configSeqNo == undefined){
	   		        	configSeqNo = "";
	   		           }
                	   //do some thing
	            	   $.ajax({
	   						url: 'deployTemplate.json',
	   			            dataType:"json",
	   			            data: {
	   			            	id:id,
	   			            	templateName:templateName,
	   			            	templateVersion:templateVersion,
	   			            	appVersionMin:appVersionMin,
	   			            	appVersionMax:appVersionMax,
	   			            	configSeqNo:configSeqNo
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            //$("#btnSearch").submit();
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.message=="success"){
										BUI.Message.Alert('模板升级成功','info');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert('模板升级异常','info'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
        
        
        
        
        
      
    });

	
	
	});