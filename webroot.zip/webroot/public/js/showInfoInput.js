  	
  	var urlRegexp = {taobao:/^(http|https):\/\/.*id=.*$/,
  	                 meituan:/^(http|https):\/\/.*meituan.*(shop|merchant).*$/,
  	                 nuomi: /^(http|https):\/\/.*nuomi.*(shop|merchant).*$/,
  	                 ctrip:/^(http|https):\/\/.*ctrip.*$/,
  	                 mi:/^.*$/,huawei:/^.*$/,koubei:/^.*$/};
  	    ABL.ready(function() {
	/*	jQuery("#detailDiv").hide();//初始隐藏*/
		
		//nick校验
		jQuery("#btnNick").on("click",function(){
	        var objBtn =jQuery(this);
			var nick=jQuery("#nick").val();
			//商户类型效验
			var merchantType=jQuery("#merchantType").val();
			if(merchantType==''){
				return;
			}
			
			if(nick==''){
				return;
			}
			var data={'nick':nick,'merchantType':merchantType};
			objBtn.attr("disabled",true);
    		jQuery.post('/hbanticash/checkNickName.json',data,function(result){
			   if(result){
			   	if(result.result && result.result=='success'){
    				//请求完成后下拉出来
    				jQuery('#nick').attr('readOnly',true);//设为只读状态
					jQuery('#nick').css('background-color','#ccc')//改变样式
					jQuery('#merchantType').attr('disabled','disabled');//设为只读状态
					jQuery('#merchantType').css('background-color','#ccc')//改变样式
    				jQuery("#detailDiv").slideDown();
					jQuery("#btnNick").hide();
					jQuery("#nickName").val(result.nick);
					jQuery("#taskId").val(result.taskId);
					jQuery("#hidMerchantType").val(result.merchantType);
					objBtn.attr("disabled",false);
				 }
				 else if(result.result && result.result=='fail'){
				 	//alert(result.remark);
				 	BUI.use('bui/overlay',function(overlay){     
				      function show () {
				        BUI.Message.Alert(result.remark,function(){
				        	objBtn.attr("disabled",false);
				        });
				      }				 
				      show();	      
				      
				      });
				 	return false;
				 	objBtn.attr("disabled",false);
				 }

			   }	
				
    		});
		});		
		  function addListener(element,e,fn){   
		        if(element.addEventListener){   
		             element.addEventListener(e,fn,false);   
		         } else {   
		             element.attachEvent("on" + e,fn);   
		          }   
		   }
		   var Textarea = document.getElementById("merchandiseLink");
		   addListener(Textarea,"keyup",function(){
		        var link=this.value;
		        this.value=this.value.decodeHtml();
          })

		  if(link){
		  	   link=link.decodeHtml().decodeHtml();
               jQuery("#merchandiseLink").val(link);

		  }
		//信息暂存
		jQuery("#btnScratchHB").click(function(){
		    var merchandiseLink=jQuery("#merchandiseLink").val();
     	  var merchantType=jQuery("#hidMerchantType").val();
  	      var reg = urlRegexp[merchantType];
  	    if(merchandiseLink){
  	    if(!reg.test(merchandiseLink)){
     	  	jQuery("#merchandiseLinkErr").show();
     	  	jQuery("#merchandiseLink").focus();
     	  	return false;
        }else{
          jQuery("#merchandiseLinkErr").hide();
         }
  	    }
  	    
  	    var mb = jQuery("#mobile").val();
  	    if(mb){
  	    if(!/(\+\d+)?1[34578]\d{9}$/.test(mb)){
            jQuery("#mobileErr").show();
            jQuery("#mobile").focus();
            return false;
         }else{
           jQuery("#mobileErr").hide();
         }
  	    }
		var objBtn =jQuery(this);
            objBtn.attr("disabled",true);
           	setTimeout(able(objBtn),3000);
			 BUI.Message.Confirm('确定信息暂存吗？',function(){
	          var url='/hbanticash/saveAntiCashInfo.json';
						jQuery("#saveStatus").val("scratch");
						var data=jQuery("#hbInputForm").serialize();
						jQuery.ajax({
							url:url,
							data:data,
							dataType:'json',
							type:'post',
							success:function(result){
								if(result.result=='success'){
		    					//alert("任务创建成功");
		    					BUI.use('bui/overlay',function(overlay){
		    						BUI.Message.Alert("信息暂存成功",function(){
		    							window.location.href="/hbanticash/showInfoInput.htm";
		    						},'success');					      
		    					});						
		    				}else if(result.result=='fail'){
								//alert(result.remark);
								BUI.use('bui/overlay',function(overlay){
									BUI.Message.Alert(result.remark);
								});
							}
						},error:function(data){
							
						}
					});
	        },'question');
		});
		
		//录入放弃
		jQuery("#btnResetHB").click(function(){	
			var objBtn =jQuery(this);
			objBtn.attr("disabled",true);
			setTimeout(able(objBtn),3000);
			var url    ='/hbanticash/saveAntiCashInfo.json';	
			var saveStatus = jQuery("#saveStatus").val("giveup");
			var data=jQuery("#hbInputForm").serialize();
//			var data={nick:jQuery("#nick").val(),nickName:jQuery("#nickName").val(),taskId:jQuery("#taskId").val(),saveStatus:jQuery("#saveStatus").val()};
			BUI.Message.Confirm('确定放弃任务创建？ ',function(){
	           jQuery.ajax({
					url:url,
					data:data,
					dataType:'json',
					type:'post',
					success:function(result){
						if(result.result=='success'){    				
							BUI.use('bui/overlay',function(overlay){     
								function show () {
									BUI.Message.Alert("录入放弃成功",function(){
										window.location.href="/hbanticash/showInfoInput.htm";
									},'success');
								}				 
								show();		      
								
							});						
						}else if(result.result=='fail'){						
							BUI.use('bui/overlay',function(overlay){
								BUI.Message.Alert(result.remark);
							});
						}
					},error:function(data){
						
					}
				});
	        },'question');
		});
	});
    function able(ele){
    	ele.attr("disabled",false);
    }
   jQuery("#btnSubmitHB").click(function(){
     	  var url_id=/id=\d+$/;
     	  var merchandiseLink=jQuery("#merchandiseLink").val();
     	  var merchantType=jQuery("#hidMerchantType").val();
  	      var reg = urlRegexp[merchantType];
        if(!reg.test(merchandiseLink)){
     	  	jQuery("#merchandiseLinkErr").show();
     	  	jQuery("#merchandiseLink").focus();
     	  	return false;
        }else{
          jQuery("#merchandiseLinkErr").hide();
         }
     	  /*if(!url_id.test(merchandiseLink)){
     	  	BUI.Message.Alert("商品链接不合法！");
            return false;

     	  }*/
     	  
     	var mb = jQuery("#mobile").val();
  	    if(mb){
  	    if(!/(\+\d+)?1[34578]\d{9}$/.test(mb)){
            jQuery("#mobileErr").show();
            jQuery("#mobile").focus();
            return false;
         }else{
           jQuery("#mobileErr").hide();
         }
  	    }
   		var objBtn =jQuery(this);
			objBtn.attr("disabled",true);
			setTimeout(able(objBtn),3000);
		BUI.use('bui/form',function(Form){
		var form=new Form.HForm({
		srcNode : '#hbInputForm',
        submitType : 'ajax',
        callback : function(data){ 
        if(data.result=="success"){
        	BUI.use('bui/overlay',function(overlay){ 
		        BUI.Message.Alert(data.remark,function(){
		        	window.location.href="/hbanticash/showInfoInput.htm";
		        },'success');
		      });
        } else if(data.result=="fail"){
    		BUI.use('bui/overlay',function(overlay){ 
		        BUI.Message.Alert(data.remark);		
		      });
        }else{
        	BUI.use('bui/overlay',function(overlay){  
		        BUI.Message.Alert("系统异常");	      
		      
		      });
        }       	
        /*  var form = this;
          if(!data.sucess && data.errors){
            BUI.each(data.errors,function(v,k){
              var field = form.getField(k);
              if(field){
                field.showErrors([v]);
              }
            });
          }*/
        }
      }).render();
   });

     form.on('beforesubmit',function(){
          
     	 var filed = jQuery(".bui-queue ul");
          if(filed.children().length==0 && jQuery("#J_Uploader .estate").length == 0){
		    	jQuery("#J_Uploader").append('<span class="estate error"><span class="x-icon x-icon-mini x-icon-error">!</span>图片不能为空</span>');
		  	 return false;
		   }  
		   if(jQuery("#J_Uploader .estate").length != 0)  {
		   		return false;
		   }     
    });
      
  });
 
  $(function(){
  	 var dataObj={taskId:jQuery("#taskId").val()};
	   BUI.use(['bui/uploader','bui/overlay'],function (Uploader) {  
	      var uploader = new Uploader.Uploader({
	        render: '#J_Uploader',
	        url: '/hbanticash/uploadHBPhoto.json',
	        data:dataObj,	
	        queue: {
	          resultTpl:{
	            'success': '<div class="success"><img src="{url}" title="{name}" delUrl="{delUrl}" width="100" height="50"/></div>',
	            'error': '<div class="error" style="display:none;"><span class="uploader-error">{msg}</span></div>'

	            //'<div class="error"><span class="uploader-error">{msg}</span></div>'
	          }
	        },     
	        rules: {
	          //文的类型
	          ext: ['.png,.jpg,.bmp,.jpeg','文件类型只能为{0}']
	        },   
	        listeners:{                                   
                   start:function(){
                                          
                   },                                   
                   mousedown:function(){
                        dataObj.taskId=  jQuery("#taskId").val();                                
                   },
                   change:function(e){
                   	  var  obj=e.items[0];
                   	  if(obj.error==true){
                         BUI.Message.Alert(obj.msg);
                         jQuery(".bui-queue-item:last").remove();
                        return false;
                   	  }
                  

                   }
                },
	        isSuccess: function(result){
	          if(result && result.downloadUrl){
	            return true;

	          }
	          return false;
	        }
	      }).render();	      
	      	//获取上传文件的对列
	      	var queue = uploader.get('queue');  
	      	var arr=[];       
		      jQuery(".imgs").each(function(){
		      		var str=jQuery(this).html();	
		      		   str= str.decodeHtml(),
		      		  deleteUrl=jQuery(this).next().html().decodeHtml();
		      	    var index = str.lastIndexOf("_");	      	     
			      	var ojbresult={success: true, name:"",ext:'.jpg', url:str,delUrl:deleteUrl};
			      	var index1=deleteUrl.lastIndexOf("_");
			      	var index2=deleteUrl.lastIndexOf("&");
			      	ojbresult.name=deleteUrl.substring(index1+1,index2);
			      	arr.push(ojbresult);		       

		      });
	      if(arr.length>0){
            queue.setItems(arr); 
            jQuery(".bui-queue-item-del").each(function(i,item){
                jQuery(item).removeClass("bui-queue-item-del").addClass("bui-delete");

            });    
	      };

	      jQuery(".bui-delete").live("click",function(){
          		deleteImg(jQuery(this));
           });  

	      uploader.on('success', function(ev){
              var result = ev.result;  
              jQuery(".estate").remove(); 
              deleteUrl=result.deleteUrl.decodeHtml();
              jQuery(".bui-queue-item-del").removeClass("bui-queue-item-del").addClass("bui-delete").parent().prev().find("img").attr("delUrl",deleteUrl);             
              jQuery(".success img:last").attr("src",result.downloadUrl.decodeHtml());            
             
              jQuery(".bui-delete").on("click",function(){
              		deleteImg(jQuery(this));
              }); 
          });
          function deleteImg(element){
          	var deleteUrl=element.parent().prev().find("img").attr("delUrl");
                   var element=element;
		            BUI.Message.Confirm('确定删除该图片吗？',function(){
			            var obj=this;
					                jQuery.ajax({
					                  	  url:deleteUrl,
					                  	  type:"post",
					                  	  dataType:"json",
					                  	  success:function(data){
					                  	  	   if(data.result=="fail"){
		                                           BUI.Message.Alert(data.remark,"error");
		                                           return;
					                  	  	   }
					                  	  	   else{
													element.addClass("bui-queue-item-del").trigger("click");
					                            	obj.close();
					                  	  	   }
					                  	       
					                  	  },
					                  	  error:function(xhr,msg){

					                  	  }
					                  });
		 
			        },'question');
                 
          };          
	      uploader.on("error",function(ev){
            var result = ev.result;           
              console.log(ev.result);
	      });
    });
  });

  
  jQuery(function(){
  jQuery("#merchandiseLink").keyup(function(){
   var merchantType=jQuery("#hidMerchantType").val();
   var reg = urlRegexp[merchantType];
    var merchandiseLink=jQuery("#merchandiseLink").val();
     if(!reg.test(merchandiseLink)){
     	  	jQuery("#merchandiseLinkErr").show();
      }else{
      jQuery("#merchandiseLinkErr").hide();
      }
   });
   
   jQuery("#mobile").keyup(function(){
          var mb = jQuery("#mobile").val();
         if(mb){
         if(!/(\+\d+)?1[34578]\d{9}$/.test(mb)){
            jQuery("#mobileErr").show();
         }else{
           jQuery("#mobileErr").hide();
         }
         }else{
          jQuery("#mobileErr").hide();	 
         }
         
   
   });
  });
  	