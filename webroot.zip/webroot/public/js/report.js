$(function(){
	var channelName="";
	var channelName1="";
	var userRoleId=$("#userRoleID").val();	
	$("#searchcustom").show();
	switch (userRoleId){
	   case "alimanager":
	   channelName=$("#channelovridName").val();
	   channelName1=$("#channelfirstName").val();
	   $("#searchForm").show();
	   $("#channel_second").show();	   
	   break;
	}
	$("#channelovridName").flexselect({ hideDropdownOnEmptyInput: false });
	$("#channelfirstName").flexselect({ hideDropdownOnEmptyInput: false });
	
	function showTime(year,month){
		month=month+1;
		if(month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12){ 
			$("#startDate").val(year+"-"+month+"-"+"1");
			$("#endDate").val(year+"-"+month+"-"+"31");
		}
		else if(month==4 || month==6 || month==9 || month==11){ 
			$("#startDate").val(year+"-"+month+"-"+"1");
			$("#endDate").val(year+"-"+month+"-"+"30");
		}
		else if(month==2){
			if((year%4==0 && year%100!=0) || (year%400==0)){
				$("#startDate").val(year+"-"+month+"-"+"1");
				$("#endDate").val(year+"-"+month+"-"+"29");	
			}else{
			   $("#startDate").val(year+"-"+month+"-"+"1");
			   $("#endDate").val(year+"-"+month+"-"+"28");	
			}
		}	
		
	}
	
	
	var date=new Date();
	var date_month=date.getMonth()+1;
	var dayNum=date.getDate();
	var year=date.getFullYear();
	$("#startDate").val(year+"-"+date_month+"-"+"1");
    $("#endDate").val(year+"-"+(date_month+1)+"-"+"1");
	 BUI.use('bui/calendar',function(Calendar){
		  var datepicker1 = new Calendar.DatePicker({
            trigger:'#signTime',
            showTime : true,
            dateMask : 'yyyy/mm/dd HH:MM:ss',
            autoRender : true
          });
		 
       var inputEl = $('#J_Month'),
        monthpicker = new BUI.Calendar.MonthPicker({
          trigger : inputEl,
         // month:1, //月份从0开始，11结束
          autoHide : true,
          align : {
            points:['bl','tl']
          },
          success:function(){
            var month = this.get('month'),
              year = this.get('year');
			    month=month + 1;
                inputEl.val(year + '-' + month);//月份从0开始，11结束	
			    $("#startDate").val(year+"-"+month+"-"+"1");
                $("#endDate").val(year+"-"+(month+1)+"-"+dayNum);
			    this.hide();
			  }
			});
        monthpicker.render();
        monthpicker.on('show',function(ev){
          var val = inputEl.val(),
            arr,month,year;
          if(val){
            arr = val.split('-'); //分割年月
            year = parseInt(arr[0]);
            month = parseInt(arr[1]);
            monthpicker.set('year',year);
            monthpicker.set('month',month - 1);
          }
        });
      });
	
	 BUI.use(['bui/grid','bui/data','bui/overlay'],function(Grid,Data){
          var Store = Data.Store,
          columns = [
            {title : '序号',dataIndex :'id', width:'10%',elCls : 'center'},
            {title : '公司名称',dataIndex :'companyName', width:'20%',elCls : 'center'},
            {title : '会员类型',dataIndex : 'memberType',width:'10%',elCls : 'center'},
			{title : '签约时间',dataIndex : 'signTime',width:'10%',elCls : 'center'},
			{title : '逾期金额',dataIndex : 'overdueAmount',width:'10%',elCls : 'center'},
			{title : '逾期天数',dataIndex : 'overdueDays',width:'10%',elCls : 'center'},
			{title : '渠道商名称',dataIndex : 'channelName',width:'30%',elCls : 'center'}
          ];
 
        var store = new Store({
            url:"/channel/showOverdueReport.json",
            pageSize : 100000,
            autoLoad:true,
            params : {
                channelName:channelName
            },
            proxy:{
              method : 'post',
              dataType : 'json'
            }
          }),
          grid = new Grid.Grid({
            render:'#grid',
            columns : columns,
            loadMask: true,
            store: store,
            // 底部工具栏
            bbar:{
                // pagingBar:表明包含分页栏
                pagingBar:false
            }
          });
 
        grid.render();	
        
        var form=new BUI.Form.HForm({
            srcNode:"#searchForm"
        }).render();
        form.on("beforesubmit",function(ev){
           var obj=form.serializeToObject();
           obj.start=0;
           obj.pageIndex=0;
           store.load(obj);
           return false;
        });   
	
		var columns1 = [
            {title : '申请编号',dataIndex :'loanId', width:'5%',elCls : 'center'},
            {title : '公司名称',dataIndex : 'companyName',width:'10%',elCls : 'center'},
			{title : '会员类型',dataIndex : 'memberType',width:'10%',elCls : 'center'},
			{title : '渠道商',dataIndex : 'channelName',width:'10%',elCls : 'center'},
			{title : '首次支用时间',dataIndex : 'firstExpendDate',width:'10%',elCls : 'center'},
			{title : '首月累计支用金额',dataIndex : 'firstTotalMoney',width:'15%',elCls : 'center'},
			{title : '本月循环累计支用金额',dataIndex : 'monthCycleMoney',width:'10%',elCls : 'center'},
			{title : '本月复额累计支用金额',dataIndex : 'monthComplexCycleMoney',width:'10%',elCls : 'center'},
			{title : '新续提额标签',dataIndex : 'amountLabel',width:'10%',elCls : 'center'},			
			{title : '是否三天无理由退息',dataIndex : 'is3dayRebate',width:'10%',elCls : 'center'}
          ];
          
 
        var store1 = new Store({
            url:"/channel/showClearingDetailsReport.json",
            pageSize : 100000,
            autoLoad:true,
            params : {
               channelName:channelName1
            },
            proxy:{
              method : 'post',
              dataType : 'json'
            }
            
          }),
          grid1 = new Grid.Grid({
            render:'#grid1',
            columns : columns1,
            loadMask: true,
            store: store1,
            // 底部工具栏
            bbar:{
                // pagingBar:表明包含分页栏
                pagingBar:false
            }
          });
 
        grid1.render();	
        	
        var form1=new BUI.Form.HForm({
            srcNode:"#searchcustom"
        }).render();
        form1.on("beforesubmit",function(ev){
           var obj=form1.serializeToObject();
           obj.start=0;
           obj.pageIndex=0;		   
           store1.load(obj);
           return false;
        });   
		
		
		var columns2 = [
            {title : '会员类型',dataIndex :'memberType', width:'15%',elCls : 'center'},
            {title : '首月累计支用客户数',dataIndex : 'monthTotalCustomer',width:'15%',elCls : 'center'},
      			{title : '首月累计支用金额',dataIndex : 'firstTotalMoney',width:'10%',elCls : 'center'},
      			{title : '循环累计支用客户数',dataIndex : 'cycleTotalCutomer',width:'15%',elCls : 'center'},
      			{title : '循环累计支用金额',dataIndex : 'cycleTotalMoney',width:'15%',elCls : 'center'},
      			{title : '复额累计支用客户数',dataIndex : 'complexCycleCustomer',width:'15%',elCls : 'center'},
      			{title : '复额累计支用金额',dataIndex : 'complexCycleMoney',width:'15%',elCls : 'center'}
          ];
          
 
        var store2 = new Store({
            url:"/channel/showClearingSummaryRepor.json",
            pageSize : 100000,
            autoLoad:true,
            params : {
               channelName:$("#channelSecnodName").val()
            },
            proxy:{
              method : 'post',
              dataType : 'json'
            }
            
          }),
          grid2 = new Grid.Grid({
            render:'#grid2',
            columns : columns2,
            loadMask: true,
            store: store2,
            // 底部工具栏
            bbar:{
                // pagingBar:表明包含分页栏
                pagingBar:false
            }
          });
 
        grid2.render();	
        	
        var form2=new BUI.Form.HForm({
            srcNode:"#searchMonths"
        }).render();
        form2.on("beforesubmit",function(ev){
           var obj=form2.serializeToObject();
           obj.start=0;
           obj.pageIndex=0;		   
           store2.load(obj);
           return false;
        });  
		
      });
	  BUI.use(['bui/tab','bui/mask'],function(Tab){
        var tab = new Tab.TabPanel({
          srcNode : '#tab',
          elCls : 'nav-tabs',
          itemStatusCls : {
            'selected' : 'active'
          },
          panelContainer : '#panel'//如果不指定容器的父元素，会自动生成
          
        });
		tab.render();
    });
	BUI.use('bui/calendar',function(Calendar){
          var datepicker = new Calendar.DatePicker({
            trigger:'.calendar',
            autoRender : true
          });
    });
	$("#J_Month").val(year+"-"+date_month);	
})
