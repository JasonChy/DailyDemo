$(function(){
	var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
		{  //声明列模型
         title : '渠道商',
         dataIndex :'channelName',
		 width:'200px'
       },{
         title : '渠道商编号',
         dataIndex :'channelCode',
			width:'200px'
       }
	  ];

	var store = new Store({
		url: $("#buggerUrl").val(),
		autoLoad:true
	  }),
	  grid = new Grid.Grid({
		render:'#noticGrid',
		loadMask: true,
		width:'100%',
		height:470,
		columns : columns,
		store: store,
		plugins : [Grid.Plugins.CheckSelection], //勾选插件、自适应宽度插件
		// 顶部工具栏
		bbar : {
		  pagingBar:false
		},
		listeners :{
				rowselected:function( obj){
					var record = obj.record, 
						row = $(obj.row);
					row.attr("data-id", record.id);
					$("#selectManCount").text($("#noticGrid").find("tr.bui-grid-row-selected").length);
				},
				rowunselected:function(){
					$("#selectManCount").text($("#noticGrid").find("tr.bui-grid-row-selected").length);
				}
			}
	  });

	grid.render();
	
	$("#sendMessage").bind("click", function(){
	    if($("#selectManCount").text()==0 ){
			alert("请选择渠道商！");
			return;
		}else if($.trim($("#noticeTextarea").val())==""){
			alert("请编写通知！");
			return;
		}
		var _this = $(this),
			paramsStr = "";
		var wrapContainer = $(this).closest(".task-container");
		$("#noticGrid").find(".bui-grid-row-selected").each(function(i){
			if(i != 0){
				paramsStr += ","+$(this).attr("data-id");
			}else{
				paramsStr += $(this).attr("data-id");
			}
			
		});
		$.ajax({ 
            type: "post", 
			url: _this.attr("data-url"), 
			dataType: "json", 
			data:{
				id:paramsStr,
				content:$("#noticeTextarea").val()
			},
			success: function (data) { 
				alert("添加成功");
				$("#noticeTextarea",wrapContainer).val("");
				$(".bui-grid-row",wrapContainer).each(function(){
					$(this).removeClass("bui-grid-row-selected");
				});
				$(".bui-grid-hd",wrapContainer).removeClass("checked");
				$("#selectManCount").html("0");
			}, 
			error: function (XMLHttpRequest, textStatus, errorThrown) { 
				alert(errorThrown); 
			} 
		});
	});
	
	$("#resetForm").bind("click", function(){
		$("#noticeTextarea").val("");
		$("#noticGrid").find("tr").removeClass("bui-grid-row-selected");
		$("#noticGrid").find("th").removeClass("checked");
		
		$("#selectManCount").html("0");
	});
	

});