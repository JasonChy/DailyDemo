$(function(){
    var json_data=org_json;
    $("#org_parent").append("<option value=''>请选择</option>"); 
    $.each(org_json, function(i,item){    
    if(typeof(item)!="undefined")
         $("#org_parent").append("<option value='"+item.value+"'>"+item.text+"</option>");
    });
    $("#org_parent").on("change",function(){
        var obj=$(this);
        $("#org_child").empty();
        $("#org_child").append("<option value=''>请选择</option>")
        $("#org_child").selectedIndex=0;
        $.each(org_json,function(i,item){
         if(obj.val()==item.value){
            $.each(item.selects,function(j,childItem){
            $("#org_child").append("<option value='"+childItem.value+"'>"+childItem.text+"</option>");
         });
       }
    });         
 });
    $.BindSelect({province:'loc_province',city:'loc_city',town:'loc_town'}); 
	// 初始化任务表格
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
		{ title: '任务编号',width: 80,  sortable: false, dataIndex: 'ecgatherTaskId',elCls : 'center'},
		{ title: '报名编号',width: 80,  sortable: false, dataIndex: 'loanCode',elCls : 'center' },
		{ title: '客户姓名/联系方式',width: 80,  sortable: false, dataIndex: 'ctrllerName', elCls : 'salesman-text', renderer:function(value,obj){
			return value+'</br>'+obj.ctrllerPhone;
		}},
		{ title: '公司名称',width: 80,  sortable: false, dataIndex: 'companyName',elCls : 'center',renderer:function(value,obj){
				return value || "";
			}
		},
		{ title: '公司地址',width: 80,  sortable: false, dataIndex: 'companyAddress',elCls : 'companyName'},
		{ title: '<span>客户经理</span><span>客户经理手机</span>',width: 80,   dataIndex: 'assistApproveName', elCls : 'salesman-text', renderer:function(value,obj){
				return value+'</br>'+obj.assistApproveMobile;
			}
		},
		{ title: '任务完成状态',width: 80,  sortable: false, dataIndex: 'overallTaskStatus',elCls : 'center',renderer:function(value,obj){
				if(value=='waitassign'){
				  value='待分配';
				}else if(value=='visiting'){
				  value='处理中';
				}else if(value=='visitfinish')
				{
				   value='外访完成';
				}else if(value=='end'){
				   value='已结束';
				}else{
					value='未知';
				}
				if(obj.urgent=='1')
				{
					return '加急/'+value;
				}
				return value;
			}
		},
		{ title: '任务子状态',width: 80,  sortable: false, dataIndex: 'processStatus',elCls : 'center',renderer:function(processStatus,obj){
				if(processStatus=='init'){
				return '客户预约';
				}
				if( processStatus=='visit'){
					return '实地调查';
				}
				if( processStatus=='investigate'){
					return '提交报告';
				}
				if( processStatus=='innerApprove'){
					return '内部审核';
				}
				if( processStatus=='innerApprove_verifyPass'){
					return '内部审核通过';
				}
				if( processStatus=='innerApprove_verifyGiveup'){
					return '内部审核确认放弃';
				}
				return '';
			}
		},
		{ title: '任务流入时间',width: 80,  sortable: false, dataIndex: 'processStartTime',elCls : 'center',renderer:BUI.Grid.Format.dateRenderer},
		{ title: '整体/环节滞留', width: 80, sortable: false,  elCls : 'center' ,dataIndex: 'processUsedTime',
		    renderer:function(value,obj){
				value = value || '0';
				var taskUsedTime=obj.taskUsedTime;
				if (typeof(taskUsedTime) == "undefined"){
					taskUsedTime='0';
				}
				
				value =value +'/'+taskUsedTime ||'0天';
				return value; 
			}
		},
		{ title: '当前跟进人', width: 80, sortable: false,  elCls : 'center' ,dataIndex: 'actorRealName',renderer:function(value,obj){
			if(obj.overallTaskStatus == "visitfinish" || obj.overallTaskStatus == "end"){
				value = "";
			}else{
				value = value || '待分配';
			}
			return value;
		}},
		{ title: '是否退回任务',width: 80,  sortable: false, dataIndex: 'isReturnTask',elCls : 'center',renderer:function(value,obj){
				if(value=='y'){
				  value='是';
				}else if(value=='n'){
				  value='否';
				}

				return value;
			}
		},
		{ title:'原件状态',width: 80,  sortable: false, dataIndex: 'originalStatus',elCls : 'center',renderer:function(value,obj){
                if(value=='unsend'){
                  value='未寄出';
                }else if(value=='send'){
                  value='已寄出';
                }else if(value=='unreceive'){
                  value='未收到';   
                }else if(value=='receive'){
                    value='已收到';
                }

                return value;
            }
        },
		{ title: '详情', width: 100, dataIndex: 'detail',elCls : 'center',renderer:function(value,obj){
	return '<a'+(obj.overallTaskStatus=='end'?' href="javascript:void(0);" onclick="javascript:BUI.Message.Alert(\'该任务已结束\',\'info\');return false;"' :' target="_blank" href="/epiboly/showTaskDetail.htm?taskId='+obj.ecgatherTaskId+'"' )+'>任务详情</a>';
		}}
	  ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:20,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	function showEndInfo(){
	    grid.clearSelection();
	}
	
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		plugins : [Grid.Plugins.CheckSelection], //勾选插件、自适应宽度插件
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});

	grid.render();
   
  // $("<li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize20'>20</a></li><li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize50'>50</a></li>").insertBefore($("#bar3").children("li").last());
  
	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}

	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();

	/*
	 $("#pagesize20").on("click",function(){	   
			  store.set("pageSize",20);
				 $("#btnSearch").click();                     
			  grid.render();
		   });  */
	
	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	 // var page=$('#grid .bui-pb-page').val();
      obj.start=0;
      obj.pageIndex=0;
	  store.load(obj);
      console.log(store.getCount() );
	  return false;
	});

    $("#grid").on("click",".view-operate",function(){
        var ecgatherTaskId = $(this).attr("data-ecgatherTaskId");
        console.log(ecgatherTaskId);
    });
	// 查看详情   
	$("#grid").on("click", ".view-detail", function(e){
		var ecgatherTaskId = $(this).attr("data-ecgatherTaskId");
		 $.ajax({
                    type:"post",
                    url: "/epiboly/showDetail.json",
                    data: {"ecgatherTaskId":ecgatherTaskId},
                    dataType: 'json',
                    success: function(data){
						//var displayHtml = $(this).find("input").val() || "";
						var detail = data.detail;
						var displayHtml = '公司工商注册号：'+ detail.regNo+'<br/>房产数量：'+ detail.houseCount+'<br/>车产数量：'+ detail.carCount +'<br/>实际经营地：'
						detail.realProvince+detail.realCity + detail.realCounty+'<br />阿里特别留言：'+ detail.aliSpecialComment;
						var dialog = new BUI.Overlay.Dialog({
							width:320,
							height:280,
							align:{
								points: ['cc','cc'],
								offset:[0,0]
							},
							elCls : 'custom-dialog',
							bodyContent:displayHtml,
							buttons : []
						});
						dialog.show();
					},
                    error: function (XMLHttpRequest, textStatus, errorThrown) { 
                    	alert(errorThrown);
                    }
                });
		
	});
	
	BUI.use('bui/overlay',function(Overlay){
		var assgindialog = new Overlay.Dialog({
				title:'任务分配',
				width:500,
				height:300,
				mask:true,
				 buttons:[
					{
						text:'关闭',
						elCls : 'button',
						handler : function(){
							this.close();
						}
					}
				],
				bodyContent:'',
				listeners:{
				    closeclick:function(){
				        grid.render();
				    }
				}
		});
		
		$("#originalStatusBut").on("click",function(){
            var selectAssignRow = grid.getSelection();        
            if(selectAssignRow.length<=0){
                BUI.Message.Alert('请选择要更改任务','info');
                return;
            }
            var taskIds="";
            for(var i=0;i<selectAssignRow.length;i++){
                taskIds+=selectAssignRow[i].ecgatherTaskId+",";
            }
            var  originalStatus=$("#originalStatus").val();
            if(originalStatus==''){
                BUI.Message.Alert('请选择要更改的状态','info');
                return;
            }
            var ajaxUrl=$(this).attr('data-url');
            $.ajax({ 
                type: "post", 
                url: ajaxUrl,
                dataType: "json", 
                data:{
                    originalStatus: originalStatus,
                    taskIds:taskIds
                },
                success: function (data) { 
                    if(data.result){
                        BUI.Message.Alert(data.result,'info');                         
                        $("#btnSearch").click();                     
                        grid.render();
                    } 
                    $("#originalStatus").val("");                   
                }, 
                error: function (XMLHttpRequest, textStatus, errorThrown) { 
                    alert(errorThrown); 
                } 
            });
        });
        
        $("#taskAssginCompanyBut").on("click",function(){
            var selectAssignRow = grid.getSelection();      
            if(selectAssignRow.length<=0){
                BUI.Message.Alert('请选择要分配的任务','info');
                return;
            }
            var assignCompany=$("#assignCompany").val();
            if(assignCompany==''){
                BUI.Message.Alert('请选择分配任务的机构','info');
                return;
            }
            var taskIds="";
            for(var i=0;i<selectAssignRow.length;i++){
                taskIds+=selectAssignRow[i].ecgatherTaskId+",";
            }
            var ajaxUrl=$(this).attr('data-url');
            $.ajax({
                type:"post",
                url:ajaxUrl,
                dataType:"json",
                data:{
                    companyCode:assignCompany,
                    taskIds:taskIds
                },
                success:function(data){
                    if(data.result.resultMsg){
                        BUI.Message.Alert(data.result.resultMsg,'info'); 
                        $("#btnSearch").click();                     
                        grid.render();
                    }      
                    $("#assignCompany").val("")              
                },
                error:function (XMLHttpRequest, textStatus, errorThrown) { 
                    alert(errorThrown); 
                } 
            });
            
        });
		
		$('#taskAssginBut').on('click',function () {
			var selectAssignRow = grid.getSelection();		
            if(selectAssignRow.length<=0){
				BUI.Message.Alert('请选择要分配的任务','info');
				return;
			}
			var assignUsername=$("#assignUsername").val();
			var assignUserRealName=$("#assignUsername").find("option:selected").text();
			if(assignUsername==''){
				BUI.Message.Alert('请选择要分配任务的处理人','info');
				return;
			}
			var taskIds="";
			for(var i=0;i<selectAssignRow.length;i++){
				taskIds+=selectAssignRow[i].ecgatherTaskId+",";
			}
			var ajaxUrl=$(this).attr('data-url');
			$.ajax({ 
				type: "post", 
				url: ajaxUrl,
				dataType: "json", 
				data:{
					assignUsername:assignUsername,
					assignUserRealName:assignUserRealName,
					taskIds:taskIds
				},
				success: function (data) { 
						var bodyContent="";
						for(var i=0;i<data.result.data.length;i++)
						{
							bodyContent+=data.result.data[i]+"<br/>"
						}
						bodyContent=bodyContent||'分配成功';
						$("#btnSearch").click(); 
						if(bodyContent=='分配成功'){
						    BUI.Message.Alert(bodyContent,'info');
						}else{						   
						    //BUI.Message.Alert(bodyContent,'info');
    					
							assgindialog.set('bodyContent',bodyContent);
							assgindialog.show();
							
						}						
					$("#assignUsername").val("");
					
				}, 
				error: function (XMLHttpRequest, textStatus, errorThrown) { 
					alert(errorThrown); 
				} 
			});
		});
	});
			
	// 通知滚动
	var noticeUl = $("#noticeUl"),
		noticeLiWidth = noticeUl.find("li:first").width(),
		liCount = noticeUl.find("li").length,
		noticeTimer = null;
	//noticeUl.css("width", noticeLiWidth*liCount+"px");
	noticeUl.hover(function(){
		clearInterval(noticeTimer);
	},function(){
		noticeTimer = setInterval(function(){
			noticeUl.animate({"marginLeft":-noticeLiWidth+"px"}, 600, function(){
				noticeUl.css({"marginLeft":0}).find("li:first").appendTo(noticeUl);
			});
		},3000);
	}).trigger("mouseleave");
	
	// 查看新的通知
	$("#viewNewNotice").on("click", function(){
		viewNewNoticeList($(this).attr("data-url"));
	});
	
	function viewNewNoticeList(url){
        var noticeColumns = [
            {title : '创建时间',dataIndex :'gmtCreate', width:100},
            {title : '内容',dataIndex : 'content',width:200}
          ];
 
        var store = new Store({
            url : url,
            autoLoad:true
          }),
          noticegrid = new Grid.Grid({
            forceFit: true, // 列宽按百分比自适应
            columns : noticeColumns,
            store : store,
			 listeners:{
				afterRenderUI:function( e ){
					$(".bui-stdmod-body").find(".bui-grid-header-container").remove();
					$(".bui-stdmod-footer").remove();
				}
			}
          });
 
	 
		  var noticeDialog = new BUI.Overlay.Dialog({
				title:'<span class="task-lba"><span>最新通知',
				width:500,
				height:370,
				children : [noticegrid],
				childContainer : '.bui-stdmod-body',
				buttons : []
			  });
		 noticeDialog.show();
	}

	// 查询历史消息详情
$("#viewHistoryDetail").bind("click", function(){
		$.ajax({
				url:"/channel/showHistoryNotice.json?start=0&limit=6&pageIndex=0",
				dataType:'json',
				async:true,
				success: function(data){
					var dataArr = data.rows || [];
					var noticeHistoryColumns = [
						{title : '创建时间',dataIndex :'gmtCreate', width:100},
						{title : '内容',dataIndex : 'content',width:200}
					  ]
			 
					var store = new Store({
						//url : $(this).attr("data-url"),
						data : dataArr,
						autoLoad:true,
						pageSize:6
					  }),
					  grid = new Grid.Grid({
						forceFit: true, // 列宽按百分比自适应
						columns : noticeHistoryColumns,
						store : store,
						listeners :{
							afterRenderUI:function( e ){
								$(".bui-stdmod-body").find(".bui-grid-header-container").remove();
								$(".bui-stdmod-footer").remove();
								//没有数据，处理分页栏
								if(!store.getTotalCount())
								{
									$('.bui-stdmod-body #totalPage').text("共 0 页");
									$('.bui-stdmod-body .bui-pb-page').val("0");
									$('.bui-stdmod-body #totalCount').text("共0条记录");
								}
							}
						},
						bbar : {
						  // pagingBar:表明包含分页栏
						  pagingBar:true
						}
					  });
					  var noticeDialog = new BUI.Overlay.Dialog({
							title:'<span class="task-lba"><span>历史记录',
							width:500,
							height:'auto',
							children : [grid],
							childContainer : '.bui-stdmod-body',
							buttons : []
						  });
					 noticeDialog.show();
				}
			});
	});	
});