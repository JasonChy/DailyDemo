
			$(function(){
	String.prototype.replaceAll = function(s1,s2) { 
    return this.replace(new RegExp(s1,"gm"),s2); 
    }

	// 初始化任务表格
	var newDate = new Date();
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
       {title : '序列',dataIndex :'id',sortable: true, width:80,elCls : 'center'},
	   {title : '公司工商注册号',dataIndex :'code',sortable: true, width:80,elCls : 'center'},
       {title : '公司名称',dataIndex :'name',sortable: false, width:80,elCls : 'center'},
       {title : 'ipId',dataIndex : 'ipId',sortable: false,width:80,elCls : 'center'},
       {title : 'ipRoleId',dataIndex : 'ipRoleId',sortable: false,width:80,elCls : 'center'},
       {title : 'Fcbu机构编码',dataIndex : 'ummsOrgCode',sortable: false,width:80,elCls : 'center'},
       {title : '产品码',dataIndex : 'productCode',sortable: false,width:80,elCls : 'center'},
       {title : '运营产品号',dataIndex : 'opPdCode',sortable: false,width:80,elCls : 'center'},
       {title : '合约产品号',dataIndex : 'contractPdCode',sortable: false,width:80,elCls : 'center'},
       {title : '备注',dataIndex : 'note',sortable: false,width:80,elCls : 'center'},
        {title : '创建时间',dataIndex : 'gmtCreate',sortable: false,width:80,elCls : 'center',renderer:function(value,obj){
          newDate.setTime(value);
          return newDate.toLocaleString();
        }},
       /* {title : '备注',dataIndex : 'note',sortable: false,width:100,elCls : 'center',renderer:function(value,obj){
            if(!value||value==""){
                return "无";
            }
            else{
				if(value.length>100){
					return value.substring(0,100)+"<a href='javascript:void(0)' class='showAll' data-val='"+value.replaceAll("\r\n","</br>")+"'>...查看</a>";					
				}
				else{
					return value.replaceAll("\r\n","</br>");
				}
                
            }
        }
                    },
        */
        {title : '类型',dataIndex : 'type',sortable: false,width:80,elCls : 'center'},

        {title : '操作',dataIndex : 'isDelete',sortable: false,width:80,elCls : 'center',renderer:function(value,obj){
            return '<a href="javascript:void(0);"  class="edit"'+
            '" data-ipRoleId="'+obj.ipRoleId+'" data-ummsOrgCode="'+obj.ummsOrgCode+'" data-productCode="'+obj.productCode+'" data-opPdCode="'+obj.opPdCode+'" data-contractPdCode="'+obj.contractPdCode+'" data-note="'+obj.note+'" data-type="'+obj.type+'" data-orgId="'+obj.orgId+'" data-id="'+obj.id+'" data-code="'+obj.code+'" data-name="'+obj.name+' " data-ipId="'+obj.ipId+' "  data-reMark="'+obj.reMark+'">修改</a><br/>';
        }} ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		},
		listeners:{
			aftershow:function(){
				$(".showAll").on("click",function(){
					var value=$(this).attr("data-val");
					console.log(value);
					BUI.use('bui/overlay',function(Overlay){
					  var dialog = new Overlay.Dialog({
						title:'备注',
						width:500,
						height:500,
						mask:true,
                        buttons:[],
						bodyContent:"<div style='margin:5px;overlay-y:scroll;'>"+value+"</div>"						
					  });
					dialog.show();
				});	
				});
			}
			
		}
		
	});

	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	  return false;
	});
	
	function reload(){
	   var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	}
	
	$("#grid").on("click",".delete",function(){
          var id=$(this).attr("data-id"); 
            BUI.Message.Confirm('确认要删除吗？',function(){
                  jQuery.ajax({
                        type:"post",
                        url:delete_org_url,
                        dataType:"json",
                        data:{
                          id:id
                        },
                        success:function(data){
                            BUI.Message.Show({
                                msg : data.result.resultMsg,
                                icon : 'error',
                                width:200,
                                buttons : [],
                                autoHide :false 
                             });
                            reload();                         
                         }
                   });
            });     
 });     
        
	
	
	
	 BUI.use('bui/overlay',function(Overlay){
       assgindialog = new Overlay.Dialog({
                title:'添加配置',
                width:650,
                height:400,
                mask:true,
                 buttons:[
                    {
                        text:'取消',
                        elCls : 'button',
                        handler : function(){                            
                            this.close();
                        }
                    },{
                        text:'确定',
                        elCls:'button',
                        handler:function(){
                           var url=this.flag=="add"?add_org_url :update_org_url;  
                           if($("#code").val()==""){
                                BUI.Message.Show({
                                        msg : '编号',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                   });
                                   return false;
                            }                          
                            if($("#cName").val()==""){
                                BUI.Message.Show({
                                        msg : '名称',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                   });
                                  return false;
                            }
                            if($("#ipId").val()==""){
                                BUI.Message.Show({
                                        msg : 'ipId不能为空',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                   });
                                  return false;
                            }
                            jQuery.ajax({
                            url: url,
                            dataType:"json",
                            data: $('#form').serialize(),
                            type: "POST",
                            error: function(e) {            
                            BUI.Message.Show({
                                        msg : '提交失败',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });
                            },
                            success: function(data) {
                            BUI.Message.Show({
                                        msg : data.result.resultMsg,
                                        icon : 'success',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                              });
                           reload();
                              
                            }                   
                       });
                       this.close(); 
                      } 
                       
                    } 
                ],
                bodyContent:'',
                listeners:{
                    closeclick:function(){
                        grid.render();
                    }
                }
        });
  });
	
	     // var str='<div id="content" ><form id="form" ><div class="control-group"> <label class="control-label">业务标识:</label> <div class="controls "><input type="text" class="province" name="bizProduct" id="bizProduct"> </div>  </div><div class="control-group"> <label class="control-label">签约文件:</label> <div class="controls "><input type="text" class="province" name="signFileId" id="signFileId"> </div>  </div><div class="control-group"> <label class="control-label">签约展现文件:</label> <div class="controls "><input type="text" class="province" name="signShowId" id="signShowId"> </div>  </div><div id="inputContent"></div> <div class="control-group org_remarks"><label class="control-label">备注:</label><div class="controls"><textarea id="txtdesc" name="remark"></textarea></div></div></form></div>';
	
     var str='<div id="content" ><form id="form"> <div id="inputContent"></div>'+ 
    	 '<div class="control-group"><label class="control-label">公司工商注册号:</label> <div class="controls "><input type="text" class="province" name="code" id="code"> </div>  </div>'+
         '<div class="control-group"> <label class="control-label">公司名称:</label> <div class="controls "><input type="text" class="province" name="cName" id="cName"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">ipId:</label> <div class="controls "><input type="text" class="province" name="ipId" id="ipId"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">ipRoleId:</label> <div class="controls "><input type="text" class="province" name="ipRoleId" id="ipRoleId"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">Fcbu机构编码:</label> <div class="controls "><input type="text" class="province" name="orgCode" id="orgCode"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">产品码:</label> <div class="controls "><input type="text" class="province" name="productCode" id="productCode"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">运营产品号:</label> <div class="controls "><input type="text" class="province" name="opPdCode" id="opPdCode"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">合约产品号:</label> <div class="controls "><input type="text" class="province" name="contractPdCode" id="contractPdCode"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">类型:</label> <div class="controls "><input type="text" class="province" name="type" id="type"> </div>  </div>'+
    	 '<div class="control-group"> <label class="control-label">备注:</label><div class="controls"><textarea id="note" name="note"></textarea></div></div>'+
    	 '</form></div>';

	 $(".add_org_rule").on("click",function(){
          assgindialog.set("bodyContent","");
          assgindialog.set("bodyContent",str);
          assgindialog.set("title","添加配置");
          assgindialog.flag="add";
          $("#inputContent").html("");
          assgindialog.show();		 
		 
		  
           
      });
	
	
	
	$("#grid").on("click",".edit",function(){    
        assgindialog.set("bodyContent","");
        assgindialog.set("bodyContent",str); 
        assgindialog.flag="update";
        assgindialog.set("title","修改协议");
        assgindialog.show();        
        $("#inputContent").html("<input type='hidden' name='id' value='"+$(this).attr("data-id")+"'>");
		$("#orgCode").val($(this).attr("data-ummsOrgCode")).attr("readonly", "true");
		if($(this).attr("data-code")){
			$("#code").val($(this).attr("data-code"));	
		}
		if($(this).attr("data-name")){
			$("#cName").val($(this).attr("data-name"));	
		}
		 
		if($(this).attr("data-ipId")){
			$("#ipId").val($(this).attr("data-ipId"));	
		} 
		if($(this).attr("data-ipRoleId")){
			$("#ipRoleId").val($(this).attr("data-ipRoleId"));	
		} 
		
		if($(this).attr("data-productCode")){
			$("#productCode").val($(this).attr("data-productCode"));	
		} 
		if($(this).attr("data-opPdCode")){
			$("#opPdCode").val($(this).attr("data-opPdCode"));	
		} 
		if($(this).attr("data-contractPdCode")){
			$("#contractPdCode").val($(this).attr("data-contractPdCode"));	
		} 
		if($(this).attr("data-note")){
			$("#note").val($(this).attr("data-note"));	
		}
		
		if($(this).attr("data-type")){
			$("#type").val($(this).attr("data-type"));	
		} 
		  });	
		
	
	
	});