$(function(){
	// 初始化任务表格
	var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
		{ title: '报名编号',width: 80,  sortable: false, dataIndex: 'loanCode',elCls : 'center',renderer:function(value,obj){
				return value || "无报名编号";
			}
		},
		{ title: '任务开始时间', width: 80, sortable: true, dataIndex: 'gmtCreate', elCls : 'center'},
		{ title: '任务状态',width: 100, sortable: true,  dataIndex:'applyStatus',  showTip: true,elCls : 'con-center center',renderer:function(value,obj){
				if(obj.marketAgain=='true'){
					return '<div class="er-m">二次跟进</div>'+value;   
				}
				return value;
			}
		},
		{ title: '<span>客户法定代表人</span><span>法人机构名称</span>', width: 120, elCls : 'company-text',  dataIndex: 'customerName',
			renderer:function(value,obj){
				value = value || '';
				return value+(obj.companyName?','+obj.companyName:""); 
			}
		},
		{ title: '整体/环节滞留', width: 80, sortable: false,  elCls : 'center' ,dataIndex: 'overallLinkDelayDay',
		    renderer:function(value,obj){
				value = value || '';
				return value+'/'+obj.linkDelayDay; 
			}
		},
		{ title: '<span>业务员姓名</span><span>业务员手机</span>',width: 80,   dataIndex: 'salesmanName', elCls : 'salesman-text', renderer:function(value,obj){
				value = value || '';
				return value+'</br>'+obj.salesmanPhone||"无手机号码";
			}
		},
		{ title: '详情', width: 100, dataIndex: 'detail',elCls : 'center',renderer:function(value,obj){
			value = value || '';
			if(value.length > 24){
				return value.substring(0,23)+'...<a class="view-detail" id="viewDetail"><input type="hidden" value="'+value+'" />详情</a>';
			}
			return value;
		}},
		{ title: '备注',width: 120, sortable: true,  dataIndex: 'recordNotes',elCls : 'center',	
			renderer : function(value,obj){
			    value = value || '';
				return '<textarea name="amount_'+obj.id+'" class="kdInput" data-id="'+obj.id+'" data-rules="{required : true}">'+value+'</textarea>';	
			}	
		}		
	  ];
	var store = new Store({
		url: $("#btnSearch").data("url")+"?_input_charset=utf-8",
		autoLoad:true,
		pageSize:10
	  }),
	  grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		plugins : [Grid.Plugins.AutoFit], //勾选插件、自适应宽度插件
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	  });

	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}

	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();

	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	  obj.start = 0; //返回第一页
	  obj.pageIndex = 0;
	  store.load(obj);
	  return false;
	});
	
	$("#grid").on("click", ".kd-sure", function(){
		var _this = $(this),
			expressNoIpt = _this.prev();
		$.ajax({ 
            type: "post", 
			url: $("#kdNumberUrl").val(), 
			dataType: "json", 
			data:{
				expressNo:expressNoIpt.val(),
				id:expressNoIpt.attr("data-id")
			},
			success: function (data) { 
				if(data.result == "true"){
					//expressNoIpt.trigger("blur");
					expressNoIpt.css("width","140px");
					expressNoIpt.next().hide();
				}else{
					expressNoIpt.val(data.result);
				}		
			}, 
			error: function (XMLHttpRequest, textStatus, errorThrown) { 
				alert(errorThrown); 
			} 
		});
	});

	$("#grid").on("focus",".kdInput",function(){
	   var value_bak = $(this).val();
	   $(this).attr("value_bak",value_bak);
	   $(this).one("blur",function(e){
	       var $this = $(this);
		   var expressNoIpt = $this.attr("data-id");
		   var value = $.trim($this.val());
		   var preValue = $.trim($this.attr("value_bak"));
		   if(!value && preValue){
			   $(this).val(preValue)
		   }
		   if(!value || value==preValue){
				return ;
		   }
		   $.ajax({ 
				type: "post", 
				url: "/channel/recordNotes.json", 
				dataType: "json", 
				data:{
					notes : value,
					id:expressNoIpt
				},
				success: function (data) { 
					if(data.result == "true"){
						
					}else{
						alert("输入异常，请重新输入！");
					}						
				}, 
				error: function (XMLHttpRequest, textStatus, errorThrown) { 
					alert(errorThrown); 
				} 
			});
	   });
		$(this).bind("keyup",function(e){
		   if(e.keyCode == 13)
		   {
			   $(this).trigger("blur");
		   }
		   return;
		})
    });
	
	// 查看详情   
	$("#grid").on("click", ".view-detail", function(e){
		var displayHtml = $(this).find("input").val() || "";
		var dialog = new BUI.Overlay.Dialog({
            width:400,
            height:200,
			align:{
				points: ['cc','cc'],
				offset:[0,0]
			},
            elCls : 'custom-dialog',
            bodyContent:displayHtml,
            buttons : []
		});
        dialog.show();
	});
	
	// 通知滚动
	var noticeUl = $("#noticeUl"),
		noticeLiWidth = noticeUl.find("li:first").width(),
		liCount = noticeUl.find("li").length,
		noticeTimer = null;
	//noticeUl.css("width", noticeLiWidth*liCount+"px");
	noticeUl.hover(function(){
		clearInterval(noticeTimer);
	},function(){
		noticeTimer = setInterval(function(){
			noticeUl.animate({"marginLeft":-noticeLiWidth+"px"}, 600, function(){
				noticeUl.css({"marginLeft":0}).find("li:first").appendTo(noticeUl);
			});
		},3000);
	}).trigger("mouseleave");
	
	// 查看新的通知
	$("#viewNewNotice").on("click", function(){
		viewNewNoticeList($(this).attr("data-url"));
	});
	
	function viewNewNoticeList(url){
        var noticeColumns = [
            {title : '创建时间',dataIndex :'gmtCreate', width:100},
            {title : '内容',dataIndex : 'content',width:200}
          ];
 
        var store = new Store({
            url : url,
            autoLoad:true
          }),
          grid = new Grid.Grid({
            forceFit: true, // 列宽按百分比自适应
            columns : noticeColumns,
            store : store,
			listeners :{
				afterRenderUI:function( e ){
					$(".bui-stdmod-body").find(".bui-grid-header-container").remove();
					$(".bui-stdmod-footer").remove();
				}
			}
          });
 
	 
		  var noticeDialog = new BUI.Overlay.Dialog({
				title:'<span class="task-lba"><span>最新通知',
				width:500,
				height:370,
				children : [grid],
				childContainer : '.bui-stdmod-body',
				buttons : []
			  });
		 noticeDialog.show();
	}
	
	// 查询历史消息详情
	$("#viewHistoryDetail").bind("click", function(){

		$.ajax({
				url:"/channel/showHistoryNotice.json?start=0&limit=6&pageIndex=0",
				dataType:'json',
				async:true,
				success: function(data){
					var dataArr = data.rows || [];
					var noticeHistoryColumns = [
						{title : '创建时间',dataIndex :'gmtCreate', width:100},
						{title : '内容',dataIndex : 'content',width:200}
					  ]
			 
					var store = new Store({
						//url : $(this).attr("data-url"),
						data : dataArr,
						autoLoad:true,
						pageSize:6
					  }),
					  grid = new Grid.Grid({
						forceFit: true, // 列宽按百分比自适应
						columns : noticeHistoryColumns,
						store : store,
						listeners :{
							afterRenderUI:function( e ){
								$(".bui-stdmod-body").find(".bui-grid-header-container").remove();
								$(".bui-stdmod-footer").remove();
								//没有数据，处理分页栏
								if(!store.getTotalCount())
								{
									$('.bui-stdmod-body #totalPage').text("共 0 页");
									$('.bui-stdmod-body .bui-pb-page').val("0");
									$('.bui-stdmod-body #totalCount').text("共0条记录");
								}
							}
						},
						bbar : {
						  // pagingBar:表明包含分页栏
						  pagingBar:true
						}
					  });
					  var noticeDialog = new BUI.Overlay.Dialog({
							title:'<span class="task-lba"><span>历史记录',
							width:500,
							height:'auto',
							children : [grid],
							childContainer : '.bui-stdmod-body',
							buttons : []
						  });
					 noticeDialog.show();
				}
			});


/**
			var noticeHistoryColumns = [
				{title : '创建时间',dataIndex :'gmtCreate', width:100},
				{title : '内容',dataIndex : 'content',width:200}
			  ]
	 
			var store = new Store({
				url : $(this).attr("data-url"),
				autoLoad:true,
				pageSize:6
			  }),
			  grid = new Grid.Grid({
				forceFit: true, // 列宽按百分比自适应
				columns : noticeHistoryColumns,
				store : store,
				listeners :{
					afterRenderUI:function( e ){
						$(".bui-stdmod-body").find(".bui-grid-header-container").remove();
						$(".bui-stdmod-footer").remove();
						//没有数据，处理分页栏
						if(!store.getTotalCount())
						{
							$('.bui-stdmod-body #totalPage').text("共 0 页");
							$('.bui-stdmod-body .bui-pb-page').val("0");
							$('.bui-stdmod-body #totalCount').text("共0条记录");
						}
					}
				},
				bbar : {
				  // pagingBar:表明包含分页栏
				  pagingBar:true
				}
			  });
			  var noticeDialog = new BUI.Overlay.Dialog({
					title:'<span class="task-lba"><span>历史记录',
					width:500,
					height:'auto',
					children : [grid],
					childContainer : '.bui-stdmod-body',
					buttons : []
				  });
			 noticeDialog.show();
			 */
	});
	
	// 下拉框
	var selectFunc= function(){
		var columns2 = [
			{ title: '<span>渠道商机构名称</span><span>报名编码</span>',width: 80, sortable: false, dataIndex: 'channelName',elCls : 'company-text',renderer:function(value,obj){
				value = value || '';
				return value+'</br>'+(obj.loanCode||"无报名编号");
			}},
			{ title: '任务开始时间', width: 80, sortable: true, dataIndex: 'gmtCreate', elCls : 'center'},
			{ title: '任务状态',width: 100, sortable: true,  dataIndex: 'applyStatus',  showTip: true,elCls : 'con-center center',renderer:function(value,obj){
					if(obj.marketAgain){
						return '<div class="er-m">二次跟进</div>'+value;
					}
					return value;
				}
			},
			{ title: '<span>客户法定代表人</span><span>法人机构名称</span>', width: 120, elCls : 'company-text',  dataIndex: 'customerName',
				renderer:function(value,obj){
					value = value || '';
					return value+','+obj.companyName;
				}
			},
			{ title: '整体/环节滞留', width: 80, sortable: false,  elCls : 'center' ,dataIndex: 'overallLinkDelayDay',
				renderer:function(value,obj){
					value = value || '';
					return value+'/'+obj.linkDelayDay; 
				}
			},
			{ title: '<span>业务员姓名</span><span>业务员手机</span>',width: 80,   dataIndex: 'salesmanName', elCls : 'salesman-text', renderer:function(value,obj){
					value = value || '';
					return value+'</br>'+obj.salesmanPhone||"无手机号码";
				}
			},
			{ title: '详情', width: 130, dataIndex: 'detail',elCls : 'center',renderer:function(value,obj){
				value = value || '';
				if(value.length > 24){
					return value.substring(0,23)+'...<a class="view-detail" id="viewDetail"><input type="hidden" value="'+value+'" />详情</a>';
				}
				return value;
			}},
			{ title: '备注',width: 120, sortable: true,  dataIndex: 'recordNotes',elCls : 'center',renderer : function(value,obj){
              value = value || '';
			  var value_bak = value;
              if(value.length > 24){
              	value = value.substring(0,23) + "...";
              }
              return '<span name="amount_'+obj.id+'" style="display:block;float:left;width:180px;" class="kdInput" data-id="'+obj.id+'" value_bak="'+value_bak+'"  data-rules="{required : true}">'+value+'</span>';
            }
		   }
		  ];
		var store = new Store({
			url: $("#btnSearch3").attr("data-json"),
			autoLoad:true,
			pageSize:10
		}),
		grid = new Grid.Grid({
			render:'#grid2',
			loadMask: true,
			forceFit:true,
			columns : columns2,
			store: store,
			plugins : [Grid.Plugins.AutoFit], //勾选插件、自适应宽度插件
			// 顶部工具栏
			bbar : {
			  //items 也可以在此配置
			  // pagingBar:表明包含分页栏
			  pagingBar:true
			}
		});
		grid.render();
		//没有数据，处理分页栏
		if(!store.getTotalCount())
		{
			$('#grid2 #totalPage').text("共 0 页");
			$('#grid2 .bui-pb-page').val("0");
			$('#grid2 #totalCount').text("共0条记录");
		}
		// 快递单号
		$("#grid2").on("focus", ".kdInput", function(){
			$(this).css("width","78px");
			$(this).next().show();
		});
		
		//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm2'
	}).render();

	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	  obj.start = 0; //返回第一页
	  obj.pageIndex = 0;
	  store.load(obj);
	  return false;
	});
		/*var Select = BUI.Select;
		var btnUrl = $("#btnSearch2").attr("data-json");
		$.ajax({
			url:"/channel/getChannelList.json",
			dataType:'json',
			success: function(data){
				var items = data.channelList;
				$("#btnSearch2").find('#hide').attr('value',items[0].value);
				var  select = new Select.Select({  
					  render:'#btnSearch2',
					  valueField:'#hide',
					  items:items
				});
				select.render();
				select.on('change', function(ev){
				  var value = ev.value;
					  store.load({
						"channelId":value,
						"pageIndex":0,
						"limit":10,
						"start":0
					  });
				});
			}
		});*/
		$("#grid2").on("mouseenter mouseleave",".kdInput",function(){
		    var $this = $(this);
		    var value_bak = $this.attr("value_bak");
		    var value = $this.text();
		    $this.attr("value_bak",value);
		    $this.text(value_bak);
	    });
		// 查看详情   
		$("#grid2").on("click", ".view-detail", function(e){
			var displayHtml = $(this).find("input").val() || "";
			var dialog = new BUI.Overlay.Dialog({
				width:400,
				height:200,
				align:{
					points: ['cc','cc'],
					offset:[0,0]
				},
				elCls : 'custom-dialog',
				bodyContent:displayHtml,
				buttons : []
			});
			dialog.show();
		});
	};
	selectFunc();	
});