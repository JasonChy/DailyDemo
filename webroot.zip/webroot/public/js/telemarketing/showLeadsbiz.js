BUI.use(['bui/grid','bui/data'],function(Grid,Data){
	var Grid = Grid,
	Store = Data.Store,
	columns = [
	           {title : 'leadNo',dataIndex :'leadNo', width:100, elCls : 'center'},
	           {title : '公司名称',dataIndex :'companyName', width:200, elCls : 'center'},
	           {title : '法人姓名',dataIndex :'legalpersonName', width:200, elCls : 'center'},
	           {title : '根业务渠道商',dataIndex :'rootChannel', width:100, elCls : 'center'},
	           {title : 'Genius渠道商',dataIndex :'channelName', width:100, elCls : 'center'},
	           {title : '跟进时间',dataIndex :'lastDealTime', width:100, elCls : 'center', renderer:function(value,obj){
	        	   if(value !== null && value !== undefined && value !== ''){
	        		   return new Date(value).toLocaleString();
	        	   }else{
	        		   return;
	        	   }
	             }},
	           {title : '省',dataIndex : 'leadProvince', sortable: true, width:100, elCls : 'center'},
	           {title : '市',dataIndex : 'leadCity', sortable: true, width:100, elCls : 'center'},
	           {title : '会员类型',dataIndex : 'memberType', sortable: true, width:100, elCls : 'center'},
	           {title : '电销状态',dataIndex : 'telemarkingStatus', sortable: true, width:200, elCls : 'center',
	        	   renderer:function(value,obj){
	        		   if(value=='init'){
	        			   value='尚未联系';
	        		   }else if(value=='noDesire'){
	        			   value='暂无意愿';
	        		   }else if(value=='unallocatedNumber')
	        		   {
	        			   value='号码错误';
	        		   }else if(value=='abandonedCall'){
	        			   value=' 无人接听';
	        		   }else if(value == 'applySuccess'){
	        			   value='已经申贷';
	        		   }else if(value == 'prepareApply'){
	        			   value='准备申贷';
	        		   }else{
	        			   value=value;
	        		   }
	        		   return value;
	        	   }
	           }
	           ];

   var store = new Store({
	   url : '/telemarketing/queryLeadsbiz.json',
	   autoLoad:false, //自动加载数据
	   params : { //配置初始请求的参数
			telemarkingStatus: $.trim($("#telemarkingStatu").val()), 
			memberType: $.trim($("#memberType").val()),
			leadProvince: $.trim($("#leadProvince").val()), 
			leadCity: $.trim($("#leadCity").val()), 
			rootChannel : $.trim($("#rootChannel").val()),
			startTime : $.trim($("#startTime").val()),
			endTime : $.trim($("#endTime").val()),
			channelName : $.trim($("#channelName").val()),
			start: 0
		},
	   pageSize:500	// 配置分页数目
   }),

   grid = new Grid.Grid({
	   render:'#grid',
	   columns : columns,
	   loadMask: true, //加载数据时显示屏蔽层
	   store: store,
	   forceFit : true, //自适应宽度
	   itemStatusFields : { //设置数据跟状态的对应关系
		   selected : 'selected',
		   disabled : 'disabled'
	   },
	   plugins : [Grid.Plugins.CheckSelection],
	   // 顶部工具栏
	   tbar:{
		   items:[{
			   btnCls : 'button button-primary button-small recycleBtn',
			   text:'回收',
			   listeners : {
		           'click' : recycleFunction
		         }
		   }]
	   },
	   // 底部工具栏
	   bbar:{
		   // pagingBar:表明包含分页栏
		   pagingBar:true
	   }
   });

	grid.render();
	
	//这个操作，是为了只加载表格
    var form = new BUI.Form.HForm({
      srcNode : '#searchForm'
    }).render();

    form.on('beforesubmit',function(ev) {
    	//序列化成对象
    	var obj = form.serializeToObject();
    	obj.start = 0; //返回第一页
    	store.load(obj);
    	return false;
    });
	
	
	//回收选中lead
	function recycleFunction(){
		var selections = grid.getSelection();
		if(selections.length<=0){
			BUI.Message.Alert("请选择要回收的lead",'info');
			return;
		}
		BUI.Message.Confirm('确认要回收选中的'+selections.length+'条lead吗？',function(){
			var leadNos = '';
			for(var i=0; i<selections.length; i++){
				leadNos += selections[i].leadNo+',';
			}
			$.ajax({
				url: 'recycleLeads.json',
	            dataType:"json",
	            data: {
	            	leadNos : leadNos
	            },
	            type: "POST",
	            error: function(data){
	            	//BUI.Message.Alert("",'error');
	            },
	            success: function(data) {
	            	BUI.Message.Confirm(data.msg,function(){
	            		window.location.reload();
	            	},'info');
	            }                   
			});
		},'question');
		
	}
	
});