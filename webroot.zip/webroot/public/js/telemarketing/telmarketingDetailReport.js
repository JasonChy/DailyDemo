
			$(function(){
	String.prototype.replaceAll = function(s1,s2) { 
    return this.replace(new RegExp(s1,"gm"),s2); 
    }
    
	// 初始化任务表格

	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '支用编号',dataIndex :'bookApplySeqno',sortable: true, width:80,elCls : 'center'},
       {title : '渠道',dataIndex : 'scoredChannelName',sortable: false,width:80,elCls : 'center'},
       {title : '小二',dataIndex : 'scoredAgentName',sortable: false,width:80,elCls : 'center'},
       {title : '产品码',dataIndex : 'prodCode',sortable: false,width:80,elCls : 'center'},
       {title : '公司名',dataIndex : 'companyName',sortable: false,width:80,elCls : 'center'},
       {title : '法人',dataIndex : 'legalpersonName',sortable: false,width:80,elCls : 'center'},
       {title : '金额',dataIndex : 'amt',sortable: false,width:80,elCls : 'center'},
       {title : '佣金',dataIndex : 'commissionAmt',sortable: false,width:80,elCls : 'center'},
       {title : '申请类型',dataIndex : 'loanType',sortable: false,width:80,elCls : 'center'},
       {title : '支用时间',dataIndex : 'disburseDate',sortable: false,width:80,elCls : 'center'}
       ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:50,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		},
		listeners:{
			aftershow:function(){
				$(".showAll").on("click",function(){
					var value=$(this).attr("data-val");
					console.log(value);
					BUI.use('bui/overlay',function(Overlay){
					  var dialog = new Overlay.Dialog({
						title:'备注',
						width:500,
						height:500,
						mask:true,
                        buttons:[],
						bodyContent:"<div style='margin:5px;overlay-y:scroll;'>"+value+"</div>"						
					  });
					dialog.show();
				});	
				});
			}
			
		}
		
	});

	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	  return false;
	});
	
	function reload(){
	   var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	}
	
	
	
	});