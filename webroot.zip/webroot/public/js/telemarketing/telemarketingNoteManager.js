$(function(){
	var opArray=[];
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	enumObj = {"gzh" : "gzh","gzh2" : "gzh2"},
	columns = [
		{ title: '小记内容',width: 80, sortable: false, dataIndex: 'note',elCls : 'center'},
		{ title: '小记时间',width: 80,  sortable: false, dataIndex: 'gmtCreate',elCls : 'center' },
		{ title: '操作人',width: 80,  sortable: false, dataIndex: 'creator',elCls : 'center'},
		{ title: '操作',width: 80,  sortable: false, dataIndex: 'legalpersonContactway',
			elCls : 'center',
			renderer:function(value,obj){
				return '<span class="grid-command phoneBtn">修改</span>';
			}
		}
	  ],
	  editing = new Grid.Plugins.CellEditing({
	     triggerSelected : true //触发编辑的时候不选中行
	  }),
      store = new Store({
		 url: $("#btnSearch").data("url"),
		 autoLoad:true,
		 pageSize:1000000,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
			 leadNo:$("#leadNo").val()
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	 grid = new Grid.Grid({
			render:'#grid',
			loadMask: true,
			columns : columns,
			forceFit:true,
			// 顶部工具栏
			bbar : {
				//items 也可以在此配置
	            // pagingBar:表明包含分页栏
				pagingBar:true
			},
			store: store,
			plugins : [Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
		});
		grid.render();
		/*	$("#btnSearch").on("click",function(){
		    grid.render();
		});*/
		
		//没有数据，处理分页栏
		if(!store.getTotalCount()){
			$('#grid #totalPage').text("共 0 页");
		    $('#grid .bui-pb-page').val("0");
			$('#grid #totalCount').text("共0条记录");
		}
		//创建表单，表单中的日历，不需要单独初始化
		var form = new BUI.Form.HForm({
		  srcNode : '#searchForm'
		}).render();
		
		form.on('beforesubmit',function(ev) {
			//序列化成对象
			var obj = form.serializeToObject();
			obj.start = 0; //返回第一页
			store.load(obj);
		  	return false;
	    });
		
		function noteUpdateModal(data){
	    	console.log("data-------------->",data);
	    	var noX = data?data.result.resultObj.noX:"";
	    	var noteMsg = data.result.resultObj.note?data.result.resultObj.note:"";
	    	var subsId = data.result.resultObj.subsId?data.result.resultObj.subsId:"";
	    	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>小号：<span id="tipMsg" name="tipMsg">'+noX+'</span></p><p>小记：<textarea id="noteMsg" name="noteMsg" style="width:300px;height:100%;">'+noteMsg+'</textarea>&nbsp;<span style="color:red">200字符以内</span></p></div>';
	    	var Overlay = BUI.Overlay;
	        var dialog = new Overlay.Dialog({
	        	title:'修改小记',
		        width:450,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
	                text:'确定',
	                elCls : 'button button-primary',
	                handler:function(){
	                	var obj=this;
	    	        	var noteMsg=$("#noteMsg").val()?$("#noteMsg").val():"";
	    	        	$.ajax({
	    					url: 'updateNote.json',
	    		            dataType:"json",
	    		            data: {
	    		            	noX:noX,
	    		            	subsId:subsId,
	    		            	note:noteMsg
	    		            },
	    		            type: "POST",
	    		            error: function(data){
	    		            	BUI.Message.Alert('系统发生故障','error');
	    			            //$("#btnSearch").submit();
	    			            obj.destroy();
	    		            },
	    		            success: function(data) {
	    	            		 BUI.Message.Alert(data.result.message,'success');
	    	            		 setTimeout(function(){
				            		 window.location.reload();
				                 },2000);
	    	            		 obj.destroy();
	    		            }                   
	    				});
	    	        	//this.close();
	    	        }
	             },{
	                text:'取消',
	                elCls : 'button',
	                handler : function(){
	             	   this.destroy();
	                }
	             }]
	        });
	        dialog.show();
	    }
		
		grid.on('cellclick',function(ev) {
		        var record = ev.record, //点击行的记录
		        	field = ev.field, //点击对应列的dataIndex
		        	target = $(ev.domTarget); //点击的元素
		        console.log("zzzzzzzzz-------------------->",ev,target);//bui-select-input
		        if(target.hasClass('phoneBtn')){//修改小记
		        	//获取法人联系方式
		        	var subsId=record?record.subsId:"";
		        	if(subsId==undefined||subsId==""){
		        		return false;
		        	}
		        	var noX=record?record.noX:"";
		        	if(noX==undefined||noX==""){
		        		return false;
		        	}
		    		$.ajax({
		        		url: 'readNote.json',
			            dataType:"json",
			            data: {
			            	subsId:subsId,
			            	noX:noX
			            },
		                type: "POST",
		                error: function(data){
		                	BUI.Message.Alert('系统错误','error');
			   	            return false;
		                },
		                success: function(data) {
		                	if(!data.result.success){
		                		BUI.Message.Show({
		       	                  	msg : data.result.message,
		       	                  	icon : 'info',
		       	                  	width:400,
		       	                  	buttons : [],
		       	                  	autoHide :false 
		                    	});
		                	}else{
		                		noteUpdateModal(data);
		                	}
		                	
		                 }            
		             });
		        }
		        
		        if(target.hasClass('telemarkingStatusBtn')){//电销状态
		        	var telemarkingStatus=record?record.telemarkingStatus:"";
		        	var opDatas=$("#staffId").attr("data-staffid");
		        	if(opArray.length==0){
		        		$("#telemarkingStatu option").map(function(){
		            		var obj={};
		            		obj["key"]=$(this).val();
		            		obj["value"]=$(this).attr("data-value");
		            		opArray.push(obj);
		            	});
		        	}
		        	var options=getOptions(opArray,telemarkingStatus);
		        	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>请选择电销状态</p><select class="input-large" id="telemarkingStatus">'+options+'</select></div>';
		        	var Overlay = BUI.Overlay;
		            var dialog = new Overlay.Dialog({
		            	title:'提示',
				        width:400,
				        height:200,
				        bodyContent:msg,
				        success:function(){
				        	var telemarkingStatus=$("#telemarkingStatus option:selected").val()?$("#telemarkingStatus option:selected").val():"";
				        	var leadNo=record?record.leadNo:"";
				        	$.ajax({
								url: 'updateLeadStatus.json',
					            dataType:"json",
					            data: {
					            	leadNo:leadNo,
					            	telemarkingStatus:telemarkingStatus
					            },
					            type: "POST",
					            error: function(e){
					            	BUI.Message.Alert('修改失败','error');
						            $("#btnSearch").submit();

					            },
					            success: function(data) {
				            		 BUI.Message.Alert('修改成功','success');
						            //$("#btnSearch").submit();
					            	//$("#btnSearch").trigger("click");
					            	 setTimeout(function(){
					            		 window.location.reload();
					                 },2000);
					            }                   
							});
				        	this.close();
				        }
		            });
		            dialog.show();
		        }
		    });
	
/*	$("#btnSearch").on("click",function(){
        
    });*/
	
	//创建表单，表单中的日历，不需要单独初始化
//    var form = new BUI.Form.HForm({
//      srcNode : '#searchForm'
//    }).render();

//    function noteAddModal(data){
//    	console.log("data-------------->",data);
//    	var tipMsg = data?data.result.message:"";
//    	var subsId = data?data.result.resultObj:"";
//    	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>小号：<span id="tipMsg" name="tipMsg">'+tipMsg+'</span></p><p>小记：<textarea id="noteMsg" name="noteMsg" style="width:300px;height:100%;"></textarea></p></div>';
//    	var Overlay = BUI.Overlay;
//        var dialog = new Overlay.Dialog({
//        	title:'提示',
//	        width:400,
//	        height:200,
//	        bodyContent:msg,
//	        buttons:[{
//                text:'确定',
//                elCls : 'button button-primary',
//                handler:function(){
//                	var obj=this;
//    	        	var noteMsg=$("#noteMsg").val()?$("#noteMsg").val():"";
//    	        	$.ajax({
//    					url: 'updateNote.json',
//    		            dataType:"json",
//    		            data: {
//    		            	subsId:subsId,
//    		            	noteMsg:noteMsg
//    		            },
//    		            type: "POST",
//    		            error: function(data){
//    		            	BUI.Message.Alert('系统发生故障','error');
//    			            //$("#btnSearch").submit();
//    			            obj.destroy();
//    		            },
//    		            success: function(data) {
//    	            		 BUI.Message.Alert(data.result.message,'success');
//    	            		 obj.destroy();
//    		            }                   
//    				});
//    	        	//this.close();
//    	        }
//             },{
//                text:'取消',
//                elCls : 'button',
//                handler : function(){
//             	   this.destroy();
//                }
//             }]
//        });
//        dialog.show();
//    }
	/**
	 * 下拉菜单设置
	 */
//	function getOptions(map, value) {
//		var rst = [];
//		BUI.each(map, function(v, k) {
//			if(v.key != ''){
//			var selected = value === v.key ? 'selected' : '';
//			var str = '<option ' + selected + ' value="' + v.key + '">' + v.value + '</option>';
//			rst.push(str);
//			}
//		});
//		return rst;
//	}
	
//    grid.on('cellclick',function(ev) {
//        var record = ev.record, //点击行的记录
//        	field = ev.field, //点击对应列的dataIndex
//        	target = $(ev.domTarget); //点击的元素
//        console.log("zzzzzzzzz-------------------->",ev,target);//bui-select-input
//        if(target.hasClass('phoneBtn')){//修改小记
//        	//获取法人联系方式
//        	var leadNo=record?record.leadNo:"";
//        	if(leadNo==undefined||leadNo==""){
//        		return false;
//        	}
//    		$.ajax({
//        		url: 'updateNote.json',
//	            dataType:"json",
//	            data: {
//	            	leadNo:leadNo
//	            },
//                type: "POST",
//                error: function(data){
//                	BUI.Message.Alert('调用失败','error');
//	   	            return false;
//                },
//                success: function(data) {
//                	if(!data.result.success){
//                		BUI.Message.Show({
//       	                  	msg : data.result.message,
//       	                  	icon : 'success',
//       	                  	width:400,
//       	                  	buttons : [],
//       	                  	autoHide :false 
//                    	});
//                	}else{
//                		noteAddModal(data);
//                	}
//                	
//                 }            
//             });
//        }
//        if(target.hasClass('telemarkingStatusBtn')){//电销状态
//        	var telemarkingStatus=record?record.telemarkingStatus:"";
//        	var opDatas=$("#staffId").attr("data-staffid");
//        	if(opArray.length==0){
//        		$("#telemarkingStatu option").map(function(){
//            		var obj={};
//            		obj["key"]=$(this).val();
//            		obj["value"]=$(this).attr("data-value");
//            		opArray.push(obj);
//            	});
//        	}
//        	var options=getOptions(opArray,telemarkingStatus);
//        	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>请选择电销状态</p><select class="input-large" id="telemarkingStatus">'+options+'</select></div>';
//        	var Overlay = BUI.Overlay;
//            var dialog = new Overlay.Dialog({
//            	title:'提示',
//		        width:400,
//		        height:200,
//		        bodyContent:msg,
//		        success:function(){
//		        	var telemarkingStatus=$("#telemarkingStatus option:selected").val()?$("#telemarkingStatus option:selected").val():"";
//		        	var leadNo=record?record.leadNo:"";
//		        	$.ajax({
//						url: 'updateLeadStatus.json',
//			            dataType:"json",
//			            data: {
//			            	leadNo:leadNo,
//			            	telemarkingStatus:telemarkingStatus
//			            },
//			            type: "POST",
//			            error: function(e){
//			            	BUI.Message.Alert('修改失败','error');
//				            $("#btnSearch").submit();
//
//			            },
//			            success: function(data) {
//		            		 BUI.Message.Alert('修改成功','success');
//				            //$("#btnSearch").submit();
//			            	//$("#btnSearch").trigger("click");
//			            	 setTimeout(function(){
//			            		 window.location.reload();
//			                 },2000);
//			            }                   
//					});
//		        	this.close();
//		        }
//            });
//            dialog.show();
//        }
//        if(target.hasClass('totalBtn')){//查看小计
//        	//获取小计链接并跳转
//        	var leadNo=record?record.leadNo:"";
//        	$.ajax({
//        		url: 'viewNote.json',
//	            dataType:"json",
//	            data: {
//	            	leadNo:leadNo
//	            },
//                type: "POST",
//                error: function(data){
//                	BUI.Message.Alert('获取失败','error');
//	   	            return false;
//                },
//                success: function(data) {
//                	//跳转设置
//                	//window.location.href="http://www.baidu.com";
//                	window.open("/telemarketing/queryLeads.htm");//新页面打开小计详情页面
//                 }            
//             });
//        }
//    });
 
    //分发
//    $(".distributeBtn").on("click",function(){
//    	var selectAssignRow = grid.getSelection();		
//        if(selectAssignRow.length<=0){
//			BUI.Message.Alert('请选择要分发的任务','info');
//			return false;
//		}
//        console.log("selectAssignRow----------->",selectAssignRow);
//        var leadNos="";
//		for(var i=0;i<selectAssignRow.length;i++){
//			leadNos+=selectAssignRow[i].leadNo+",";
//		}
//		var ckLeadNos=leadNos;
//		var userData=[];
//		if(selectAssignRow.length>0){
//			//获取用户信息
//			$.ajax({
//	    		url: 'getGroupUsers.json',
//	    		dataType:"json",
//	    		data: {},
//	    		async:false,
//	    		type: "POST",
//	    		error: function(e){
//	    			BUI.Message.Alert('信息获取失败','error');
//	    		},
//	    		success: function(data) {
//	    	        console.log("data----------->",data);
//	    	        if(data && data.groupUsers.length<1){
//	    	        	BUI.Message.Alert('暂无可分配的员工账号','error');
//	    	        	return false;
//	    	        }
//	    			for(var i = 0;i < data.groupUsers.length;i++){
//	            		var obj={};
//	            		obj["key"]=data.groupUsers[i].userName;
//	            		obj["value"]=data.groupUsers[i].realName;
//	            		userData.push(obj);
//	    			}
//	    		}                   
//	    	});
//			//弹出模态框设置
//		    var options=getOptions(userData);
//        	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>请选择</p><select class="input-large" id="staffId">'+options+'</select></div>';
//        	var Overlay = BUI.Overlay;
//            var dialog = new Overlay.Dialog({
//            	title:'提示',
//		        width:400,
//		        height:200,
//		        bodyContent:msg,
//		        success:function(){
//		         	//获取员工Id
//			    	var staffId=$("#staffId option:selected").val()?$("#staffId option:selected").val():"";
//			    	if(staffId==undefined || staffId==""){
//			    		BUI.Message.Alert('请选择需要分配的员工账号','error');
//			    		return false;
//			    	}
//			    	//修改跟进人
//			    	$.ajax({
//			    		url: 'updateLeadsDealer.json',
//			    		dataType:"json",
//			    		data: {
//			    			staffId:staffId,
//			    			leadNos:ckLeadNos
//			    		},
//			    		type: "POST",
//			    		error: function(e){
//			    			BUI.Message.Alert('提交失败','error');
//			    		},
//			    		success: function(data) {
//			            	BUI.Message.Alert('提交成功','success');
//			            	 setTimeout(function(){
//			            		 window.location.reload();
//			                 },2000);
//			    		}                   
//			    	});
//			    	this.close();
//		        }
//            });
//            dialog.show();
//            /*var Overlay = BUI.Overlay,
//		    Form = BUI.Form;
//		    var form = new Form.HForm({
//		    	srcNode : '#form'
//		    }).render();*/
////		    var dialog = new Overlay.Dialog({
////			    title:'提示',
////			    width:400,
////			    height:200,
////			    contentId:'distributeContent',
////			    success:function(){
////			    	//获取员工Id
////			    	var staffId=$("#sta" +
////			    			"ffId option:selected").val()?$("#staffId option:selected").val():"";
////			    	if(staffId==undefined || staffId==""){
////			    		BUI.Message.Alert('请选择需要分配的员工账号','error');
////			    		return false;
////			    	}
////			    	//修改跟进人
////			    	$.ajax({
////			    		url: 'updateLeadsDealer.json',
////			    		dataType:"json",
////			    		data: {
////			    			staffId:staffId,
////			    			leadNos:ckLeadNos
////			    		},
////			    		type: "POST",
////			    		error: function(e){
////			    			BUI.Message.Alert('提交失败','error');
////			    		},
////			    		success: function(data) {
////			            	BUI.Message.Alert('提交成功','success');
////			    			$("#btnSearch").submit();
////			    		}                   
////			    	});
////			    	this.close();
////		    	}
////	    	});
////	    	dialog.show();
//		}
//    });
    

});