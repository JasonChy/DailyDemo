
			$(function(){
	String.prototype.replaceAll = function(s1,s2) { 
    return this.replace(new RegExp(s1,"gm"),s2); 
    }
	// 初始化任务表格
	var newDate = new Date();
	  var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
	   {title : '编号',dataIndex :'id',sortable: true, width:80,elCls : 'center'},
       {title : '会员类型',dataIndex :'memberType',sortable: false, width:80,elCls : 'center'},
       {title : '省份',dataIndex : 'province',sortable: false,width:80,elCls : 'center'},
       {title : '城市',dataIndex : 'city',sortable: false,width:80,elCls : 'center'},
       {title : '根业务渠道商',dataIndex : 'rootChannel',sortable: false,width:80,elCls : 'center'},
       {title : '优先级',dataIndex : 'ruleOrder',sortable: false,width:80,elCls : 'center'},
       {title : '分发数量',dataIndex : 'dispCount',sortable: false,width:80,elCls : 'center'},
       {title : '接收渠道商编码',dataIndex : 'channelCode',sortable: false,width:80,elCls : 'center'},
       {title : '接收渠道商名称',dataIndex : 'channelName',sortable: false,width:80,elCls : 'center'},
        {title : '创建时间',dataIndex : 'gmtCreate',sortable: false,width:80,elCls : 'center',renderer:function(value,obj){
          newDate.setTime(value);
          return newDate.toLocaleString();
        }},
        {title : '操作',dataIndex : 'isDelete',sortable: false,width:80,elCls : 'center',renderer:function(value,obj){
            return '<a href="javascript:void(0);" data-id="'+obj.id+'" class="edit" data-memberType="'+obj.memberType+'" data-dispCount="'+obj.dispCount+'" data-province="'+obj.province+' " data-city="'+obj.city+' " data-ruleOrder="'+obj.ruleOrder+' " data-channelCode="'+obj.channelCode+' " data-channelName="'+obj.channelName+' "  data-rootChannel="'+obj.rootChannel+'">修改规则</a> | '+
            '<a href="javascript:void(0);" data-id="'+obj.id+'" class="delete">删除规则</a>'+
            '<br/>';
        }} ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:10,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		},
		listeners:{
			aftershow:function(){
				$(".showAll").on("click",function(){
					var value=$(this).attr("data-val");
					console.log(value);
					BUI.use('bui/overlay',function(Overlay){
					  var dialog = new Overlay.Dialog({
						title:'备注',
						width:500,
						height:500,
						mask:true,
                        buttons:[],
						bodyContent:"<div style='margin:5px;overlay-y:scroll;'>"+value+"</div>"						
					  });
					dialog.show();
				});	
				});
			}
			
		}
		
	});

	grid.render();

	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	
	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	  return false;
	});
	
	function reload(){
	   var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	  var page=$('#grid .bui-pb-page').val();                        
	  obj.pageIndex = page-1;
	  store.load(obj);
	}
	
	$("#grid").on("click",".delete",function(){
          var id=$(this).attr("data-id"); 
            BUI.Message.Confirm('确认要删除吗？',function(){
                  jQuery.ajax({
                        type:"post",
                        url:delete_org_url,
                        dataType:"json",
                        data:{
                          id:id
                        },
                        success:function(data){
                            BUI.Message.Show({
                                msg : data.result.resultMsg,
                                icon : 'error',
                                width:200,
                                buttons : [],
                                autoHide :false 
                             });
                            reload();                         
                         }
                   });
            });     
 });     
        
	
	
	
	 BUI.use('bui/overlay',function(Overlay){
       assgindialog = new Overlay.Dialog({
                title:'添加绑定账号',
                width:650,
                height:400,
                mask:true,
                 buttons:[
                    {
                        text:'取消',
                        elCls : 'button',
                        handler : function(){ 
                        	suggestContainer.hide();
                            this.close();
                        }
                    },{
                        text:'确定',
                        elCls:'button',
                        handler:function(){
                           var url=this.flag=="add"?add_org_url :update_org_url;  
                           var ruleOrder = $("#ruleOrder").val();
                           var dispCount = $("#dispCount").val();
                           var memberType =$("#memberType").val();
                           var province   =$("#province").val();
                           var city      = $("#city").val();
                           var rootChannel = $("#rootChannel").val();
                           var channelCode = $("#ruleOrgCode").val();
                           if(!memberType){
                               BUI.Message.Show({
                                       msg : '会员类型不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!province){
                               BUI.Message.Show({
                                       msg : '省份不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!city){
                               BUI.Message.Show({
                                       msg : '城市不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!rootChannel){
                               BUI.Message.Show({
                                       msg : '根渠道商不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(rootChannel.trim()=='全部'){
                               BUI.Message.Show({
                                       msg : '根渠道商不能填全部',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!ruleOrder){
                               BUI.Message.Show({
                                       msg : '分配优先级不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!/\d+/.test(ruleOrder)){
                               BUI.Message.Show({
                                       msg : '优先级为整数',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }
                           if(!dispCount){
                               BUI.Message.Show({
                                       msg : '分配数量不能为空',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }

                           if(!/\d+/.test(dispCount)){
                               BUI.Message.Show({
                                       msg : '分配数量为整数',
                                       icon : 'error',
                                       width:200,
                                       buttons : [],
                                       autoHide :false 
                                  });
                                 return false;
                           }

                            
                            jQuery.ajax({
                            url: url,
                            dataType:"json",
                            data: $('#form').serialize(),
                            type: "POST",
                            error: function(e) {            
                            BUI.Message.Show({
                                        msg : '提交失败',
                                        icon : 'error',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                                    });
                            },
                            success: function(data) {
                            BUI.Message.Show({
                                        msg : data.result.resultMsg,
                                        icon : 'success',
                                        width:200,
                                        buttons : [],
                                        autoHide :false 
                              });
                           reload();
                              
                            }                   
                       });
                       this.close(); 
                      } 
                       
                    } 
                ],
                bodyContent:'',
                listeners:{
                    closeclick:function(){
                        grid.render();
                    }
                }
        });
  });
	 

	    
	      var str='<div id="content" ><form id="form" >'+
	      '<div class="control-group"> <label class="control-label">会员类型:</label> <div class="controls "><input type="text" class="province" name="memberType" id="memberType"> </div>  </div>'+
	      '<div class="control-group"> <label class="control-label">省份:</label> <div class="controls "><input type="text" class="province" name="province" id="province"> </div>  </div>'+
	      '<div class="control-group"> <label class="control-label">城市:</label> <div class="controls "><input type="text" class="province" name="city" id="city"> </div>  </div>'+
	      '<div class="control-group"> <label class="control-label">根业务渠道商:</label> <div class="controls "><input type="text" class="province" name="rootChannel" id="rootChannel"> </div>  </div>'+
	      '<div class="control-group"> <label class="control-label">优先级:</label> <div class="controls "><input type="text" class="province" name="ruleOrder" id="ruleOrder"> </div>  </div>'+
	      '<div id="inputContent"></div>'+
	      '<div class="control-group"> <label class="control-label">分发数量:</label> <div class="controls "><input type="text" class="province" name="dispCount" id="dispCount"> </div>  </div>'+
//	      '<div class="control-group"> <label class="control-label">接收渠道商:</label> <div class="controls " id="a_channel"><select name="channelCode" id="a_channelCode">'+
	      '<div class="control-group"> <label class="control-label">接收渠道商:</label> '+
	      '<div class="controls ">'+
	      '<input type="text" id="testInput" name="channelName" oninput=valueChange() onblur=focusLose()  autocomplete="off"/>'+
	      '<input id="ruleOrgCode" name="channelCode" type="hidden"/> </div>  </div>'+
	      '</form></div>';
	
	 $(".add_org_rule").on("click",function(){
		  assgindialog.set("bodyContent","");
          assgindialog.set("bodyContent",str);
          assgindialog.set("title","添加分配规则");
          assgindialog.flag="add";
          $("#inputContent").html("");
          assgindialog.show();
//          $("#a_channelCode").html(channelOption());
         		  
           
      });
	 
	
	
	$("#grid").on("click",".edit",function(){    
        assgindialog.set("bodyContent","");
        assgindialog.set("bodyContent",str); 
        assgindialog.flag="update";
        assgindialog.set("title","修改分配规则");
        assgindialog.show();        
        $("#inputContent").html("<input type='hidden' name='id' value='"+$(this).attr("data-id")+"'>");
        $("#ruleOrgCode").val($(this).attr("data-channelCode"));
        $("#testInput").val($(this).attr("data-channelName"));
		
		if($(this).attr("data-memberType")&&'undefined'!==$(this).attr("data-memberType").trim()){
			$("#memberType").val($(this).attr("data-memberType"));
		}
		if($(this).attr("data-province")&&'undefined'!==$(this).attr("data-province").trim()){
			$("#province").val($(this).attr("data-province"));	
		}
		if($(this).attr("data-city")&&'undefined'!==$(this).attr("data-city").trim()){
			$("#city").val($(this).attr("data-city"));	
		} 
		if($(this).attr("data-rootChannel")&&'undefined'!==$(this).attr("data-rootChannel").trim()){
			$("#rootChannel").val($(this).attr("data-rootChannel"));	
		}
		if($(this).attr("data-ruleOrder")&&'undefined'!==$(this).attr("data-ruleOrder").trim()){
			$("#ruleOrder").val($(this).attr("data-ruleOrder"));	
		}
		if($(this).attr("data-dispCount")&&'undefined'!==$(this).attr("data-dispCount").trim()){
			$("#dispCount").val($(this).attr("data-dispCount"));	
		}
	});	
		
	
	
	});
			
function channelOption(selected){
	var option = "";
	jQuery.ajax({
        type:"post",
        url:"/telemarketing/queryChannelAjax.json",
        dataType:"json",
        async: false,
        data:{
       	 channelName:'',
       	 groupCode:''
        },
        success:function(data){
       	 for(i=0;i<data.results;i++){
       	 option += '<option value ="'+data.rows[i].groupCode+'" '+(data.rows[i].groupCode===selected?'selected':'')+'>'+data.rows[i].channelName+'</option>';
       	 }
         }
   });
   return option;
}

function getOption(){
	var option = "[";
	jQuery.ajax({
        type:"post",
        url:"/telemarketing/queryChannelAjax.json",
        dataType:"json",
        async: false,
        data:{
       	 channelName:'',
       	 groupCode:''
        },
        success:function(data){
       	 for(i=0;i<data.results;i++){
       	 option += '{"name":"'+ data.rows[i].channelName +'","code":"' + data.rows[i].groupCode +'"},';
       	 }
       	option = option.substring(0,option.length-1);
       	option += "]";
         }
   });
   return option;
}



	
/**
	* 搜索下拉列表
	**/
function valueChange() {
	$('#ruleOrgCode').val("");
    var items = inputChange(); //搜索数据并获取搜索结果
    if (items != undefined && items.length!=0) {
        _initItems(items);
    }else{
    	suggestContainer.hide();
    }
}



var datas =  JSON.parse(getOption());//定义数据	

//1：搜索数据
var inputChange = function() {
    var inputValue = $('#testInput').val();

    if (inputValue != "") {
        var matcher = new RegExp(inputValue, "i");
        return $.grep(datas,
        function(value) {
            return matcher.test(value.name);
        });
    } 

};
var maxFontNumber = 0; //最大字数
var suggestContainer = $('<div></div>'); //创建一个子<div>
suggestContainer.attr('id', "testInput-suggest");
suggestContainer.attr('tabindex', '0');
suggestContainer.hide();

//2：初始化搜索到的数据进行显示
var _initItems = function(items) {
    $('#ruleOrgCode').val("");
    suggestContainer.empty();
    for (var i = 0; i < items.length; i++) {
        if (items[i].name.length > maxFontNumber) {
            maxFontNumber = items[i].name.length;
        }
        var suggestItem = $('<div></div>'); //创建一个子<div>
        suggestItem.attr('code', items[i].code);
        suggestItem.append(items[i].name);
        suggestItem.css({
            'padding': '3px',
            //item间距
            'white-space': 'nowrap',
            'cursor': 'pointer',
            'background-color': 'RGB(199,237,204)',
            //默认背景颜色
            'color': '#000000' //默认字体颜色
        });
        suggestItem.bind("mouseover",
        function() {
            $(this).css({
                'background-color': '#C9302C',
                //选中背景颜色
                'color': '#ffffff' //选中字体颜色
            });
        });
        suggestItem.bind("mouseout",
        function() {
            $(this).css({
                'background-color': 'RGB(199,237,204)',
                //默认背景颜色
                'color': '#000000' //默认字体颜色
            });
        });
        suggestItem.bind("click", showClickTextFunction); //选中后处理数据
        //suggestItem.bind("click", itemSelectFunction);
        suggestItem.appendTo(suggestContainer);
        suggestContainer.appendTo(document.body);
    }
    suggestContainer.removeAttr("style");
    suggestContainer.css({
        'border': '1px solid #ccc',
        'max-height': '200px',
        'top': $('#testInput').offset().top + $('#testInput').outerHeight(),
        'left': $('#testInput').offset().left,
        'width': 12 * maxFontNumber + 2 * 3 + 30,
        'position': 'absolute',
        'font-size': '12px',
        //默认字体大小
        'font-family': 'Arial',
        'z-index': 99999,
        'background-color': '#FFFFFF',
        'overflow-y': 'auto',
        'overflow-x': 'hidden',
        'white-space': 'nowrap'

    });
    maxFontNumber = 0;
    suggestContainer.show();
};

//3.选中后处理数据
var showClickTextFunction = function() {
    //alert(this.innerText + "---" + this.getAttribute("code"));
    $('#testInput').val(this.innerText);
    $('#ruleOrgCode').val(this.getAttribute("code"));
    suggestContainer.hide();
};
