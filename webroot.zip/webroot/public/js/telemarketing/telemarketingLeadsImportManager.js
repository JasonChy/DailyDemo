$(function(){
	var opArray=[];
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	columns = [
	    { title: '创建时间',width: 10,  sortable: false, dataIndex: 'gmtCreate',elCls : 'center'},
		{ title: '修改时间',width: 10,  sortable: false, dataIndex: 'gmtModified',elCls : 'center'},
		{ title: 'Leads编号',width: 10,  sortable: false, dataIndex: 'leadNo',elCls : 'center' },
		{ title: 'Leads类型',width: 10,  sortable: false, dataIndex: 'leadType',elCls : 'center' },
		{ title: 'Leads省份',width: 10,  sortable: false, dataIndex: 'leadProvince',elCls : 'center'},
		{ title: 'Leads城市',width: 10,  sortable: false, dataIndex: 'leadProvince',elCls : 'center'},
		{ title: '分配状态',width: 10,  sortable: false, dataIndex: 'updateResult',elCls : 'center'},
		{ title: '分配结果详情',width: 40,  sortable: false, dataIndex: 'updateFailInfo',elCls : 'center'}
	  ],
      store = new Store({
		 url: "/telemarketing/queryleadsImportResultAjax.json",
		 autoLoad:true,
		 pageSize:1000000,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
             start : 0
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	
	 grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		columns : columns,
		forceFit:true,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
            // pagingBar:表明包含分页栏
			pagingBar:true
		},
		store: store,
		plugins : [Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
	});
	grid.render();
	/*	$("#btnSearch").on("click",function(){
	    grid.render();
	});*/
	
	//没有数据，处理分页栏
	if(!store.getTotalCount()){
		$('#grid #totalPage').text("共 0 页");
	    $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		var obj = form.serializeToObject();
		obj.start = 0; //返回第一页
		store.load(obj);
	  	return false;
    });
	
});