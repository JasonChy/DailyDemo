$(function(){
	var opArray=[];
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	columns = [
		{ title: '公司名称',width: 80, sortable: true, dataIndex: 'companyName',elCls : 'center'},
		{ title: '法人姓名',width: 80,  sortable: true, dataIndex: 'legalpersonName',elCls : 'center' },
		{ title: '法人联系方式',width: 80,  sortable: true, dataIndex: 'legalpersonContactway',
			elCls : 'center',
			renderer:function(value,obj){
				return '<span class="grid-command phoneBtn">查看电话</span>';
			}
		},
		{ title: '建议申贷账号类型',width: 80,  sortable: true, dataIndex: 'memberType',elCls : 'center'},
		{ title: '贷款状态',width: 80,  sortable: true, dataIndex: 'noteOne',elCls : 'center'},
		{ title: '补充信息',width: 80,  sortable: true, dataIndex: 'noteTwo',elCls : 'center'},
		{ title : '电销状态',width: 60, sortable: true,dataIndex : 'telemarkingStatus',elCls : 'center',
			renderer:function(value,obj){
				if(value=='init'){
					  value='尚未联系';
					}else if(value=='noDesire'){
					  value='暂无意愿';
					}else if(value=='unallocatedNumber')
					{
					   value='号码错误';
					}else if(value=='abandonedCall'){
					   value=' 无人接听';
					}else if(value == 'applySuccess'){
						value='已经申贷';
					}else if(value == 'prepareApply'){
						value='准备申贷';
					}else{
						value=value;
					}
			return '<span class="grid-command telemarkingStatusBtn">'+value+'</span>';
		}
		},
		{ title: '跟进人', width: 80,  sortable: true, elCls : 'center' ,dataIndex: 'dealerRealName'},
		{ title: '最后跟进时间', width: 80,  sortable: true, elCls : 'center' ,dataIndex: 'lastDealDate'},
		{ title: '剩余时间', width: 80,  sortable: true, elCls : 'center' ,dataIndex: 'remainingDays'},
		{ title: '小计', width: 80,  sortable: true, elCls : 'center' ,dataIndex: 'dealer',
			renderer:function(value,obj){
				return '<span class="grid-command totalBtn">查看</span>';
			}
		},
		{ title: '操作', width: 80,  sortable: true, elCls : 'center' ,dataIndex: '',
			renderer:function(value,obj){
				return '<a href="/telemarketing/sendBackLead.htm?leadNo='+obj.leadNo+'" class="grid-command">退回</a>';
			}
		}
	  ],
	  editing = new Grid.Plugins.CellEditing({
	     triggerSelected : true //触发编辑的时候不选中行
	  }),
      store = new Store({
		 url: $("#btnSearch").data("url"),
		 autoLoad:true,
		 pageSize:10,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
             start : 0
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	
	 grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		columns : columns,
		forceFit:true,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
            // pagingBar:表明包含分页栏
			pagingBar:true
		},
		store: store,
		plugins : [editing,Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
	});
	grid.render();
	
/*	$("#btnSearch").on("click",function(){
        grid.render();
    });*/
	
	//没有数据，处理分页栏
	if(!store.getTotalCount()){
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	//创建表单，表单中的日历，不需要单独初始化
    var form = new BUI.Form.HForm({
      srcNode : '#searchForm'
    }).render();

    form.on('beforesubmit',function(ev) {
    	//序列化成对象
    	var obj = form.serializeToObject();
    	obj.start = 0; //返回第一页
    	store.load(obj);
    	return false;
    });
    
    function noteAddModal(data,leadNo){
    	console.log("data-------------->",data);
    	var noX = data?data.result.message:"";
    	var subsId = data?data.result.resultObj:"";
    	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p style="margin-left: 120px;">小号：<span id="tipMsg" name="tipMsg">'+noX+'</span></p><p style="margin-left: 120px;">小记：<textarea id="noteMsg" name="noteMsg" style="width:300px;height:100%;"></textarea></p>'
    	+'<p>法人手机号码（如需修改）：<input id="cellphone" name="cellphone" style="width:300px;height:100%;" onchange="checkCellphoneNumber(this.value)"></input></p>'
    	+'<p><input type="checkbox" style="margin-left: 120px;" id="isSendMsg">是否发送短信</p>'
    	+'<p id="showSendMsg" style="display:none;margin-left: 120px;">发送短信类型:'+getOptionsSel(sendList)+'</p>'
    	+'</div>';
    	var Overlay = BUI.Overlay;
        var dialog = new Overlay.Dialog({
        	title:'提示',
	        width:600,
	        height:350,
	        bodyContent:msg,
	        buttons:[{
                text:'确定',
                elCls : 'button button-primary',
                handler:function(){
                	var obj=this;
    	        	var noteMsg=$("#noteMsg").val()?$("#noteMsg").val():"";
    	        	var cellphone = $("#cellphone").val()?$("#cellphone").val():null;
    	        	var extraInfo;
    	        	if(cellphone!=null){
    	        		extraInfo = '{"cellphone":"'+cellphone+'"}';
    	        	}
    	        	var sendMsgSelected = $("#isSendMsg")[0].checked? $("#sendMsgSelected").val():'';
    	        	$.ajax({
    					url: 'updateNote.json',
    		            dataType:"json",
    		            data: {
    		            	noX:noX,
    		            	subsId:subsId,
    		            	note:noteMsg,
    		            	extraInfo:extraInfo,
    		            	leadNo:leadNo,
    		            	templateId:sendMsgSelected
    		            },
    		            type: "POST",
    		            error: function(data){
    		            	BUI.Message.Alert('系统发生故障','error');
    			            //$("#btnSearch").submit();
    			            obj.destroy();
    		            },
    		            success: function(data) {
    		            	if(data.result.success){
    		            		BUI.Message.Alert(data.result.message,'success');
    		            		obj.destroy();
    		            	}else{
    		            		BUI.Message.Alert(data.result.message,'success');
    		            	}
    		            }                   
    				});
    	        	//this.close();
    	        }
             },{
                text:'取消',
                elCls : 'button',
                handler : function(){
             	   this.destroy();
                }
             }]
        });
        dialog.show();
        $("#isSendMsg").click(function(){
        	if(this.checked){
        	 $("#showSendMsg").show();
        	}else{
        	 $("#sendMsgSelected").val('')
             $("#showSendMsg").hide();
        	}
        	
        });
    }

    /**
     * 检查手机号码是否输入正确
     */
    function checkCellphoneNumber(number){
    	number = $.trim(number);
    	if(number==undefined||number==""){
    		return;
    	}
    	var regex = /\d{10,12}$/;
    	if(!(regex.test(number))){ 
    		BUI.Message.Show({
    			msg : "手机号码有误",
    			icon : 'info',
    			width:400,
    			buttons : [],
    			autoHide :true 
    		});
    		return false; 
    	} 
    }
    
    
	/**
	 * 下拉菜单设置
	 */
	function getOptions(map, value) {
		var rst = [];
		BUI.each(map, function(v, k) {
			if(v.key != ''){
				var selected = value === v.key ? 'selected' : '';
				var str = '<option ' + selected + ' value="' + v.key + '">' + v.value + '</option>';
				rst.push(str);
			}
		});
		return rst;
	}
	function getOptionsSel(map) {
		var rst = [];
		rst.push('<select name="templateId" id="sendMsgSelected">');
		for(key in map){  
	    var str = '<option   value="' + key + '">' +map[key] + '</option>';
	    rst.push(str);
		} 
		rst.push('</select>');
		return rst;
	}
	
    grid.on('cellclick',function(ev) {
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        if(target.hasClass('phoneBtn')){//查看电话
        	//获取法人联系方式
        	var leadNo=record?record.leadNo:"";
        	if(leadNo==undefined||leadNo==""){
        		return false;
        	}
    		$.ajax({
        		url: 'bind.json',
	            dataType:"json",
	            data: {
	            	leadNo:leadNo
	            },
                type: "POST",
                error: function(data){
                	BUI.Message.Alert('请求失败','error');
	   	            return false;
                },
                success: function(data) {
                	if(!data.result.success){
                		BUI.Message.Show({
       	                  	msg : data.result.message,
       	                  	icon : 'info',
       	                  	width:400,
       	                  	buttons : [],
       	                  	autoHide :false 
                    	});
                	}else{
                		noteAddModal(data,leadNo);
                	}
                	
                 }            
             });
        }
        
        if(target.hasClass('telemarkingStatusBtn')){//电销状态
        	var telemarkingStatus=record?record.telemarkingStatus:"";
        	var opDatas=$("#staffId").attr("data-staffid");
        	var leadNo=record?record.leadNo:"";
        	if(opArray.length==0){
        		$("#telemarkingStatu option").map(function(){
            		var obj={};
            		obj["key"]=$(this).val();
            		obj["value"]=$(this).attr("data-value");
            		opArray.push(obj);
            	});
        	}
        	var options=getOptions(opArray,telemarkingStatus);
        	var msg = '<div style="margin-left: 20px;margin-top:10px;"><p>请选择电销状态</p><select class="input-large" id="telemarkingStatus">'+options+'</select></div>';
        	var Overlay = BUI.Overlay;
            var dialog = new Overlay.Dialog({
            	title:'修改电销状态',
		        width:400,
		        height:200,
		        bodyContent:msg,
		        buttons:[{
	                   text:'确定',
	                   elCls : 'button button-primary',
	                   handler : function(){
	                	var obj=this;
	   		        	var telemarkingStatus=$("#telemarkingStatus option:selected").val()?$("#telemarkingStatus option:selected").val():"";
			        	$.ajax({
							url: 'updateLeadStatus.json',
				            dataType:"json",
				            data: {
				            	leadNo:leadNo,
				            	telemarkingStatus:telemarkingStatus
				            },
				            type: "POST",
				            error: function(e){
				            	BUI.Message.Alert('修改失败','error');
				            	setTimeout(function(){
				            		 window.location.reload();
				                 },2000);
				            	obj.destroy();
				            },
				            success: function(data) {
				            	if(data.success){
				            		 BUI.Message.Alert('修改成功','success');
					            	 setTimeout(function(){
					            		 window.location.reload();
					                 },2000);
				            	}else{
				                	BUI.Message.Alert('修改电销状态失败,'+data.message,'error');
				            	}
				            	obj.destroy();
				            }                   
						});
			        }
	                },{
		        	 text:'取消',
	                   elCls : 'button',
	                   handler : function(){
	                	   this.destroy();
	                   }
		        }],
            });
            dialog.show();
        }
        
        if(target.hasClass('totalBtn')){//查看小计
        	//获取小计链接并跳转
        	var leadNo=record?record.leadNo:"";
        	$.ajax({
        		url: 'viewNotes.json',
	            dataType:"json",
	            data: {
	            	leadNo:leadNo
	            },
                type: "POST",
                error: function(data){
                	BUI.Message.Alert('系统错误','error');
	   	            return false;
                },
                success: function(data) {
                	if(!data.result.success){
                		BUI.Message.Show({
       	                  	msg : data.result.message,
       	                  	icon : 'success',
       	                  	width:400,
       	                  	buttons : [],
       	                  	autoHide :false 
                    	});
                	}else{
                		window.location.href="/telemarketing/viewNotes.htm?leadNo="+data.result.message;
                	}
                 }            
             });
        }
    });
 
 
    
 
});