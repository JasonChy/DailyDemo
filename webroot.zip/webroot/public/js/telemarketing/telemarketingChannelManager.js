$(function(){
	var opArray=[];
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	columns = [
	    { title: '渠道商名称',width: 20,  sortable: false, dataIndex: 'channelName',elCls : 'center'},
		{ title: '渠道商分发限额',width: 20,  sortable: false, dataIndex: 'channelDispMax',elCls : 'center'},
		{ title: '小二分发限额',width: 20,  sortable: false, dataIndex: 'employDispMax',elCls : 'center'},
		{ title: '品控账号',width: 10,  sortable: false, dataIndex: 'controller',elCls : 'center' },
		{ title: '用户组code',width: 10,  sortable: false, dataIndex: 'groupCode',elCls : 'center' },
		{ title: '状态',width: 10,  sortable: false, dataIndex: 'delFlag',elCls : 'center',
			renderer:function(value,obj){
				if(value=='0'){
					return '启用';
				}else if(value=='1'){
					return '禁用';
				}else{
					return value;
				}	
			}
		},
		{ title: '操作', width: 30, dataIndex: 'id',elCls : 'center',
			renderer:function(value,obj){
				var operationDesc;
				if(obj.delFlag=='0'){
					operationDesc = '禁用';
				}else if(obj.delFlag=='1'){
					operationDesc = '启用';
				}else{
					operationDesc = value;
				}
				var deleteChannel = "<a href='javascript:void(0)' class='grid-command edit-DelFlag-Channel'>"+operationDesc+"</a>";
				var editChannel = "<a href='javascript:void(0)' class='grid-command edit-Channel'>修改</a>";
				var telephoneBind =  "<a href='javascript:void(0)' class='grid-command bind-phone'>座机绑定</a>";
				var operateEvt= deleteChannel+"&nbsp;&nbsp;"+editChannel+"&nbsp;&nbsp;"+telephoneBind;
				return operateEvt;
			}
		}
	  ],
      store = new Store({
		 url: $("#btnSearch").data("url"),
		 autoLoad:true,
		 pageSize:1000000,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
             start : 0,
			 channelName:$("#channelName").val(),
			 groupCode:$("#groupCode").val()
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	
	 grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		columns : columns,
		forceFit:true,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
            // pagingBar:表明包含分页栏
			pagingBar:true
		},
		store: store,
		plugins : [Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
	});
	grid.render();
	/*	$("#btnSearch").on("click",function(){
	    grid.render();
	});*/
	
	//没有数据，处理分页栏
	if(!store.getTotalCount()){
		$('#grid #totalPage').text("共 0 页");
	    $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		var obj = form.serializeToObject();
		obj.start = 0; //返回第一页
		store.load(obj);
	  	return false;
    });
	
	//渠道商编辑与渠道商启用/禁用
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素
        //console.log("zzzzzzzzz---------wwwwwwwwwww----------->",ev,record);//bui-select-input
        //编辑渠道商
        if(target.hasClass('edit-Channel')){
        	var msg = '<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">渠道商名称：</span><span name="eChannelName" id="eChannelName">'+record.channelName+'</span></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">渠道商限额：</span><input type="text" name="channelDispMax" id="channelDispMax" value="'+record.channelDispMax+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">小二限额：</span><input type="text" name="employDispMax" id="employDispMax" value="'+record.employDispMax+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">*品控账号： </span><input type="text" name="eController" id="eController" value="'+record.controller+'" style="width:200px;"/></div>'+
			'<div style="margin-left: 20px;margin-top:10px;"><span style="display:inline-block;width:80px;text-align:right;">用户组code： </span><span name="eGroupCode" id="eGroupCode">'+record.groupCode+'</span></div>';
			var Overlay = BUI.Overlay;
		    var dialog = new Overlay.Dialog({
		    	title:'修改渠道商',
		        width:450,
		        height:380,
		        bodyContent:msg,
		        buttons:[{
                   text:'确定',
                   elCls : 'button button-primary',
                   handler : function(){
                	   var obj=this;
                	   var employDispMax=$("#employDispMax").val();
                	   var channelDispMax=$("#channelDispMax").val();
   		        	   var controller=$("#eController").val()?$("#eController").val():"";
	   		           var groupCode=$("#eGroupCode").text()?$("#eGroupCode").text():"";
	   		           if(channelDispMax&&!/\d+/.test(channelDispMax)){
	   	        		   BUI.Message.Alert('渠道商分发限额为整数','info');
	   	        		   return false;
	   		      	   }
	   	        	   if(employDispMax&&!/\d+/.test(employDispMax)){
	   	        		   BUI.Message.Alert('小二分发限额为整数','info');
	   	        		   return false;
	   		      	   }
	   		           if(controller==undefined || controller==""){
	   		        	   BUI.Message.Alert('品控账号必填','info');
	   		      		   return false;
	   		      	   }
	   		           if(groupCode==undefined || groupCode==""){
	   		        	   BUI.Message.Alert('用户组Code必填','info');
	   		      		   return false;
	   		      	   }
                	   //do some thing
	            	   $.ajax({
	   						url: 'editChannelAjax.json',
	   			            dataType:"json",
	   			            data: {
	   			            	employDispMax:employDispMax,
	   			            	controller:controller,
	   			            	groupCode:groupCode,
	   			            	channelDispMax:channelDispMax
	   			            },
	   			            type: "POST",
	   			            error: function(e){
	   			            	BUI.Message.Alert('修改失败','error');
	   				            //$("#btnSearch").submit();
	   				            obj.destroy();
	   			            },
	   			            success: function(data) {
				    			 if(data.editResult.success==true){
										BUI.Message.Alert('修改成功','info');
						    			setTimeout(function(){
							            	window.location.reload();
							            },2000);
					    		     }else{
					    		    	BUI.Message.Alert(data.editResult.message,'info'); 
					    		     }
	   				            obj.destroy();
	   			            }                   
	   					});
               	   }
                },{
                   text:'取消',
                   elCls : 'button',
                   handler : function(){
                	   this.destroy();
                   }
                }]
		    });
		    dialog.show();
        }
        //渠道商启用/禁用
        if(target.hasClass('edit-DelFlag-Channel')){
			var operationDesc;
			if(record.delFlag=='0'){
				operationDesc = '禁用';
			}else if(record.delFlag=='1'){
				operationDesc = '启用';
			}else{
				operationDesc = value;
			}
			var currentDelFlag=record?record.delFlag:"";
			var groupCode=record?record.groupCode:"";
 		   BUI.Message.Confirm("确定"+operationDesc+"该渠道商",function(){
		       $.ajax({
					url: 'editChannelDelFlagAjax.json',
		            dataType:"json",
		            data: {
		            	currentDelFlag:currentDelFlag,
		            	groupCode:groupCode
		            },
		            type: "POST",
		            error: function(e){
		            	BUI.Message.Alert(operationDesc+'失败','error');
		            },
		            success: function(data) {
		    			 if(data.editDelFlagResult.success==true){
								BUI.Message.Alert(operationDesc+'成功','info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else{
			    		    	BUI.Message.Alert(data.editDelFlagResult.message,'info'); 
			    		     }
		            }    
　　　　			});		   
 		   });
        }
        
        //绑定座机
        if(target.hasClass('bind-phone')){
		   var groupCode=record?record.groupCode:"";
		   var channelName=record?record.channelName:"";
		   if(groupCode==undefined || groupCode==""){
			   BUI.Message.Alert('用户组Code为空','error');
		   		return;
		   }
		   if(channelName==undefined || channelName==""){
			   BUI.Message.Alert('渠道商名为空','error');
		   		return;
		   }
		   
		   window.open("/telemarketing/queryBindPhones.htm?groupCode="+groupCode+"&channName="+channelName);
	   
        }
    });
	
	//新增渠道商
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addform'
        }).render();
   
        var dialog = new Overlay.Dialog({
	          title:'新增渠道商',
	          width:450,
	          height:340,
	          //配置DOM容器的编号
	          contentId:'contentAddChannle',
	          success:function () {
	        	  var channelName = $("#a_channelName").val();
	        	  var channelDispMax = $("#a_channelDispMax").val();
	        	  var controller = $("#a_controller").val();
	        	  var groupCode = $("#a_groupCode").val();
	        	  var employDispMax = $("#a_employDispMax").val();
	        	  if(channelName==undefined || channelName==""){
			    		BUI.Message.Alert('渠道商名必填','info');
			    		return false;
			      }
	        	  if(channelDispMax&&!/\d+/.test(channelDispMax)){
  	        		   BUI.Message.Alert('渠道商分发限额为整数','info');
  	        		   return false;
  		      	   }
  	        	   if(employDispMax&&!/\d+/.test(employDispMax)){
  	        		   BUI.Message.Alert('小二分发限额为整数','info');
  	        		   return false;
  		      	   }
	        	  if(controller==undefined || controller==""){
			    		BUI.Message.Alert('品控账号必填','info');
			    		return false;
			      }
	        	  if(groupCode==undefined || groupCode==""){
			    		BUI.Message.Alert('用户组Code必填','info');
			    		return false;
			      }
			      $.ajax({
			    		url: 'addChannelAjax.json',
			    		dataType:"json",
			    		data: {
			    			channelName:channelName,
			    			channelDispMax:channelDispMax,
			    			employDispMax:employDispMax,
			    			controller:controller,
			    			groupCode:groupCode
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(e){
			    			BUI.Message.Alert('新增失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.addResult.success==true){
								BUI.Message.Alert('新增成功','info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else{
			    		    	BUI.Message.Alert(data.addResult.message,'info'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addChannel').on('click',function () {
            dialog.show();
          });   
         
        });	
    
    //渠道商批量导入
    BUI.use('bui/uploader',function (Uploader) {
        uploader = new Uploader.Uploader({
            render: '#batchAddChannel',
            url: 'batchAddChannelAjax.json',
            rules: {
                //文的类型
               ext: ['.csv','文件类型只能为{0}'],
                maxSize: [11264, '文件大小不能大于10M']
            }
        }).render();
        
        //上传成功时会触发
        uploader.on('success', function(ev){
            var result = ev.result;
                //BUI.Message.Show({
                //    msg : '上传成功',
                //    icon : 'success',
                //   width:200,
                //    buttons : [],
                //    autoHide : true,
                //    autoHideDelay : 1000
                //});
        })
        //上传成功时会触发
        uploader.on('error', function(ev){
            var result = ev.result;
            if(result.batchAddResult.success==true){
                BUI.Message.Show({
                    msg : '上传成功',
                    icon : 'success',
                    width:200,
                    buttons : [],
                    autoHide : true,
                    autoHideDelay : 1000
                });
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }else{
                    BUI.Message.Show({
                        msg : result.batchAddResult.message+" 请删除,重新上传！",
                        icon : 'error',
                        width:200,
                        buttons : [{ text:'关闭', elCls : 'button', handler : function(){ this.hide(); }}],
                        autoHide : false
                    });
                $(".defaultTheme .bui-queue-item .action").css("display","block");
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }
        });
    }); 
});