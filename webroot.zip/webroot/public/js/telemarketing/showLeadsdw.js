
var globalDialog;
var globalGrid;
var globalSelect;


//显示表格
BUI.use(['bui/grid','bui/data'],function(Grid,Data){
	var Grid = Grid,
	Store = Data.Store,
	columns = [
	           {title : 'leadNo',dataIndex :'leadNo', sortable: true, width:100, elCls : 'center'},
	           {title : '公司名称',dataIndex :'companyName', sortable: true, width:300, elCls : 'center'},
	           {title : '法人姓名',dataIndex :'legalpersonName', sortable: true, width:300, elCls : 'center'},
	           {title : '根业务渠道商',dataIndex :'rootChannel', width:150, elCls : 'center'},
	           {title : '省',dataIndex : 'leadProvince', sortable: true, width:100, elCls : 'center'},
	           {title : '市',dataIndex : 'leadCity', sortable: true, width:100, elCls : 'center'},
	           {title : '会员类型',dataIndex : 'memberType', sortable: true, width:100, elCls : 'center'},
	           {title : '电销状态',dataIndex : 'telemarkingStatus', sortable: true, width:200, elCls : 'center',
	        	   renderer:function(value,obj){
	        		   if(value=='init'){
	        			   value='尚未联系';
	        		   }else if(value=='noDesire'){
	        			   value='暂无意愿';
	        		   }else if(value=='unallocatedNumber')
	        		   {
	        			   value='号码错误';
	        		   }else if(value=='abandonedCall'){
	        			   value=' 无人接听';
	        		   }else if(value == 'applySuccess'){
	        			   value='已经申贷';
	        		   }else if(value == 'prepareApply'){
	        			   value='准备申贷';
	        		   }else{
	        			   value=value;
	        		   }
	        		   return value;
	        	   }
	           }
	           ];

	var store = new Store({
		url : '/telemarketing/queryLeadsdw.json',
		autoLoad:true, //自动加载数据
		proxy:{
			 method:'post',
			 dataType:'json'
		 },
		params : { //配置初始请求的参数
			telemarkingStatus: $.trim($("#telemarkingStatu").val()), 
			memberType: $.trim($("#memberType").val()),
			leadProvince: $.trim($("#leadProvince").val()), 
			leadCity: $.trim($("#leadCity").val()), 
			start: 0
		},
		pageSize:500	// 配置分页数目
	}),

	grid = new Grid.Grid({
		render:'#grid',
		columns : columns,
		loadMask: true, //加载数据时显示屏蔽层
		store: store,
		forceFit : true, //自适应宽度
		itemStatusFields : { //设置数据跟状态的对应关系
			selected : 'selected',
			disabled : 'disabled'
		},
		plugins : [Grid.Plugins.CheckSelection],
		// 顶部工具栏
		tbar:{
			items:[{
				btnCls : 'button button-primary button-small distributeBtn',
				text:'分发',
				listeners : {
					'click' : distributeFunction
				}
			}]
		},
		// 底部工具栏
		bbar:{
			// pagingBar:表明包含分页栏
			pagingBar:true
		}
	});

	grid.render();
	
	//这个操作，是为了只加载表格
    var form = new BUI.Form.HForm({
      srcNode : '#searchForm'
    }).render();

    form.on('beforesubmit',function(ev) {
    	//序列化成对象
    	var obj = form.serializeToObject();
    	obj.start = 0; //返回第一页
    	store.load(obj);
    	return false;
    });

	//分发选中lead
	function distributeFunction(){
		var selections = grid.getSelection();
		if(selections.length<=0){
			BUI.Message.Alert("请选择要分发的lead",'info');
			return;
		}
		globalGrid = grid;
		globalDialog.show();
	}

});





//分发弹出框
BUI.use('bui/overlay',function(Overlay){

	var dialog = new Overlay.Dialog({
		title:'选择渠道商',
		width:500,
		height:300,
		mask:false,
		buttons:[
		         {
		        	 text:'确定',
		        	 elCls : 'button button-primary',
		        	 handler : function(){
		        		 var channelName = $("#channel").val();
		        		// var groupCode = globalSelect.getSelectedValue();
		        		 if( channelName==""){
		        			 BUI.Message.Alert('请选择渠道商','info');
		        			 return;
		        		 }
		        		 var selections = globalGrid.getSelection();
		        		 var leadNos = '';
		        		 for(var i=0; i<selections.length; i++){
		        			 leadNos += selections[i].leadNo+',';
		        		 }

		        		 $.ajax({
		        			 url: 'allotLeads.json',
		        			 dataType:"json",
		        			 data: {
		        				 channelName : channelName,
		        				// groupCode : groupCode,
		        				 leadNos : leadNos
		        			 },
		        			 type: "POST",
		        			 error: function(data){
		        				 BUI.Message.Alert(data.msg,'info');
		        			 },
		        			 success: function(data) {
		        				 $("#channel").val("")
		        				 BUI.Message.Confirm(data.msg,function(){
		        					 window.location.reload();
		        				 },'info');
		        			 }                   
		        		 });
		        		 this.close();


		        	 }
		         },{
		        	 text:'取消',
		        	 elCls : 'button',
		        	 handler : function(){
		        		 $("#channel").val("")
		        		 this.close();
		        	 }
		         }
		         ],

		         contentId : 'selectChannelDiv'

	});

	globalDialog = dialog;
//	$('.distributeBtn').on('click',function () {
//	dialog.show();
//	});
});


/*//查询渠道商
BUI.use(['bui/select','bui/data'],function(Select,Data){

	var store = new Data.Store({
		url : '/telemarketing/queryAllChannels.json',
		autoLoad : true
	}),
	select = new Select.Select({  
		render:'#s1',
		valueField:'#channel',
		multipleSelect : false,
		store : store
	});
	select.render();
	globalSelect = select;
	select.on('change', function(ev){

	});

});*/

var colors =[];
$(function () {
	
	jQuery.ajax({
        type:"post",
        url:"/telemarketing/queryAllChannels.json",
        dataType:"json",
        data:{
        },
        async: false,
        success:function(data){
        	for(t in data.rows){
         	colors.push(data.rows[t]);	
        	}
         }
   });
	
	  $('#channel').autocompleter({
	        // marker for autocomplete matches
	        highlightMatches: true,

	        // object to local or url to remote search
	        source: colors,

	        // custom template
	        template: '{{ label }} <span>({{ text }})</span>',

	        // show hint
	        hint: true,

	        // abort source if empty field
	        empty: false,

	        // max results
	        limit: 5,

	        callback: function (value, index, selected) {
	        	$("#channel").val(value);
	        }
	    });
	});