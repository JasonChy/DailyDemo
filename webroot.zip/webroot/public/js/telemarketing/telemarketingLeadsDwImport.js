$(function(){
	var opArray=[];
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	columns = [
	    { title: '导入时间',width: 8,  sortable: false, dataIndex: 'gmtCreate',elCls : 'center'},
		{ title: '导入人',width: 8,  sortable: false, dataIndex: 'creator',elCls : 'center'},
		{ title: 'Leads编号',width: 10,  sortable: false, dataIndex: 'leadNo',elCls : 'center' },
		{ title: 'Leads类型',width: 5,  sortable: false, dataIndex: 'leadType',elCls : 'center' },
		{ title: 'Leads省份',width: 5,  sortable: false, dataIndex: 'leadProvince',elCls : 'center'},
		{ title: 'Leads城市',width: 5,  sortable: false, dataIndex: 'leadCity',elCls : 'center'},
		{ title: '公司名称',width: 8, sortable: false, dataIndex: 'companyName',elCls : 'center'},
		{ title: '法人姓名',width: 5,  sortable: false, dataIndex: 'legalpersonName',elCls : 'center' },
		{ title: '法人联系方式',width: 5,  sortable: false, dataIndex: 'legalpersonContactway',elCls : 'center'}
	  ],
      store = new Store({
		 url: "/telemarketing/queryleadsDwImportResultAjax.json",
		 autoLoad:true,
		 pageSize:1000000,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
             start : 0
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	
	 grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		columns : columns,
		forceFit:true,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
            // pagingBar:表明包含分页栏
			pagingBar:true
		},
		store: store,
		plugins : [Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
	});
	grid.render();
	/*	$("#btnSearch").on("click",function(){
	    grid.render();
	});*/
	
	//没有数据，处理分页栏
	if(!store.getTotalCount()){
		$('#grid #totalPage').text("共 0 页");
	    $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		var obj = form.serializeToObject();
		obj.start = 0; //返回第一页
		store.load(obj);
	  	return false;
    });
	
	
	//渠道商批量导入
    BUI.use('bui/uploader',function (Uploader) {
        uploader = new Uploader.Uploader({
            render: '#batchAddLeads',
            url: 'batchAddLeadsAjax.json',
            rules: {
                //文的类型
               ext: ['.csv','文件类型只能为{0}'],
                maxSize: [11264, '文件大小不能大于10M']
            }
        }).render();
        
        //上传成功时会触发
        uploader.on('success', function(ev){
            var result = ev.result;
                //BUI.Message.Show({
                //    msg : '上传成功',
                //    icon : 'success',
                //   width:200,
                //    buttons : [],
                //    autoHide : true,
                //    autoHideDelay : 1000
                //});
        })
        //上传成功时会触发
        uploader.on('error', function(ev){
            var result = ev.result;
            if(result.batchAddResult.success==true){
                BUI.Message.Show({
                    msg : '上传成功',
                    icon : 'success',
                    width:200,
                    buttons : [],
                    autoHide : true,
                    autoHideDelay : 1000
                });
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }else{
                    BUI.Message.Show({
                        msg : result.batchAddResult.message+" 请删除,重新上传！",
                        icon : 'error',
                        width:200,
                        buttons : [{ text:'关闭', elCls : 'button', handler : function(){ this.hide(); }}],
                        autoHide : false
                    });
                $(".defaultTheme .bui-queue-item .action").css("display","block");
   			 	setTimeout(function(){
   			 		window.location.reload();
   			 	},2000);
            }
        });
    }); 
	
});