$(function(){
	var opArray=[];
	
	var groupCode = $("#groupCode").val();
	var channName = $("#channName").val();
	// 初始化任务表格
	var Grid = BUI.Grid,
	Data = BUI.Data,
	Store = Data.Store,
	columns = [
	    { title: '座机号',width: 10,  sortable: false, dataIndex: 'no',elCls : 'center'},
		{ title: '员工域账号',width: 10,  sortable: false, dataIndex: 'realName',elCls : 'center'},
		{ title: '渠道商名称',width: 10,  sortable: false, dataIndex: 'channName',elCls : 'center'},
		{ title: '操作',width: 10,  sortable: false, dataIndex: 'creator',elCls : 'center',
			renderer:function(value,obj){
			return '<span class="grid-command delphoneBtn">取消绑定</span>';
		}}
	  ],
      store = new Store({
		 url: "/telemarketing/queryBindPhonesAjax.json",
		 autoLoad:true,
		 pageSize:1000000,
		 proxy:{
			 method:'post',
			 dataType:'json'
		 },
		 params : {
             start : 0,
             groupCode : groupCode,
             channName : channName,
         },
		 listeners:{
		     beforeprocessload:function(e){
		     }
		 }
	 }),
	
	 grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		columns : columns,
		forceFit:true,
		// 顶部工具栏
		bbar : {
			//items 也可以在此配置
            // pagingBar:表明包含分页栏
			pagingBar:true
		},
		store: store,
		plugins : [Grid.Plugins.AutoFit] //勾选插件、自适应宽度插件
	});
	grid.render();
	
	//没有数据，处理分页栏
	if(!store.getTotalCount()){
		$('#grid #totalPage').text("共 0 页");
	    $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}
	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();
	
	form.on('beforesubmit',function(ev) {
		//序列化成对象
		var obj = form.serializeToObject();
		obj.start = 0; //返回第一页
		store.load(obj);
	  	return false;
    });
	
	
	//新增座机绑定
    BUI.use(['bui/overlay','bui/form'],function(Overlay,Form){
        var form = new Form.HForm({
          srcNode : '#addform'
        }).render();
   
        var dialog = new Overlay.Dialog({
	          title:'新增座机绑定',
	          width:510,
	          height:300,
	          //配置DOM容器的编号
	          contentId:'contentAddBind',
	          success:function () {
	        	  var phoneNo = $("#phoneNo").val();
	        	  var salesman = $("#salesman option:selected").val();
	        	  var groupCode = $("#groupCode").val();
	        	  if(phoneNo==undefined || phoneNo==""){
			    		BUI.Message.Alert('座机号必填','info');
			    		return false;
			      }
			      $.ajax({
			    		url: 'addBind.json',
			    		dataType:"json",
			    		data: {
			    			phoneNo:phoneNo,
			    			salesman:salesman,
			    			groupCode:groupCode
			    		},
			    		type: "POST",
			    		async: false,
			    		error: function(data){
			    			BUI.Message.Alert('绑定失败','error');
			    		},
			    		success: function(data) {
			    			 if(data.result.success==true){
								BUI.Message.Alert(data.result.message,'info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else{
			    		    	BUI.Message.Alert(data.result.message,'info'); 
			    		     }
			    		}                   
			      });
            	  this.close();
              }
            });
        
          $('#addBind').on('click',function () {
            dialog.show();
          });   
         
        });	
    
    
    grid.on('cellclick',function(ev) {
    	var obj=this;
        var record = ev.record, //点击行的记录
        	field = ev.field, //点击对应列的dataIndex
        	target = $(ev.domTarget); //点击的元素

        //绑定取消
        if(target.hasClass('delphoneBtn')){
        	var id=record?record.id:"";
 		   	BUI.Message.Confirm("确定取消该座机绑定",function(){
		       $.ajax({
					url: 'deleteBind.json',
		            dataType:"json",
		            data: {
		            	id:id
		            },
		            type: "POST",
		            error: function(data){
		            	BUI.Message.Alert(data.result.message,'error');
		            },
		            success: function(data) {
		    			 if(data.result.success==true){
								BUI.Message.Alert(data.result.message,'info');
				    			setTimeout(function(){
					            	window.location.reload();
					            },2000);
			    		     }else{
			    		    	BUI.Message.Alert(data.result.message,'info'); 
			    		     }
		            }    
　　　　			});		   
 		   });
        }
        
    });
	
});