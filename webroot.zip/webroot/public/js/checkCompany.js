$(function(){
    var Grid = BUI.Grid,
    Store = BUI.Data.Store,
    columns = [
		        {title : '是否营销',dataIndex :'isMarket', width:150,elCls : 'center',renderer : function(value){
		                if(value=="未通过")
						{
							return "<span style='color:red'>否</span>";
						}else if(value=="通过"){ 
							return "是";
						}else{
							return value;
						}
				    }
				},
				{title : '公司名称',elCls : 'center',dataIndex :'companyName', width:300,sortable : false}
               ];
    var store = new Store({
		data : [],
		autoLoad:true
	  }),
	grid = new Grid.Grid({
		render:'#companyGrid',
		width:'100%',//这个属性一定要设置
		columns : columns,
		store : store,
		height:520,
		loadMask: true
	});
 
    grid.render();

	var fullMask = new BUI.Mask.LoadMask({el : 'body',msg : '正在检测。。。'});
	$("#startTest").click(function(){
		fullMask.show();
		var companiesStr = $.trim($("#companies").val()),
		companiesArr = companiesStr.split(/\n+/),//以enter作为分隔符
        len = companiesArr.length;
		store.setResult([]);//清空数据
        if(companiesStr == ""){	
			fullMask.hide();
			return;
		}
		//超过100条，只能检测前100条
		setTimeout(function(){
			if(len > 100)
			{
				len = 100;
			}
			for(var i = 0;i < len;i++){
				var companyName = $.trim(companiesArr[i]);
				if(!$.trim(companyName)){
					continue;
				}
			var ajax = $.ajax({
					url:"/channel/checkCompany.json?_input_charset=utf-8",
					dataType:'json',
					async:false,
					data:{
						companyName:companyName
					},
					success: function(data){
						if(data.messageCode && data.exception_marking)
						{
							var exception_marking = data.exception_marking.split("=")[1];
							store.add({companyName:companyName,isMarket:exception_marking});
						}else if(data.result)
						{
							store.add({companyName:companyName,isMarket:data.result});
						}
						//store.load();
						//store.setResult(storeData);
					}
					//,
					//error: function (XMLHttpRequest, textStatus, errorThrown) { 
					//	alert("请求出错"); 
					//} 
				});
			}
			ajax.fail(function(){
				alert("请求出错"); 
			});
		//	store.setResult(storeData);
			fullMask.hide();
		},100);
		
      });
	  
})