BUI.use(['bui/grid','bui/data'],function(Grid,Data){
   var Grid = BUI.Grid,
	  Store = BUI.Data.Store,
	  columns = [
		{ title: '公司名称',width: 80,  sortable: false, dataIndex: 'companyName',elCls : 'center'},
		{ title: '流入时间',width: 80,  sortable: false, dataIndex: 'inputViewTime',elCls : 'center' },
		{ title: '流出时间',width: 80,  sortable: false, dataIndex: 'outputViewTime',elCls : 'center' },
		{ title: '是否有效',width: 80,  sortable: false, dataIndex: 'isValid',elCls : 'center',renderer:function(value,obj){
		    return value=="n"?"无效":"有效";
		} },
		{ title: '详情', width: 100, dataIndex: 'id',elCls : 'center',renderer:function(value,obj){
		return '<a target="_blank" href="/leads/showLeadsNodesDetail.htm?leadsId='+value+'">例子详情</a>';
		}}
	  ];
     store = new Store({
		url: $("#btnSearch").data("url"),
		autoLoad:true,
		pageSize:20,
		proxy:{
			method:'post',
			dataType:'json'
		},
		params : {
                start : 0
          },
		listeners:{
		    beforeprocessload:function(e){
		           
		    }
		    
		}
	}),
	function showEndInfo(){
	    grid.clearSelection();
	}
	
	grid = new Grid.Grid({
		render:'#grid',
		loadMask: true,
		forceFit:true,
		columns : columns,
		store: store,
		plugins : [Grid.Plugins.CheckSelection], //勾选插件、自适应宽度插件
		// 顶部工具栏
		bbar : {
		  //items 也可以在此配置
		  // pagingBar:表明包含分页栏
		  pagingBar:true
		}
	});

	grid.render();
   
  // $("<li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize20'>20</a></li><li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize50'>50</a></li>").insertBefore($("#bar3").children("li").last());
  
	//没有数据，处理分页栏
	if(!store.getTotalCount())
	{
		$('#grid #totalPage').text("共 0 页");
        $('#grid .bui-pb-page').val("0");
		$('#grid #totalCount').text("共0条记录");
	}

	//创建表单，表单中的日历，不需要单独初始化
	var form = new BUI.Form.HForm({
	  srcNode : '#searchForm'
	}).render();

	/*
	 $("#pagesize20").on("click",function(){	   
			  store.set("pageSize",20);
				 $("#btnSearch").click();                     
			  grid.render();
		   });  */
	
	form.on('beforesubmit',function(ev) {
	  //序列化成对象
	  var obj = form.serializeToObject();
	 // obj.start = 0; //返回第一页
	 // var page=$('#grid .bui-pb-page').val();
      obj.start=0;
      obj.pageIndex=0;
	  store.load(obj);
      console.log(store.getCount() );
	  return false;
	});
});
