jQuery(function(){
	BUI.use(['bui/tab','bui/mask','bui/imgview','bui/overlay'],function(Tab,ImgView,Overlay){      
			var tab = new Tab.TabPanel({
			  render : '#tab',
			  elCls : 'nav-tabs',
			  panelContainer : '#panel',//如果内部有容器，那么会跟标签项一一对应，如果没有会自动生成
			  //selectedEvent : 'mouseenter',//默认为click,可以更改事件
			  autoRender: true,
			  children:[
				{title:'小记信息',value:'1',loader : {url : '/leads/getLeadsNodesList.htm?leadsId='+leadsId},selected : true},
				{title:'公司信息',value:'2',loader : {url : '/leads/getLeadsInfo.htm?leadsId='+leadsId}}
			  ]
			});	  
	});	
	
	jQuery("#btnSubmit").bind("click",function(){  
		 if(jQuery.trim(jQuery("#txt_area").val())==""){
			  BUI.Message.Show({
							msg :'小计不能为空',
							icon : 'info',
							width:200,
							buttons : [],
							autoHide :false 
						});       
			   return;
		 }
		  jQuery.ajax({
				url: "/leads/insertLeadsNodes.json",
				dataType:"json",
				data: jQuery('#formSubmit_Check').serialize(),
				type: "POST",
				error: function(e) {            
					  BUI.Message.Show({
							msg : '提交失败',
							icon : 'error',
							width:200,
							buttons : [],
							autoHide :false 
						});
			
				},
				success: function(data) {
						  BUI.Message.Show({
							msg : data.message,
							icon : 'success',
							width:200,
							buttons : [],
							autoHide :false 
						});
					   window.location.reload();
				}                   
		   });
		});  
	});