$(function(){
	BUI.use(['bui/grid','bui/data','bui/form'],function(Grid,Data,Form){
	   var Grid = BUI.Grid,
		  Store = BUI.Data.Store,
		  columns = [
		    { title: '编号',width: 80,  sortable: false, dataIndex: 'id',elCls : 'center'},
			{ title: '状态',width: 80,  sortable: false, dataIndex: 'statusStr',elCls : 'center'},
			{ title: '命令类型',width: 80,  sortable: false, dataIndex: 'commandType',elCls : 'center' },
			{ title: '执行次数',width: 80,  sortable: false, dataIndex: 'executeTimes',elCls : 'center' },
			{ title: '下次执行时间',width: 80,  sortable: false, dataIndex: 'nextExecuteTimeStr',elCls : 'center' },
			{ title: '外部业务编号',width: 80,  sortable: false, dataIndex: 'businessNo',elCls : 'center' },
			{ title: '执行上下文',width: 80,  sortable: false, dataIndex: 'context',elCls : 'center' },
			{ title: '生产者主机名',width: 80,  sortable: false, dataIndex: 'hostname',elCls : 'center' },
			{ title: '操作', width: 100, dataIndex: 'id',elCls : 'center',renderer:function(value,obj){
			return '<a href="/tool/asynUpdateAction.json?id='+value+'">重试</a>';
			}}
		  ];
		 store = new Store({
			url: $("#btnSearch").data("url"),
			autoLoad:true,
			pageSize:20,
			proxy:{
				method:'post',
				dataType:'json'
			},
			params : {
					start : 0
			  },
			listeners:{
				beforeprocessload:function(e){
					   
				}
				
			}
		}),
		function showEndInfo(){
			grid.clearSelection();
		}
		
		grid = new Grid.Grid({
			render:'#grid',
			loadMask: true,
			forceFit:true,
			columns : columns,
			store: store,
			plugins : [Grid.Plugins.CheckSelection], //勾选插件、自适应宽度插件
			// 顶部工具栏
			bbar : {
			  //items 也可以在此配置
			  // pagingBar:表明包含分页栏
			  pagingBar:true
			}
		});

		grid.render();
	   
	  // $("<li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize20'>20</a></li><li class='bui-bar-item-text bui-bar-item bui-inline-block'><a href='javascript:void(0);' id='pagesize50'>50</a></li>").insertBefore($("#bar3").children("li").last());
	  
		//没有数据，处理分页栏
		if(!store.getTotalCount())
		{
			$('#grid #totalPage').text("共 0 页");
			$('#grid .bui-pb-page').val("0");
			$('#grid #totalCount').text("共0条记录");
		}

		//创建表单，表单中的日历，不需要单独初始化
		var form = new BUI.Form.HForm({
		  srcNode : '#searchForm'
		}).render();

		/*
		 $("#pagesize20").on("click",function(){	   
				  store.set("pageSize",20);
					 $("#btnSearch").click();                     
				  grid.render();
			   });  */
		
		form.on('beforesubmit',function(ev) {
		  //序列化成对象
		  var obj = form.serializeToObject();
		  obj.start=0;
		  obj.pageIndex=0;
		  store.load(obj);
		  return false;
		});
	});
});