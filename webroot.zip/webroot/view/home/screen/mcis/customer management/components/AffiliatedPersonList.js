import React from 'react';
import { Row, Col, Table, message, Popconfirm } from 'antd';

import request from 'superagent';

class WordList extends React.Component {
  constructor(...args) {
    super(...args);
    this.state = {
      data: null
    };
  }

  /*componentWillReceiveProps(obj) {
    if (this.props.mustCustNo == "") {
      this.setState({
        custNoMaster: obj.mustCustNo
      })
    }
  }*/

  handleDelete(id) {
    console.log('category: ', id);
    let self = this;

    request
      .del('/selfhelploan/getCustomerInfo.json' + id)
      .end(function (err, resp) {
        if (err) {
          message.error('删除失败！', err);
          return;
        }
        message.success('删除成功！');
        self.refresh.call(self);
      });
  }

  cancel() {
    message.error('点击了取消');
  }

  refresh() {
    let self = this;
    request
      .post('/selfhelploan/getCustomerInfo.json')
      .set('Content-Type', 'application/json')
      .send({
        custNoMaster: this.props.params.flagOne,
      })
      .end(function (err, resp) {
        console.log('进入查看或者修改查找存储的关联人信息', resp);
        self.setState({
          data: resp.body
        });
      })
      /*.get('/selfhelploan/getCustomerInfo.json')
      .end(function (err, resp) {
        console.log('resp ', resp);
        self.setState({
          data: resp.body
        });
      });*/
  }

  componentDidMount() {
    if(this.props.params.flagTwo == "look" || this.props.params.flagTwo == "correct"){
      /*this.refresh.call(this);*/
    }
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.addWord !== this.props.addWord) {
      this.refresh();
      return;
    }
  }

  render() {
    let self = this;

    const columns = [{
      title: '关联客户类型',
      dataIndex: 'category',
    }, {
      title: '关联关系类型',
      dataIndex: 'relationType',
    }, {
      title: '具体关系',
      dataIndex: 'relationDetail',
    }, {
      title: '关系客户姓名',
      dataIndex: 'relatedCustName',
    }, {
      title: '证件类型',
      dataIndex: 'relatedCertType',
    }, {
      title: '证件号码',
      dataIndex: 'relatedCertNo',
    },{
      title: '联系方式',
      dataIndex: 'relatedTel',
    }, {
      title: '年收入',
      dataIndex: 'relatedSalary',
    }, {
      title: '工作单位',
      dataIndex: 'relatedOffice',
    }, {
      title: '控股类型',
      dataIndex: 'holdCategory',
    },{
      title: '持股金额',
      dataIndex: 'holdAmount',
    }, {
      title: '持有股数',
      dataIndex: 'holdShares',
    }, {
      title: '占股比例',
      dataIndex: 'holdRatio',
    },{
      title: '操作',
      key: 'operation',
      render(text, record) {
        return <span>
                <Popconfirm title="操作确认" onConfirm={self.handleDelete.bind(self, record.id)} onCancel={self.cancel}>
                  <a href="#">删除</a>
                </Popconfirm>
               </span>
      }
    }];

    let wordTable;
    if (this.state.data === null) {
      wordTable = '';
    } else {
      wordTable = <Table
        rowKey={record => record.id}
        columns={columns}
        dataSource={this.state.data}
        bordered
        pagination={false}
      />;
    }

    return (
      <Row>
        <Col>
          {wordTable}
        </Col>
      </Row>
    );
  }
}

export default WordList;