import React from 'react';
import { Button, Form, Input, Modal, message, Select } from 'antd';
const createForm = Form.create;
const FormItem = Form.Item;
const Option = Select.Option;

import request from 'superagent';

class AddWord extends React.Component {
  constructor(props) {
    super(props)
    this.state = { 
      visible: false,
      rtRelatedCertTypeList: [],
      rtRelationDetailList: []
    };
  }

  /*componentWillReceiveProps(obj) {
    if (this.props.mustCustNo == "") {
      this.setState({
        custNoMaster: obj.mustCustNo
      })
    }
  }*/

  handleSubmit() {
    console.log(this.props.form.getFieldsValue());
    var form = this.props.form.getFieldsValue();
    if (!form.category || !form.relationDetail) {
      message.error('请填写必填项！');
      return;
    }
    if (form.category.length > 30
      || form.relationDetail.length > 200
      || (form.relationType && form.relationType.length > 30)
    ) {
      message.error('长度超过限制！');
      return;
    }
    var self = this;
    request
      .post('/selfhelploan/saveCustomerRelation.json')
      .set('Content-Type', 'application/json')
      .send({
        custNoMaster: this.props.params.flagOne,
        category: form.category,
        relationType: form.relationType,
        relationDetail: form.relationDetail,
        relatedCustName: form.relatedCustName,
        relatedCertType: form.relatedCertType,
        relatedCertNo: form.relatedCertNo,
        relatedTel: form.relatedTel,
        relatedAddress: form.relatedAddress,
        relatedSalary: form.relatedSalary,
        relatedOffice: form.relatedOffice,
        holdCategory: form.holdCategory,
        holdAmount: form.holdAmount,
        holdShares: form.holdShares,
        holdRatio: form.holdRatio
      })
      .end(function (err, resp) {
        if (err) {
          message.error('添加失败！', err);
          return;
        }
        message.success('添加成功！');
        console.log('refresh', self.props.refresh);
        self.props.refresh(resp);
        self.hideModal();
    });
  }

  showModal() {
    this.setState({ visible: true });
  }

  hideModal() {
    this.setState({ visible: false });
  }

  handleRelationCustType(value){
    if(value=="个人"){
      this.setState({
        rtRelatedCertTypeList: ["身份证","户口簿","护照","军官证","士兵证","港澳居民来往内地通行证","台湾同胞来往内地通行证","临时身份证","外国人居留证","警官证","其他证件"]
      })
      this.refs.workSpace.style.display = "block"
    }else if(value=="企业"){
      this.setState({
        rtRelatedCertTypeList: ["工商注册号","组织机构代码证","统一社会信用代码证","其他证件"]
      })
      this.refs.workSpace.style.display = "none"
    }
  }

  handleRelationType(value){
    if(value == "家庭"){
      this.setState({
        rtRelationDetailList: ["子女","姐妹","兄弟","母亲","父亲","配偶"]
      })
      this.refs.companyWork.style.display = "none";
    }else if(value=="股东"){
      this.setState({
        rtRelationDetailList: ["个人股东"]
      })
      this.refs.companyWork.style.display = "block";
    }else if(value == "高管"){
      this.setState({
        rtRelationDetailList: ["法人代表","总经理","财务负责人","其他"]
      })
      this.refs.companyWork.style.display = "none";
    }else if(value == "其他"){
      this.setState({
        rtRelationDetailList: ["其他"]
      })
      this.refs.companyWork.style.display = "none";
    }
  }

  rtRelationDetailOption(){
    return this.state.rtRelationDetailList.map((array, index) => {
      return (<Option key={index} value={array}>{array}</Option>);
    });
  }

  rtRelatedCertTypeOption(){
        return this.state.rtRelatedCertTypeList.map((array, index) => {
            return (<Option key={index} value={array}>{array}</Option>);
        });
    }

  render() {
    //输入框的样式
    const inputStyle = {
        width: '200px',
        height: '28px',
        padding: '4px 7px'
    }

    const { getFieldDecorator } = this.props.form;

    const formItemLayout = {
      labelCol: { span: 6 },
      wrapperCol: { span: 10 },
    };
    return (
      <div>
        <Button type="primary" onClick={this.showModal.bind(this)} disabled={this.props.topDisabled} >添加关联人</Button>
        <Modal title="添加关联人" visible={this.state.visible} onOk={this.handleSubmit.bind(this)} onCancel={this.hideModal.bind(this)}>
          <Form horizontal>
            <FormItem
              {...formItemLayout}
              label="关联客户类型：">
              {getFieldDecorator('category', {})(
                <Select placeholder="请选择" onChange={this.handleRelationCustType.bind(this)} >
                  <Option value="个人">个人</Option>
                  <Option value="企业">企业</Option>
                </Select>
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="关联关系类型：">
              {getFieldDecorator('relationType', {})(
                <Select placeholder="请选择" onChange={this.handleRelationType.bind(this)} >
                  <Option value="家庭">家庭</Option>
                  <Option value="股东">股东</Option>
                  <Option value="高管">高管</Option>
                  <Option value="其他">其他</Option>
                </Select>
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="具体关系：">
              {getFieldDecorator('relationDetail', {})(
                <Select>
                  {this.rtRelationDetailOption()}
                </Select>
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="关系客户姓名：">
              {getFieldDecorator('relatedCustName', {})(
                <Input style={inputStyle}  type="text" placeholder="请输入内容" />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="证件类型：">
              {getFieldDecorator('relatedCertType', {})(
                <Select>
                  {this.rtRelatedCertTypeOption()}
                </Select>
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="证件号码：">
              {getFieldDecorator('relatedCertNo', {})(
                <Input style={inputStyle}  type="text" placeholder="请输入证件号码" />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="联系方式：">
              {getFieldDecorator('relatedTel', {})(
                <Input style={inputStyle}  type="text" placeholder="请输入电话号码" />
              )}
            </FormItem>
            <FormItem
              {...formItemLayout}
              label="年收入：">
              {getFieldDecorator('relatedSalary', {})(
                <Input style={inputStyle}  type="text" placeholder="请输入联系地址" />
              )}
            </FormItem>
            <div ref="workSpace">
              <FormItem
                {...formItemLayout}
                label="工作单位：">
                {getFieldDecorator('relatedOffice', {})(
                    <Input style={inputStyle}  type="text" placeholder="请输入工作单位" />
                )}
              </FormItem>
            </div>
            <div ref="companyWork">
              <FormItem
                {...formItemLayout}
                label="控股类型：">
                {getFieldDecorator('holdCategory', {})(
                    <Select>
                      <Option value="绝对控股">绝对控股</Option>
                      <Option value="相对控股">相对控股</Option>
                      <Option value="参股">参股</Option>
                    </Select>
                )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="控股金额（万元）：">
                {getFieldDecorator('holdAmount', {})(
                    <Input style={inputStyle}  type="text" placeholder="请输入金额" />
                )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="持有股数（股）：">
                {getFieldDecorator('holdShares', {})(
                    <Input style={inputStyle}  type="text" placeholder="请输入数字" />
                )}
              </FormItem>
              <FormItem
                {...formItemLayout}
                label="占股比例（%）：">
                {getFieldDecorator('holdRatio', {})(
                    <Input style={inputStyle}  type="text" placeholder="请输入比例" />
                )}
              </FormItem>
            </div>
          </Form>
        </Modal>
      </div>
    );
  }
};

AddWord = createForm()(AddWord);

export default AddWord;