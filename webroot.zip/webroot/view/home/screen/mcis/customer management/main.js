/**
 * 
 * @authors luozh@snail.com
 * @date    2016-03-21 16:42:35
 * @description 主入口模块
 */

import React from 'react'
import { render } from 'react-dom'

// 引入React-Router模块
import { Router, Route, Link, hashHistory, IndexRoute, Redirect, IndexLink} from 'react-router'

// 引入Antd的导航组件
import { Icon, Switch, Button, Table } from 'antd'

// 引入Ant-Design样式 & Animate.CSS样式
import 'animate.css/animate.min.css'
import 'font-awesome/css/font-awesome.min.css'

// 引入主体样式文件
import './main.css'

// 引入单个页面（包括嵌套的子页面）
import newTable from './components/custTable.js'


const columns = [{
    title: '客户姓名',
    dataIndex: 'custName'
}, {
    title: '客户类型',
    dataIndex: 'category',
}, {
    title: '报名渠道',
    dataIndex: 'custSource',
},{
    title: '证件号码',
    dataIndex: 'certNo',
}, {
    title: '联系方式',
    dataIndex: 'contact',
}, {
    title: '客户录入时间',
    dataIndex: 'gmtCreate',
}, {
    title: '客户经理',
    dataIndex: 'custManagerName',
}, {
    title: '客户授信状态',
    dataIndex: 'credited',
}, {
    title: '操作',
    dataIndex: 'operate',
    render(text, record, index) {
        const divStyle = {
            textAlign: 'center'
        }
        const recordCustNo = record.custNo
        if(record.editable == true){
            return <div style={divStyle}><Link to={"/newTable/"+recordCustNo+"/look"}>查看</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<Link to={"/newTable/"+recordCustNo+"/correct"}>修改</Link></div>
        }else if(record.editable == false){
            return <div style={divStyle}><Link to={"/newTable/"+recordCustNo+"/look"}>查看</Link></div>
        }
        
    }
}]

class myTable extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            tDate: [],
            managersList: [],
            custType: 0,
            custState: 0,
            totalSpan: 0,
            pCount: 0,
            oCount: 0,
            cTrue: 0,
            cFalse: 0,
            queryLook: 0
        }
    }

    dataPost(body){
        const data = []

        fetch('/selfhelploan/queryCustomerList.json', {
          method: 'POST',
          credentials: "include",
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
          },
          body: body
        }).then((response) => response.json())
        .then((obj) => {
            this.setState({totalSpan: obj.total})
            obj.rows.map((array, index) => {
                data.push({
                    key: index,
                    custName: array.custName,
                    category: array.category,
                    custSource: array.custSource,
                    certNo: array.certNo,
                    contact: array.contact,
                    gmtCreate: array.gmtCreate,
                    custManagerName: array.custManagerName,
                    credited: array.credited,
                    editable: array.editable,
                    custNo: array.custNo
                })
            })
            this.setState({
                tDate: data
            })
        }).catch((error) => {
            console.warn(error);
        });
    }

    //点击个人进行数据筛选
    handlePersonalClick(){
        this.setState({queryLook: 0})
        this.setState({custType: 1})
        if(this.state.custState == 3){
            const body='category=0&credited=true'
            this.dataPost(body)
        }else if(this.state.custState == 4){
            const body='category=0&credited=false'
            this.dataPost(body)
        }else{
            const body='category=0'
            this.dataPost(body)
        }
    }

    //个人筛选鼠标晃动时的样式
    personalEnter(){
        this.refs.hoverPersonal.style.backgroundColor = "#ccc"
        this.refs.hoverCompany.style.backgroundColor = "#fff"
    }

    //点击机构进行数据筛选
    handleCompanyClick(){
        this.setState({queryLook: 0})
        this.setState({custType: 2})
        if(this.state.custState == 3){
            const body='category=1&credited=true'
            this.dataPost(body)
        }else if(this.state.custState == 4){
            const body='category=1&credited=false'
            this.dataPost(body)
        }else{
            const body='category=1'
            this.dataPost(body)
        }
        
    }

    //机构筛选鼠标晃动时的样式
    companyEnter(){
        this.refs.hoverCompany.style.backgroundColor = "#ccc"
        this.refs.hoverPersonal.style.backgroundColor = "#fff"
    }

    //点击有授信记录进行数据筛选
    handleHaveCredit(){
        this.setState({queryLook: 0})
        this.setState({custState: 3})
        if(this.state.custType == 1){
            const body='category=0&credited=true'
            this.dataPost(body)
        }else if(this.state.custType == 2){
            const body='category=1&credited=true'
            this.dataPost(body)
        }else{
            const body='credited=true'
            this.dataPost(body)
        }
    }

    //有授信记录筛选鼠标晃动时的样式
    haveEnter(){
        this.refs.hoverHave.style.backgroundColor = "#ccc"
        this.refs.hoverNo.style.backgroundColor = "#fff"
    }

    //点击无授信记录进行数据筛选
    handleNoCredit(){
        this.setState({queryLook: 0})
        this.setState({custState: 4})
        if(this.state.custType == 1){
            const body='category=0&credited=false'
            this.dataPost(body)
        }else if(this.state.custType == 2){
            const body='category=1&credited=false'
            this.dataPost(body)
        }else{
            const body='credited=false'
            this.dataPost(body)
        }
    }

    //无授信记录筛选鼠标晃动时的样式
    noEnter(){
        this.refs.hoverNo.style.backgroundColor = "#ccc"
        this.refs.hoverHave.style.backgroundColor = "#fff"
    }

    //点击精确查询进行数据筛选
    handleQuery(){
        this.setState({queryLook: 1})
        this.setState({custType: 0})
        this.setState({custState: 0})
        const custName = this.refs.queryCustName.value;
        const certNo = this.refs.queryCustId.value;
        const managerId = this.refs.selectManager.options[this.refs.selectManager.selectedIndex].value
        const body='custName='+custName+'&certNo='+certNo+'&managerId='+managerId
        this.dataPost(body)
        this.refs.hoverPersonal.style.backgroundColor = "#fff"
        this.refs.hoverCompany.style.backgroundColor = "#fff"
        this.refs.hoverHave.style.backgroundColor = "#fff"
        this.refs.hoverNo.style.backgroundColor = "#fff"
    }



    componentDidMount() {
        this.refs.hoverPersonal.style.backgroundColor = "#ccc"
        this.refs.hoverHave.style.backgroundColor = "#ccc"
        this.setState({custType: 1})
        this.setState({custState: 3})
        const data = []

        const managersData =[]
        fetch('/selfhelploan/queryCustomerList.json', {
          method: 'POST',
          credentials: "include",
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
          },
          body: 'category=0&credited=true'
        }).then((response) => response.json())
        .then((obj) => {
            obj.managers.map((array,index) => {
                managersData.push({
                    name: array.certName,
                    id: array.id
                })
            })
            this.setState({totalSpan: obj.total})
            this.setState({pCount: obj.pCount})
            this.setState({oCount: obj.oCount})
            this.setState({cTrue: obj.cTrue})
            this.setState({cFalse: obj.cFalse})
            obj.rows.map((array, index) => {
                data.push({
                    key: index,
                    custName: array.custName,
                    category: array.category,
                     custSource: array.custSource,
                    certNo: array.certNo,
                    contact: array.contact,
                    gmtCreate: array.gmtCreate,
                    custManagerName: array.custManagerName,
                    credited: array.credited,
                    editable: array.editable,
                    custNo: array.custNo
                })
            })
            this.setState({
                tDate: data,
                managersList: managersData
            })
        }).catch((error) => {
            console.warn(error);
        });
    }

    handleChange(pagination, filters, sorter){
        const current = pagination.current;
        const pageSize = pagination.pageSize;

        if(this.state.queryLook == 1){
            const custName = this.refs.queryCustName.value;
            const certNo = this.refs.queryCustId.value;
            const managerId = this.refs.selectManager.options[this.refs.selectManager.selectedIndex].value
            const body='current='+current+'&pageSize='+pageSize+'&custName='+custName+'&certNo='+certNo+'&managerId='+managerId
            this.dataPost(body)
        }else if(this.state.custType == 1&&this.state.custState == 3){
            const body='current='+current+'&pageSize='+pageSize+'&category=0&credited=true'
            this.dataPost(body)
        }else if(this.state.custType == 1&&this.state.custState == 4){
            const body='current='+current+'&pageSize='+pageSize+'&category=0&credited=false'
            this.dataPost(body)
        }else if(this.state.custType == 2&&this.state.custState == 3){
            const body='current='+current+'&pageSize='+pageSize+'&category=1&credited=true'
            this.dataPost(body)
        }else if(this.state.custType == 2&&this.state.custState == 4){
            const body='current='+current+'&pageSize='+pageSize+'&category=1&credited=false'
            this.dataPost(body)
        }else if(this.state.custType == 1){
            const body='current='+current+'&pageSize='+pageSize+'&category=0'
            this.dataPost(body)
        }else if(this.state.custType == 2){
            const body='current='+current+'&pageSize='+pageSize+'&category=1'
            this.dataPost(body)
        }else if(this.state.custState == 3){
            const body='current='+current+'&pageSize='+pageSize+'&credited=true'
            this.dataPost(body)
        }else if(this.state.custState == 4){
            const body='current='+current+'&pageSize='+pageSize+'&credited=false'
            this.dataPost(body)
        }else{
            const body='current='+current+'&pageSize='+pageSize
            this.dataPost(body)
        }
        
    }

    render() {
        const pagination = {
            total: this.state.totalSpan,
            showSizeChanger: true
        }

        const divStyleOne = {
            padding: '20px 20px',
            border: '1px solid #ccc'
        }
        const divStyleTwo = {
            height: '100px'
        }
        const divStyleThree = {
            padding: '10px 0',
            background: '#f2f2f2',
            textIndent: '10px',
            marginBottom: '20px',
            fontSize: '16px',
            fontWeight: 'bold'
        }
        const buttonStyle = {
            float: 'right',
            marginRight: '30px'
        }

        const custManTitle = {
            paddingLeft: '10px',
            paddingTop: '20px',
            fontWeight: 'bold',
            height: '75px',
        }

        const custManMail = {
            height: '150px'
        }

        const custManMailUl = {
            paddingLeft: '10px',
            marginBottom: '5px',
            height: '30px',
            lineHeight: '30px',
            display: 'block'
        }

        const custManMailLiOne = {
            backgroundColor: '#f2f2f2',
            width: '100px',
            textAlign: 'center',
            float: 'left'
        }

        const custManMailLiOther = {
            width: '100px',
            textAlign: 'center',
            cursor: 'pointer',
            float: 'left',
            borderRadius: '8px'
        }

        const detailedQuery = {
            marginLeft: '10px',
            height: '30px',
            lineHeight: '30px',
            marginTop: '20px',
            textAlign: 'center',
        }

        const detailedQueryInput = {
            outline: 'none',
            borderRadius: '8px',
            border: '1px #9C9C9C solid',
            height: '28px',
            marginRight: '30px',
            paddingLeft: '10px'
        }

        const detailedQuerySelect = {
            outline: 'none',
            borderRadius: '8px',
            border: '1px #9C9C9C solid',
            height: '28px',
            marginRight: '30px'
        }

        return (
            <div style = {divStyleOne}>
                <div style = {custManTitle}>
                    <span>个人工作台&nbsp;>>&nbsp;基础信息维护&nbsp;>>&nbsp;客户管理</span>
                </div>
                <div style = {custManMail}>
                    <div style={{width : 350,display : 'inline-block'}}>
                        <ul style = {custManMailUl}>
                            <li style={custManMailLiOne}>客户类型</li>
                            <li style={custManMailLiOther} ref="hoverPersonal" onClick={this.handlePersonalClick.bind(this)} onMouseDown={this.personalEnter.bind(this)} >个人&nbsp;&nbsp;<span>{this.state.pCount}</span></li>
                            <li style={custManMailLiOther} ref="hoverCompany" onClick={this.handleCompanyClick.bind(this)} onMouseDown={this.companyEnter.bind(this)} >企业&nbsp;&nbsp;<span>{this.state.oCount}</span></li>
                        </ul>
                        <ul style = {custManMailUl}>
                            <li style={custManMailLiOne}>客户授信状态</li>
                            <li style={custManMailLiOther} ref="hoverHave" onClick={this.handleHaveCredit.bind(this)} onMouseDown={this.haveEnter.bind(this)} >有授信记录&nbsp;&nbsp;<span>{this.state.cTrue}</span></li>
                            <li style={custManMailLiOther} ref="hoverNo" onClick={this.handleNoCredit.bind(this)} onMouseDown={this.noEnter.bind(this)} >无授信记录&nbsp;&nbsp;<span>{this.state.cFalse}</span></li>
                        </ul>
                    </div>
                    <div style={detailedQuery}>
                        <input style={detailedQueryInput} ref="queryCustName" type="text" placeholder="客户名称" />
                        <input style={detailedQueryInput} ref="queryCustId" type="text" placeholder="证件号码" />
                        <select style={detailedQuerySelect} ref="selectManager" >
                            <option>请选择客户经理</option>
                            {
                                this.state.managersList.map((array, index) => {
                                    return (<option key={index} value={array.id}>{array.name}</option>);
                                })
                            }
                        </select>
                        <Button type="primary" onClick={this.handleQuery.bind(this)}>查询</Button>
                    </div>
                </div>
                <div>
                    <div style = {divStyleTwo}>
                        <div style = {divStyleThree}>客户列表</div>
                        <Button type="primary" style = {buttonStyle}><Link to="/newTable/newCust/newCust">新建客户</Link></Button>
                        <div style = {{paddingTop: 10}}>共有<span>{this.state.totalSpan}</span>条记录</div>
                    </div>
                    <Table columns={columns} dataSource={this.state.tDate} bordered pagination={pagination} onChange={this.handleChange.bind(this)} />
                </div>
            </div>
        )
    }
}


// 配置路由
render((
    <Router history={hashHistory} >
        <Route path="/" component={myTable} />
        <Route path="newTable/:flagOne/:flagTwo" component={newTable} />
    </Router>
), document.getElementById('app'));